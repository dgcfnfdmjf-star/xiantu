(()=>{
'use strict';
// Shared species mapping includes elite variants; named story people and tribulations keep their own art.
if(typeof window.startCombat==='function'){
 let scene=null,casting=null,sceneRevision=0;
 const combatBase=window.combat;
 if(typeof combatBase==='function')window.combat=function(action,index){
  const previous=casting;casting=action==='skill'?player.skills?.[index]:null;
  try{return combatBase.apply(this,arguments);}finally{casting=previous;}
 };
 const elementHit=window.applyElementHitV286818;
 if(typeof elementHit==='function')window.applyElementHitV286818=function(skill,damage){const result=elementHit.apply(this,arguments);scene?.elementApplied(skill);return result;};
 function stop(){
  sceneRevision++;
  scene?.destroy();
  scene=null;
  document.getElementById('combatArena')?.classList.remove('duel25-active');
 }
 const start=window.startCombat;
 window.startCombat=function(...args){
  const result=start.apply(this,args);
  if(currentEnemy!==args[0]||gameState!=='combat')return result;
  stop();
  const revision=sceneRevision,owner=player,foe=currentEnemy;
  function attach(duel){
   if(!duel||revision!==sceneRevision||player!==owner||currentEnemy!==foe||gameState!=='combat')return;
   const key=typeof scrollMonsterKeyV2853==='function'?scrollMonsterKeyV2853(foe.name):null;
   scene=duel.create(document.getElementById('combatArena'),()=>({
    ...duel.readCombatElements(foe,owner),targetToken:foe,
    active:player===owner&&currentEnemy===foe&&(gameState==='combat'||gameState==='combat-ending'),
    compact:!!document.getElementById('battleVitalsV286816'),pet:owner.activePet,
    playerName:owner.name,enemyName:foe.name,playerHp:owner.hp,playerMax:getMaxHp(),enemyHp:foe.hp,enemyMax:foe.maxHp,
    burnTurns:foe.burnTurns,burnDamage:foe.burnStacks,burnHealBlock:!!foe._burnHealBlockV286818
   }),key);
  }
  document.getElementById('inkFxNameV2854').textContent='术法招式';
  loadBattlePresentationV2868124(attach);
  return result;
 };
 for(const name of ['resetRuntimeState','endCombatAfterCapture']){const base=window[name];if(typeof base==='function')window[name]=function(...args){stop();return base.apply(this,args);};}
 const attack=window.playAttackAnimation;window.playAttackAnimation=function(side){if(scene?.ready){scene.act(side,side==='player'&&casting?casting.element||'sword':side==='enemy'?undefined:'sword',side==='player'&&casting?casting.name:'');return;}return attack.apply(this,arguments);};
 const skill=window.playSkillEffect;window.playSkillEffect=function(name,element,source,visualResult){if(scene?.ready){scene.act('player',element||'sword',name,true,visualResult);return;}return skill.apply(this,arguments);};
 const bossSkill=window.playBossSkillEffect;if(typeof bossSkill==='function')window.playBossSkillEffect=function(name){if(scene?.ready){scene.act('enemy',window.InkSkillFxV2854?.profile(name).family||'sword',name,true);return;}return bossSkill.apply(this,arguments);};
 const damage=window.showDamageNumber;window.showDamageNumber=function(amount,side,heal,crit,boss,pet,skillName){if(scene?.ready){scene.hit(side,amount,heal,crit,pet,skillName);return;}if(skillName==='灼烧引爆'&&Number(amount)>0)window.InkSkillFxV2854?.fireBatch?.detonate(side);return damage.apply(this,arguments);};
 const log=window.addCombatLog;if(typeof log==='function')window.addCombatLog=function(text){
  const result=log.apply(this,arguments);if(/^灼烧造成\s*[1-9]\d* 点伤害/.test(String(text)))scene?.burnTick();return result;
 };
 const story=window.showStory;window.showStory=function(...args){stop();return story.apply(this,args);};
}

})();

// BEGIN SCENE25D_V2888
'use strict';
// V2888 · 2.5D map scenes. Pure canvas/CSS/inline SVG: no image files, no gameplay or save changes.
// World map: relief light baked once into the static ground cache, drifting cloud shadows, depth scale and
// cast shadows on landmarks/trees, cached screen-space haze + light, parallax foreground mist.
// 山河图: light/relief layer, raised landmark plinths, parallax mist, procedural terrain only under missing art.
// Location cards: layered ink-landscape diorama with pointer parallax and a raised medallion.
// Opt-out: the 山河图 header button, or localStorage 'xiantu_scene25d_v2888' = 'off'.
const SCENE25D_V2888={
 key:'xiantu_scene25d_v2888',
 depth:{far:.91,near:1.07},                       // sprite scale at the top / bottom of the view
 cast:{building:{w:66,h:20,dx:20,dy:5,y:26},tree:{w:30,h:10,dx:11,dy:4,y:28},alpha:.24},
 clouds:{count:6,alpha:.15,speed:7,w:520,h:230},
 haze:{top:.22,topSpan:.32,bottom:.16,bottomSpan:.28},
 mist:{alpha:.16,parallax:1.35,speed:6},
 relief:{hills:26,light:.15,shade:.17,global:.09,edge:.14},
 palette:{                                         // haze colour per region (sky tint seen through distance)
  south:[238,230,205],east:[214,232,220],west:[232,214,190],north:[226,238,246],human_peaks:[230,232,214],
  human_valleys:[226,236,212],demon_domain:[120,86,110],immortal_domain:[255,240,210]
 }
};
const S25_V2888={sprites:null,overlay:null,overlayKey:'',baked:new WeakSet(),frameVh:0,terrain:new Map(),scrollRaf:0,cardRaf:0,cardTarget:null,cardXY:[0,0]};

// ------------------------------------------------------------------ switches ----
let scene25dEnabledV2888=true;try{scene25dEnabledV2888=localStorage.getItem(SCENE25D_V2888.key)!=='off';}catch(_){}
function scene25dOnV2888(){return scene25dEnabledV2888;}
function scene25dCalmV2888(){try{return !!window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;}catch(_){return false;}}
function setScene25dV2888(on){
 on=!!on;scene25dEnabledV2888=on;s25StopMotionV2888();
 try{on?localStorage.removeItem(SCENE25D_V2888.key):localStorage.setItem(SCENE25D_V2888.key,'off');}catch(_){}
 S25_V2888.overlay=null;S25_V2888.overlayKey='';
 try{if(typeof releaseStaticWorldCacheV2767==='function')releaseStaticWorldCacheV2767();}catch(_){}
 document.documentElement.classList.toggle('scene25d-off-v2888',!on);s25ApplyScrollV2888();
 return on;
}
function s25RandV2888(seed){let s=(seed>>>0)||1;return()=>((s=Math.imul(s^s>>>15,1|s)+0x6D2B79F5|0,(s^s>>>7)>>>0)%100000)/100000;}
function s25HashV2888(text){let h=2166136261;for(const ch of String(text))h=Math.imul(h^ch.codePointAt(0),16777619);return h>>>0;}
function s25RegionV2888(){try{return currentRegion||player?.worldMapId||'south';}catch(_){return 'south';}}
function s25CanvasV2888(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext?.('2d');return x?{c,x}:null;}
function s25IsWorldCtxV2888(ctx){return !!ctx&&ctx.canvas&&ctx.canvas.id==='worldCanvas';}

// ------------------------------------------------------------------ sprites (made once) ----
function s25SpritesV2888(){
 if(S25_V2888.sprites)return S25_V2888.sprites;
 const blob=(w,h,puffs,rgb,seed)=>{
  const k=s25CanvasV2888(w,h);if(!k)return null;const r=s25RandV2888(seed);
  for(let i=0;i<puffs;i++){
   const x=w*(.18+.64*r()),y=h*(.3+.4*r()),rad=h*(.28+.25*r());
   const g=k.x.createRadialGradient(x,y,0,x,y,rad);g.addColorStop(0,`rgba(${rgb},.55)`);g.addColorStop(1,`rgba(${rgb},0)`);
   k.x.fillStyle=g;k.x.beginPath();k.x.arc(x,y,rad,0,Math.PI*2);k.x.fill();
  }
  return k.c;
 };
 const shadow=(()=>{const k=s25CanvasV2888(128,48);if(!k)return null;const g=k.x.createRadialGradient(64,24,2,64,24,62);g.addColorStop(0,'rgba(12,16,12,1)');g.addColorStop(.55,'rgba(12,16,12,.55)');g.addColorStop(1,'rgba(12,16,12,0)');k.x.setTransform(1,0,0,.38,0,14.9);k.x.fillStyle=g;k.x.beginPath();k.x.arc(64,24,62,0,Math.PI*2);k.x.fill();return k.c;})();
 S25_V2888.sprites={cloud:[blob(256,112,7,'18,26,22',11),blob(256,112,6,'18,26,22',29)],mist:[blob(256,96,6,'255,255,255',41),blob(256,96,5,'255,255,255',57)],shadow};
 return S25_V2888.sprites;
}

// ------------------------------------------------------------------ world: one-time relief on the ground cache ----
function s25BakeReliefV2888(cache){
 if(typeof joinedSceneReadyV286896==='function'&&joinedSceneReadyV286896())return;
 if(!cache||S25_V2888.baked.has(cache))return;S25_V2888.baked.add(cache);
 const ctx=cache.getContext?.('2d');if(!ctx)return;
 const C=SCENE25D_V2888.relief,w=cache.width,h=cache.height,region=s25RegionV2888();
 const image=typeof SCROLL_ART_V2831!=='undefined'&&(SCROLL_ART_V2831.regions||SCROLL_ART_V2831.landscape),art=!!(image?.complete&&image.naturalWidth);
 ctx.save();
 if(!art){                                          // procedural ground only: rounded mounds lit from the upper left
  const r=s25RandV2888(s25HashV2888(region)),dark=region==='demon_domain'?'28,10,22':'16,26,18';
  for(let i=0;i<C.hills;i++){
   const x=w*r(),y=h*r(),rad=90+r()*150;
   const lg=ctx.createRadialGradient(x-rad*.35,y-rad*.42,0,x-rad*.35,y-rad*.42,rad*.95);lg.addColorStop(0,`rgba(255,248,222,${C.light})`);lg.addColorStop(1,'rgba(255,248,222,0)');
   ctx.fillStyle=lg;ctx.beginPath();ctx.arc(x-rad*.35,y-rad*.42,rad*.95,0,Math.PI*2);ctx.fill();
   const sg=ctx.createRadialGradient(x+rad*.38,y+rad*.42,0,x+rad*.38,y+rad*.42,rad);sg.addColorStop(0,`rgba(${dark},${C.shade})`);sg.addColorStop(1,`rgba(${dark},0)`);
   ctx.fillStyle=sg;ctx.beginPath();ctx.arc(x+rad*.38,y+rad*.42,rad,0,Math.PI*2);ctx.fill();
  }
 }
 // whole map: warm light from the upper left, cool shade toward the lower right, darker world edges (ambient occlusion)
 const d=ctx.createLinearGradient(0,0,w,h);d.addColorStop(0,`rgba(255,238,196,${C.global})`);d.addColorStop(.5,'rgba(255,238,196,0)');d.addColorStop(.5,'rgba(20,28,44,0)');d.addColorStop(1,`rgba(20,28,44,${C.global*1.2})`);
 ctx.fillStyle=d;ctx.fillRect(0,0,w,h);
 const edge=70;for(const [x0,y0,x1,y1,rx,ry,rw,rh] of [[0,0,0,edge,0,0,w,edge],[0,h,0,h-edge,0,h-edge,w,edge],[0,0,edge,0,0,0,edge,h],[w,0,w-edge,0,w-edge,0,edge,h]]){
  const g=ctx.createLinearGradient(x0,y0,x1,y1);g.addColorStop(0,`rgba(10,14,12,${C.edge})`);g.addColorStop(1,'rgba(10,14,12,0)');ctx.fillStyle=g;ctx.fillRect(rx,ry,rw,rh);
 }
 ctx.restore();
}

// One small world-space lighting map is shared by the completed northern scene.
// Its maximum backing is 256x256; camera movement and standing frames reuse it.
function s25JoinedWorldLightV286896(ctx){
 const w=FLAT_WORLD.width,h=FLAT_WORLD.height,key=`${w}:${h}`;
 if(!S25_V2888.joinedLight||S25_V2888.joinedLightKey!==key){
  const old=S25_V2888.joinedLight,k=s25CanvasV2888(256,256);if(!k)return;
  const x=k.x,C=SCENE25D_V2888.relief,d=x.createLinearGradient(0,0,256,256);
  d.addColorStop(0,`rgba(255,238,196,${C.global})`);d.addColorStop(.5,'rgba(255,238,196,0)');d.addColorStop(.5,'rgba(20,28,44,0)');d.addColorStop(1,`rgba(20,28,44,${C.global*1.2})`);x.fillStyle=d;x.fillRect(0,0,256,256);
  const ex=70/w*256,ey=70/h*256;
  for(const [x0,y0,x1,y1,rx,ry,rw,rh] of [[0,0,0,ey,0,0,256,ey],[0,256,0,256-ey,0,256-ey,256,ey],[0,0,ex,0,0,0,ex,256],[256,0,256-ex,0,256-ex,0,ex,256]]){
   const g=x.createLinearGradient(x0,y0,x1,y1);g.addColorStop(0,`rgba(10,14,12,${C.edge})`);g.addColorStop(1,'rgba(10,14,12,0)');x.fillStyle=g;x.fillRect(rx,ry,rw,rh);
  }
  S25_V2888.joinedLight=k.c;S25_V2888.joinedLightKey=key;if(old){old.width=1;old.height=1;}
 }
 ctx.drawImage(S25_V2888.joinedLight,0,0,w,h);
}

// ------------------------------------------------------------------ world: per-frame helpers ----
function s25DepthScaleV2888(y){
 if(typeof wildSceneReadyV286898==='function'&&wildSceneReadyV286898()&&wildSceneV286898()?.actorScale)return wildSceneV286898().actorScale;
 const D=SCENE25D_V2888.depth,cam=FLAT_WORLD.camera,vh=S25_V2888.frameVh||700;
 const k=Math.max(0,Math.min(1,(y-cam.y)/vh));return D.far+(D.near-D.far)*k;
}
function s25CastKindV2888(o){
 if(o?.t==='tree')return 'tree';
 // Integrated architecture already includes a contact shadow in its painted earth.
 if(typeof wildSceneRoomV286898==='function'&&wildSceneRoomV286898(o)||typeof sectScenePoiV286896==='function'&&sectScenePoiV286896(o)||typeof joinedArchitectureReadyV286896==='function'&&joinedArchitectureReadyV286896(o))return null;
 if(!o||o.enemy||o._warUnitV2840||o.action==='war_map_v2840'||o.action==='explore_v2828'||o.buildingId==='spirit_spring')return null;
 const k=typeof getPoiVisualKind==='function'?getPoiVisualKind(o):'default';
 return k==='npc'||k==='default'||k==='rest'||k==='forest'||k==='battlefield'||k==='pets'?null:'building';
}
function s25CastShadowV2888(ctx,o,kind){
 const sp=s25SpritesV2888().shadow;if(!sp)return;
 const c=SCENE25D_V2888.cast,k=c[kind],s=kind==='tree'?(o.s||1):1,w=k.w*s*2,h=k.h*s*2;
 ctx.save();ctx.globalAlpha*=c.alpha;
 ctx.translate(o.x+k.dx*s,o.y+k.y*s+k.dy*s);ctx.transform(1,0,-.55,1,0,0);   // skewed away from the upper-left sun
 ctx.drawImage(sp,-w/2,-h/2,w,h);ctx.restore();
}
function s25WrapSpriteV2888(name,cast){
 const base=window[name];if(typeof base!=='function'||base._s25V2888)return;
 const wrapped=function(ctx,o){
  if(!scene25dOnV2888()||!s25IsWorldCtxV2888(ctx)||!o)return base.apply(this,arguments);
  const kind=cast?s25CastKindV2888(o):null;if(kind)s25CastShadowV2888(ctx,o,kind);
  const grounded=name==='drawWorldPoi'&&(typeof wildSceneRoomV286898==='function'&&wildSceneRoomV286898(o)||typeof sectScenePoiV286896==='function'&&sectScenePoiV286896(o)||typeof joinedArchitectureReadyV286896==='function'&&joinedArchitectureReadyV286896(o));
  // Architecture and its ground footprint use the same fixed world scale: camera movement
  // must not stretch the courtyard across static roads or the surrounding soil.
  const s=grounded?1:s25DepthScaleV2888(o.y),pivotY=grounded?o.y+30:o.y;
  ctx.save();ctx.translate(o.x,pivotY);ctx.scale(s,s);ctx.translate(-o.x,-pivotY);
  try{return base.apply(this,arguments);}finally{ctx.restore();}
 };
 wrapped._s25V2888=true;wrapped._baseV2888=base;window[name]=wrapped;
}
function s25CloudShadowsV2888(ctx,t,minX,maxX,minY,maxY){
 const C=SCENE25D_V2888.clouds,sp=s25SpritesV2888().cloud,W=FLAT_WORLD.width+C.w*2,H=FLAT_WORLD.height;
 const tt=scene25dCalmV2888()?0:t*.001,r=s25RandV2888(s25HashV2888(s25RegionV2888())+7);
 ctx.save();
 for(let i=0;i<C.count;i++){
  const img=sp[i%2];if(!img)continue;
  const sc=.7+r()*.6,w=C.w*sc,h=C.h*sc,x=((r()*W+tt*C.speed*(1+i*.15))%W)-C.w,y=H*(.05+.9*r());
  if(x+w<minX||x>maxX||y+h<minY||y>maxY)continue;
  ctx.globalAlpha=C.alpha*(.75+.5*r());ctx.drawImage(img,x,y,w,h);
 }
 ctx.restore();
}
function s25OverlayV2888(vw,vh){
 const region=s25RegionV2888(),key=`${Math.round(vw)}x${Math.round(vh)}:${region}`;
 if(S25_V2888.overlay&&S25_V2888.overlayKey===key)return S25_V2888.overlay;
 const k=s25CanvasV2888(Math.max(1,Math.round(vw)),Math.max(1,Math.round(vh)));if(!k)return null;
 const H=SCENE25D_V2888.haze,rgb=(SCENE25D_V2888.palette[region]||SCENE25D_V2888.palette.south).join(','),x=k.x,w=k.c.width,h=k.c.height;
 let g=x.createLinearGradient(0,0,0,h*H.topSpan);g.addColorStop(0,`rgba(${rgb},${H.top})`);g.addColorStop(1,`rgba(${rgb},0)`);x.fillStyle=g;x.fillRect(0,0,w,h*H.topSpan);   // distance haze
 g=x.createLinearGradient(0,h*(1-H.bottomSpan),0,h);g.addColorStop(0,'rgba(10,14,12,0)');g.addColorStop(1,`rgba(10,14,12,${H.bottom})`);x.fillStyle=g;x.fillRect(0,h*(1-H.bottomSpan),w,h*H.bottomSpan);  // near ground
 const diag=Math.hypot(w,h);
 g=x.createRadialGradient(-w*.1,-h*.15,0,-w*.1,-h*.15,diag*.75);g.addColorStop(0,'rgba(255,236,190,.12)');g.addColorStop(1,'rgba(255,236,190,0)');x.fillStyle=g;x.fillRect(0,0,w,h);   // sun
 g=x.createRadialGradient(w*1.05,h*1.05,0,w*1.05,h*1.05,diag*.6);g.addColorStop(0,'rgba(18,26,46,.14)');g.addColorStop(1,'rgba(18,26,46,0)');x.fillStyle=g;x.fillRect(0,0,w,h);       // shade
 S25_V2888.overlay=k.c;S25_V2888.overlayKey=key;return k.c;
}
function s25ForegroundV2888(ctx,t,vw,vh){
 const ov=s25OverlayV2888(vw,vh);if(ov)ctx.drawImage(ov,0,0,vw,vh);
 const M=SCENE25D_V2888.mist,sp=s25SpritesV2888().mist,cam=FLAT_WORLD.camera,tt=scene25dCalmV2888()?0:t*.001,span=vw+520;
 ctx.save();ctx.globalAlpha=M.alpha;
 for(let i=0;i<2;i++){const img=sp[i];if(!img)continue;
  const x=((( -(scene25dCalmV2888()?0:cam.x)*M.parallax+tt*M.speed*(i?1.4:1)+i*span*.5)%span)+span)%span-260,y=vh*(i?.86:.74)-(scene25dCalmV2888()?0:cam.y)*.04%24;
  ctx.drawImage(img,x,y,420,150);
 }
 ctx.restore();
}

// ------------------------------------------------------------------ world: install wrappers ----
function installWorld25dV2888(){
 if(typeof drawFlatWorld!=='function'||drawFlatWorld._s25V2888)return;
 const baseCache=window.ensureStaticWorldCache;
 if(typeof baseCache==='function'){const w=function(){const c=baseCache.apply(this,arguments);try{if(scene25dOnV2888())s25BakeReliefV2888(c);}catch(e){console.warn('2.5D 地形光照失败',e);}return c;};w._s25V2888=true;window.ensureStaticWorldCache=w;}
 const baseAmbient=window.drawWorldAmbient;
 if(typeof baseAmbient==='function'){const w=function(ctx,t,minX,maxX,minY,maxY){const r=baseAmbient.apply(this,arguments);try{if(scene25dOnV2888()&&s25IsWorldCtxV2888(ctx)&&!(typeof joinedSceneReadyV286896==='function'&&joinedSceneReadyV286896()))s25CloudShadowsV2888(ctx,t,minX,maxX,minY,maxY);}catch(e){console.warn('2.5D 云影失败',e);}return r;};w._s25V2888=true;window.drawWorldAmbient=w;}
 s25WrapSpriteV2888('drawWorldPoi',true);
 s25WrapSpriteV2888('drawDepthTreeV2770',true);
 s25WrapSpriteV2888('drawWorldMonster',false);
 s25WrapSpriteV2888('drawWorldPlayer',false);
 const baseDraw=window.drawFlatWorld;
 const w=function(t=performance.now(),dt=1/60){
  if(typeof watchDprV2893==='function')watchDprV2893();
  const c=document.getElementById('worldCanvas'),dpr=c?._dpr||1;
  if(c)S25_V2888.frameVh=c.height/dpr;
  const r=baseDraw.apply(this,arguments);
  if(c&&!interiorV286886&&!document.hidden&&!isWorldOverlayOpen()&&document.body.classList.contains('flat-world-active')&&scene25dOnV2888()){
   const ctx=c.getContext('2d');
   try{ctx.save();ctx.setTransform(dpr,0,0,dpr,0,0);s25ForegroundV2888(ctx,t,c.width/dpr,c.height/dpr);}catch(e){console.warn('2.5D 前景失败',e);}finally{ctx.restore();}
  }
  return r;
 };
 w._s25V2888=true;window.drawFlatWorld=w;
}

// ------------------------------------------------------------------ 山河图 ----
function s25TerrainUrlV2888(region){
 if(!Object.hasOwn(SCENE25D_V2888.palette,region))region='south';
 if(S25_V2888.terrain.has(region))return S25_V2888.terrain.get(region);
 const k=s25CanvasV2888(440,290);if(!k||typeof k.c.toDataURL!=='function')return '';
 const x=k.x,w=440,h=290,r=s25RandV2888(s25HashV2888(region)+3);
 const pal=typeof worldThemeV2827==='function'?worldThemeV2827():{ground:'#617452',patch:'#8b9867',dark:'#314b37'};
 x.fillStyle='#eadfbe';x.fillRect(0,0,w,h);
 for(let i=0;i<34;i++){                             // ink mountains: lit left flank, shaded right flank
  const cx=w*r(),base=h*(.25+.75*r()),ph=18+r()*46,pw=ph*(1.1+r());
  x.fillStyle=pal.patch;x.globalAlpha=.32;x.beginPath();x.moveTo(cx-pw,base);x.lineTo(cx,base-ph);x.lineTo(cx,base);x.closePath();x.fill();
  x.fillStyle=pal.dark;x.globalAlpha=.36;x.beginPath();x.moveTo(cx,base-ph);x.lineTo(cx+pw,base);x.lineTo(cx,base);x.closePath();x.fill();
 }
 x.globalAlpha=.5;x.strokeStyle='#6f8f99';x.lineWidth=3;x.beginPath();x.moveTo(0,h*.62);for(let i=1;i<=8;i++)x.quadraticCurveTo(w*(i-.5)/8,h*(.55+.15*r()),w*i/8,h*(.58+.1*r()));x.stroke();x.globalAlpha=1;
 let url='';try{url=k.c.toDataURL('image/jpeg',.82);}catch(_){}
 S25_V2888.terrain.set(region,url);return url;
}
function s25DecorateFieldV2888(){
 const field=document.getElementById('scrollFieldV2831');if(!field||!scene25dOnV2888())return;
 if(!field.querySelector('.s25-light-v2888'))for(const cls of ['s25-mist-v2888 s25-near-v2888','s25-mist-v2888 s25-far-v2888','s25-light-v2888']){const el=document.createElement('div');el.className=cls;el.setAttribute('aria-hidden','true');field.prepend(el);}
 s25ScrollParallaxV2888();
}
function s25ScrollParallaxV2888(){
 const view=document.getElementById('scrollWindowV2831');if(!view||document.hidden||!scene25dOnV2888())return;
 if(scene25dCalmV2888()){for(const el of view.querySelectorAll('.s25-mist-v2888'))el.style.transform='none';return;}
 for(const el of view.querySelectorAll('.s25-mist-v2888')){const k=el.classList.contains('s25-near-v2888')?-.18:.22;el.style.transform=`translate3d(${(view.scrollLeft*k).toFixed(1)}px,${(view.scrollTop*k).toFixed(1)}px,0)`;}
}
function s25EnhanceScrollV2888(){
 const wrap=document.getElementById('scrollMapV2831');if(!wrap)return;
 const head=wrap.querySelector('header');
 if(head&&!head.querySelector('[data-s25-toggle]')){
  const b=document.createElement('button');b.type='button';b.setAttribute('data-s25-toggle','1');b.className='s25-toggle-v2888';
  const label=()=>{const on=scene25dOnV2888();b.textContent=on?'立体 · 开':'立体 · 关';b.setAttribute('aria-pressed',String(on));};label();
  b.addEventListener('click',e=>{e.stopPropagation();setScene25dV2888(!scene25dOnV2888());label();s25ApplyScrollV2888();});
  head.insertBefore(b,head.querySelector('[data-scroll-action="close"]'));
 }
 const view=document.getElementById('scrollWindowV2831');
 if(view&&!view._s25V2888){view._s25V2888=true;view.addEventListener('scroll',()=>{if(S25_V2888.scrollRaf||document.hidden||!scene25dOnV2888()||scene25dCalmV2888())return;S25_V2888.scrollRaf=requestAnimationFrame(()=>{S25_V2888.scrollRaf=0;s25ScrollParallaxV2888();});},{passive:true});}
 s25ApplyScrollV2888();
}
function s25ApplyScrollV2888(){
 const wrap=document.getElementById('scrollMapV2831'),field=document.getElementById('scrollFieldV2831');if(!wrap||!field)return;
 const on=scene25dOnV2888();wrap.classList.toggle('scene25d-scroll-v2888',on);
 if(!on){for(const el of field.querySelectorAll('.s25-light-v2888, .s25-mist-v2888'))el.remove();if(field._s25Background){Object.assign(field.style,field._s25Background);delete field._s25Background;delete field.dataset.s25Bg;}return;}
 const url=s25TerrainUrlV2888(s25RegionV2888());
 if(url&&!field.dataset.s25Bg){                      // painted art stays on top; the terrain only shows where art is missing
  field._s25Background=Object.fromEntries(['backgroundImage','backgroundSize','backgroundPosition','backgroundRepeat'].map(k=>[k,field.style[k]||'']));
  const cs=getComputedStyle(field),img=field.style.backgroundImage||cs.backgroundImage||'none';
  field.dataset.s25Bg=img;
  const size=field.style.backgroundSize||cs.backgroundSize||'100% 100%',pos=field.style.backgroundPosition||cs.backgroundPosition||'50% 50%';
  field.style.backgroundImage=`${img&&img!=='none'?img+', ':''}url("${url}")`;
  field.style.backgroundSize=`${img&&img!=='none'?size+', ':''}100% 100%`;
  field.style.backgroundPosition=`${img&&img!=='none'?pos+', ':''}0 0`;
  field.style.backgroundRepeat='no-repeat';
 }
 s25DecorateFieldV2888();
}
function installScroll25dV2888(){
 const baseShow=window.showScrollMapV2831;
 if(typeof baseShow==='function'&&!baseShow._s25V2888){const w=function(){const r=baseShow.apply(this,arguments);try{s25EnhanceScrollV2888();}catch(e){console.warn('2.5D 山河图失败',e);}return r;};w._s25V2888=true;window.showScrollMapV2831=w;}
 const baseRender=window.renderScrollTargetsV2837;  // the field is rebuilt on every filter/selection change
 if(typeof baseRender==='function'&&!baseRender._s25V2888){const w=function(){const r=baseRender.apply(this,arguments);try{s25DecorateFieldV2888();}catch(e){console.warn('2.5D 山河图层失败',e);}return r;};w._s25V2888=true;window.renderScrollTargetsV2837=w;}
 const baseZoom=window.zoomScrollV2837;
 if(typeof baseZoom==='function'&&!baseZoom._s25V2888){const w=function(){const r=baseZoom.apply(this,arguments);try{s25ScrollParallaxV2888();}catch(_){}return r;};w._s25V2888=true;window.zoomScrollV2837=w;}
}

// ------------------------------------------------------------------ location cards ----
function s25RidgeV2888(rand,base,amp,step){
 let d=`M0 80 L0 ${base}`;for(let x=0;x<=300;x+=step){const y=base-amp*(.35+.65*rand());d+=` L${x} ${y.toFixed(1)}`;}return d+' L300 80 Z';
}
function s25LandmarkV2888(kind){
 if(kind==='sect')return '<g transform="translate(236 30)"><path d="M-22 22h44l-6-7h-32z"/><path d="M-17 15h34l-5-7h-24z"/><path d="M-12 8h24l-4-7h-16z"/><path d="M-1 1h2v-9h-2z"/><rect x="-14" y="22" width="28" height="22"/><path d="M-44 44v-14h4v14zM-30 44v-14h4v14zM-48 30h26l-3-4h-20z"/></g>';
 if(kind==='village')return '<g transform="translate(222 46)"><path d="M0 12l14-12 14 12z"/><rect x="3" y="12" width="22" height="16"/><path d="M26 16l12-10 12 10z"/><rect x="29" y="16" width="18" height="12"/><path d="M-22 18l10-9 10 9z"/><rect x="-20" y="18" width="16" height="10"/></g>';
 if(kind==='home')return '<g transform="translate(230 30)"><path d="M-40 50 L-30 6 Q-5 -10 22 4 L40 50Z"/><path d="M-12 50v-18a12 12 0 0 1 24 0v18z" fill="rgba(0,0,0,.55)"/></g>';
 if(kind==='market')return '<g transform="translate(222 48)"><rect x="-20" y="8" width="18" height="18"/><path d="M-24 8h26l-4-8h-18z"/><rect x="8" y="8" width="18" height="18"/><path d="M4 8h26l-4-8h-18z"/><path d="M36 26v-30h2v30z"/><path d="M38 -4h12l-3 5 3 5h-12z"/></g>';
 return '<g transform="translate(232 40)"><path d="M-26 14q26 -16 52 0l-6 3h-40z"/><rect x="-16" y="17" width="3" height="20"/><rect x="13" y="17" width="3" height="20"/><path d="M-22 37h44v3h-44z"/></g>';
}
function s25SceneKindV2888(icon,title){
 const t=String(icon)+String(title);
 if(/⛩|宗|殿|阁/.test(t))return 'sect';
 if(/🏘|村|镇/.test(t))return 'village';
 if(/🏠|洞府|居/.test(t))return 'home';
 if(/🏪|🏬|市|铺|商/.test(t))return 'market';
 return 'pavilion';
}
function s25DioramaV2888(icon,title,accent){
 const pal=typeof worldThemeV2827==='function'?worldThemeV2827():{ground:'#617452',patch:'#8b9867',dark:'#314b37'};
 const r=s25RandV2888(s25HashV2888(title)),safe=/^#[0-9a-f]{3,8}$/i.test(accent)?accent:'#ffd98a',kind=s25SceneKindV2888(icon,title);
 const layer=(depth,body)=>`<div class="s25-layer-v2888" style="--d:${depth}"><svg viewBox="0 0 300 80" preserveAspectRatio="none" focusable="false">${body}</svg></div>`;
 return `<div class="s25-diorama-v2888" aria-hidden="true" style="--s25-accent:${safe}">`
  +`<div class="s25-sky-v2888"></div><div class="s25-sun-v2888" style="left:${Math.round(12+r()*30)}%"></div>`
  +layer(.15,`<path d="${s25RidgeV2888(r,46,30,20)}" fill="${pal.patch}" opacity=".45"/>`)
  +layer(.35,`<path d="${s25RidgeV2888(r,58,24,15)}" fill="${pal.ground}" opacity=".8"/>`)
  +'<div class="s25-mistband-v2888"></div>'
  +layer(.7,`<g fill="${pal.dark}"><path d="${s25RidgeV2888(r,70,12,25)}"/>${s25LandmarkV2888(kind)}</g>`)
  +'<div class="s25-ground-v2888"></div></div>';
}
function installCards25dV2888(){
 const base=window.buildAreaSceneCard;if(typeof base!=='function'||base._s25V2888)return;
 const w=function(opts={}){
  const html=base.apply(this,arguments);
  if(!scene25dOnV2888()||typeof html!=='string'||!html.includes('<div class="area-scene-card">'))return html;
  try{return html.replace('<div class="area-scene-card">',`<div class="area-scene-card scene25d-card-v2888">${s25DioramaV2888(opts?.icon??'',opts?.title??'',opts?.accent??'#ffd98a')}`);}
  catch(e){console.warn('2.5D 场景卡失败',e);return html;}
 };
 w._s25V2888=true;w._baseV2888=base;window.buildAreaSceneCard=w;
 const move=e=>{
  const card=e.target?.closest?.('.scene25d-card-v2888');
  if(card!==S25_V2888.cardTarget){if(S25_V2888.cardTarget){S25_V2888.cardTarget.style.setProperty('--s25x','0');S25_V2888.cardTarget.style.setProperty('--s25y','0');}S25_V2888.cardTarget=card||null;}
  if(!card||document.hidden||!scene25dOnV2888()||scene25dCalmV2888()||(e.pointerType==='touch'&&!e.buttons))return;
  const b=card.getBoundingClientRect();S25_V2888.cardXY=[Math.max(-1,Math.min(1,((e.clientX-b.left)/Math.max(1,b.width))*2-1)),Math.max(-1,Math.min(1,((e.clientY-b.top)/Math.max(1,b.height))*2-1))];
  if(S25_V2888.cardRaf)return;
  S25_V2888.cardRaf=requestAnimationFrame(()=>{S25_V2888.cardRaf=0;const c=S25_V2888.cardTarget;if(!c||!c.isConnected||!scene25dOnV2888()||document.hidden)return;c.style.setProperty('--s25x',S25_V2888.cardXY[0].toFixed(3));c.style.setProperty('--s25y',S25_V2888.cardXY[1].toFixed(3));});
 };
 document.addEventListener('pointermove',move,{passive:true});
}

function s25StopMotionV2888(){
 cancelAnimationFrame(S25_V2888.cardRaf);cancelAnimationFrame(S25_V2888.scrollRaf);
 S25_V2888.cardRaf=S25_V2888.scrollRaf=0;
 const c=S25_V2888.cardTarget;if(c){c.style.setProperty('--s25x','0');c.style.setProperty('--s25y','0');}S25_V2888.cardTarget=null;
}
let scene25dLifecycleV2888=false;
function installSceneLifecycleV2888(){
 if(scene25dLifecycleV2888)return;scene25dLifecycleV2888=true;
 for(const n of ['pointerup','pointercancel','pointerleave'])document.addEventListener(n,s25StopMotionV2888,{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)s25StopMotionV2888();});
 window.addEventListener('pagehide',s25StopMotionV2888);
 window.addEventListener('storage',e=>{if(e.key===SCENE25D_V2888.key||e.key===null)setScene25dV2888(e.key===null||e.newValue!=='off');});
 window.matchMedia?.('(prefers-reduced-motion: reduce)')?.addEventListener?.('change',()=>{s25StopMotionV2888();s25ScrollParallaxV2888();});
 for(const n of ['closeScrollMapV2837','closeWorldOverlay','resetRuntimeState']){const base=window[n];if(typeof base==='function')window[n]=function(...args){s25StopMotionV2888();return base.apply(this,args);};}
}
// ------------------------------------------------------------------ styles ----
function installStyles25dV2888(){
 if(document.getElementById('scene25dStyleV2888'))return;
 const st=document.createElement('style');st.id='scene25dStyleV2888';
 st.textContent=`
.scene25d-card-v2888{position:relative;overflow:hidden;--s25x:0;--s25y:0;transform:perspective(900px) rotateX(calc(var(--s25y) * -2deg)) rotateY(calc(var(--s25x) * 2.6deg));transition:transform .25s ease-out}
.scene25d-card-v2888 .s25-diorama-v2888{position:relative;height:88px;margin:-14px -14px 12px;border-radius:18px 18px 0 0;overflow:hidden;contain:paint;background:#1c2128}
.s25-sky-v2888{position:absolute;inset:0;background:linear-gradient(180deg,color-mix(in srgb,var(--s25-accent) 30%,#2b3640) 0%,#1d252c 100%)}
@supports not (background:color-mix(in srgb,red 50%,blue)){.s25-sky-v2888{background:linear-gradient(180deg,#5b5a4a 0%,#1d252c 100%)}}
.s25-sun-v2888{position:absolute;top:12px;width:30px;height:30px;border-radius:50%;background:radial-gradient(circle at 40% 40%,#fff8de,var(--s25-accent) 60%,transparent 72%);box-shadow:0 0 26px 8px color-mix(in srgb,var(--s25-accent) 45%,transparent);opacity:.85;transform:translate3d(calc(var(--s25x) * -2px),calc(var(--s25y) * -1px),0)}
.s25-layer-v2888{position:absolute;inset:-6px -12px 0;transform:translate3d(calc(var(--s25x) * var(--d) * -14px),calc(var(--s25y) * var(--d) * -5px),0);transition:transform .25s ease-out;will-change:transform}
.s25-layer-v2888 svg{width:100%;height:100%;display:block}
.s25-mistband-v2888{position:absolute;left:-20%;right:-20%;top:46%;height:26px;background:radial-gradient(ellipse at 30% 50%,rgba(255,255,255,.22),transparent 60%),radial-gradient(ellipse at 75% 50%,rgba(255,255,255,.16),transparent 55%);animation:s25DriftV2888 22s linear infinite alternate}
.s25-ground-v2888{position:absolute;left:0;right:0;bottom:0;height:22px;background:linear-gradient(180deg,transparent,rgba(10,12,14,.55))}
@keyframes s25DriftV2888{from{transform:translateX(-6%)}to{transform:translateX(6%)}}
.scene25d-card-v2888 .area-scene-head{position:relative;z-index:1}
.scene25d-card-v2888 .area-scene-icon{margin-top:-46px;background:radial-gradient(circle at 32% 26%,rgba(255,255,255,.34),rgba(255,255,255,.06) 42%,rgba(0,0,0,.28) 100%),#2a3038;border:1px solid rgba(255,255,255,.2);box-shadow:0 14px 22px rgba(0,0,0,.42),0 3px 0 rgba(0,0,0,.35),inset 0 2px 1px rgba(255,255,255,.22),inset 0 -6px 10px rgba(0,0,0,.35)!important;text-shadow:0 3px 4px rgba(0,0,0,.45)}
@media(max-width:600px){.scene25d-card-v2888 .s25-diorama-v2888{height:66px}.scene25d-card-v2888 .area-scene-icon{margin-top:-38px}}
.scene25d-scroll-v2888 .scroll-field-v2831 .s25-light-v2888{position:absolute;inset:0;pointer-events:none;z-index:1;background:radial-gradient(ellipse at 12% 8%,rgba(255,246,214,.30),transparent 55%),radial-gradient(ellipse at 95% 100%,rgba(48,34,22,.22),transparent 60%),linear-gradient(180deg,rgba(246,238,214,.32),transparent 30%)}
.scene25d-scroll-v2888 .scroll-field-v2831 .s25-mist-v2888{position:absolute;inset:-10%;pointer-events:none;z-index:1;background:radial-gradient(ellipse 22% 9% at 20% 30%,rgba(255,255,255,.34),transparent 70%),radial-gradient(ellipse 26% 8% at 70% 62%,rgba(255,255,255,.28),transparent 70%),radial-gradient(ellipse 18% 7% at 45% 85%,rgba(255,255,255,.24),transparent 70%);will-change:transform}
.scene25d-scroll-v2888 .scroll-field-v2831 .s25-near-v2888{opacity:.7;background-size:140% 140%}
.scene25d-scroll-v2888 .scroll-poi-v2831::before{content:"";position:absolute;left:50%;bottom:14px;width:46px;height:12px;margin-left:-14px;border-radius:50%;background:radial-gradient(closest-side,rgba(40,26,12,.42),transparent);transform:skewX(-35deg);z-index:-1;pointer-events:none}
.scene25d-scroll-v2888 .scroll-poi-v2831{transition:transform .18s ease-out}
.scene25d-scroll-v2888 .scroll-poi-v2831.is-selected,.scene25d-scroll-v2888 .scroll-poi-v2831:hover{transform:translate(-50%,-82%)}
.scene25d-scroll-v2888 .scroll-poi-v2831.is-selected::before,.scene25d-scroll-v2888 .scroll-poi-v2831:hover::before{bottom:6px;width:54px;opacity:.75}
.scene25d-scroll-v2888 .scroll-player-v2831{filter:drop-shadow(3px 4px 2px rgba(40,26,12,.45))}
.s25-toggle-v2888{margin-left:auto;margin-right:8px;font-size:12px!important;min-height:36px!important}
.scene25d-off-v2888 .s25-diorama-v2888{display:none}.scene25d-off-v2888 .scene25d-card-v2888{transform:none!important}.scene25d-off-v2888 .scene25d-card-v2888 .area-scene-icon{margin-top:0}
.xiantu-v2762-page-hidden .s25-mistband-v2888{animation-play-state:paused}
@media (prefers-reduced-motion: reduce){.s25-layer-v2888,.s25-sun-v2888,.s25-mist-v2888{transform:none!important}.scene25d-card-v2888,.s25-layer-v2888,.scene25d-scroll-v2888 .scroll-poi-v2831{transition:none}.s25-mistband-v2888{animation:none}.scene25d-card-v2888{transform:none}}
`;
 document.head.appendChild(st);
}

// ------------------------------------------------------------------ install ----
function installScene25dV2888(){
 installSceneLifecycleV2888();installStyles25dV2888();installWorld25dV2888();installScroll25dV2888();installCards25dV2888();
 document.documentElement.classList.toggle('scene25d-off-v2888',!scene25dOnV2888());
}
try{installScene25dV2888();}catch(e){console.warn('2.5D 场景安装失败',e);}

// END SCENE25D_V2888

// BEGIN BATTLE25D_V2889
'use strict';
// V2889 · 2.5D battle stage and clearer battle feedback. Presentation only: never writes gameplay state,
// never changes damage, turns or rewards. Pure CSS / inline SVG / DOM, no image files, no animation loop.
// Regular battles: region-matched layered backdrop with perspective floor, pedestals and depth for the fighters,
// pointer + impact parallax, hit / crit / dodge / heal bursts, readable damage numbers, tweened HP/MP bars with a
// damage "chip", a turn cue and phone-friendly skill buttons. 镇岳台 (V2887): stage, tweened bars, damage floats.
// Off switch: 战斗设置 → 立体战场, or localStorage 'xiantu_battle25d_v2889' = 'off'. Reduced motion is respected.
const BATTLE25D_V2889={
 key:'xiantu_battle25d_v2889',
 fxMax:6,fxLife:900,kickMs:240,
 regions:{                       // sky top, sky bottom, far ridge, near ridge, floor, mist
  south:['#2b4a52','#c9b98d','#6f8a70','#3d5a45','#4e6a49','255,246,220'],
  east:['#23434a','#a9c8b4','#5d8a78','#2f5446','#3f6352','230,250,240'],
  west:['#4a3a35','#d0a878','#8a7058','#54412f','#6b5641','255,236,210'],
  north:['#33485a','#d9e6ec','#9fb3b7','#5c7276','#7d9093','240,248,255'],
  human_peaks:['#334452','#c8c6a6','#7d8a70','#45573f','#5a6a4c','250,248,230'],
  human_valleys:['#2d4a45','#bcc89a','#6f8f62','#3e5a3a','#55704a','245,250,225'],
  demon_domain:['#1b1220','#6b3048','#4a2a3c','#2a1622','#3a2230','230,170,200'],
  immortal_domain:['#3c3a66','#f3dfa8','#a99bc8','#6e6496','#8a7fae','255,244,220']
 },
 tier:{boss:'rgba(255,70,60,.20)',tribulation:'rgba(140,170,255,.26)',elite:'rgba(255,214,90,.14)',normal:'rgba(0,0,0,0)'},
 dodge:/闪避(?:了|成功)|(?:躲过|躲开|避开)了.*(?:攻击|一击)|攻击未能命中/,
 block:/格挡了|抵挡下|挡下了|护盾吸收了/,
 elements:{fire:'#ff9348',ice:'#9fe8ff',thunder:'#efe88f',heal:'#84ffd0',sword:'#dce9ff',wood:'#9be27d',earth:'#d9b77a',water:'#7fc4ff'}
};
const B25_V2889={meters:new Map(),meterOwner:null,fx:[],kickTimer:0,pointerRaf:0,xy:[0,0],boss:new Map(),bossBefore:null,tasks:new Map(),epoch:0,owner:null,foe:null,lifecycle:false};

// ------------------------------------------------------------------ switches ----
let battle25dEnabledV2889=true;try{battle25dEnabledV2889=localStorage.getItem(BATTLE25D_V2889.key)!=='off';}catch(_){}
function battle25dOnV2889(){return battle25dEnabledV2889;}
function battle25dCalmV2889(){try{return !!window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;}catch(_){return false;}}
function setBattle25dV2889(on){
 on=!!on;battle25dEnabledV2889=on;b25ClearV2889();
 try{on?localStorage.removeItem(BATTLE25D_V2889.key):localStorage.setItem(BATTLE25D_V2889.key,'off');}catch(_){}
 b25SyncV2889(true);if(on)b25BossStageV2889();else{const h=document.getElementById('bossFightV2887');h?.classList.remove('b25-boss-v2889');for(const e of h?.querySelectorAll('.b25-stage-v2889, .b25-fx-v2889')||[])e.remove();}return on;
}
function b25HashV2889(t){let h=2166136261;for(const c of String(t))h=Math.imul(h^c.codePointAt(0),16777619);return h>>>0;}
function b25RandV2889(seed){let s=(seed>>>0)||7;return()=>((s=Math.imul(s^s>>>15,1|s)+0x6D2B79F5|0,(s^s>>>7)>>>0)%100000)/100000;}
function b25ChildV2889(el,cls){return el?[...el.children].find(c=>c.classList?.contains(cls))||null:null;}
function b25RegionV2889(){try{return currentRegion||player?.worldMapId||'south';}catch(_){return 'south';}}
function b25InBattleV2889(){try{return !!currentEnemy&&(gameState==='combat'||gameState==='combat-ending');}catch(_){return false;}}
function b25TierV2889(){try{return isTribulation?'tribulation':isBossFight?'boss':currentEnemy?._isElite?'elite':'normal';}catch(_){return 'normal';}}
function b25DuelV2889(){return !!document.getElementById('combatArena')?.classList.contains('duel25-active');}

function b25ScheduleV2889(fn,delay,frame){
 const epoch=B25_V2889.epoch,owner=player;
 const cb=()=>{B25_V2889.tasks.delete(id);if(epoch===B25_V2889.epoch&&owner===player&&!document.hidden&&battle25dOnV2889())fn();};
 const id=frame?requestAnimationFrame(cb):setTimeout(cb,delay);B25_V2889.tasks.set(id,frame);return id;
}
function b25LaterV2889(fn,delay){return b25ScheduleV2889(fn,delay,false);}
function b25FrameV2889(fn){return b25ScheduleV2889(fn,0,true);}
function b25CancelV2889(id){if(B25_V2889.tasks.get(id))cancelAnimationFrame(id);else clearTimeout(id);B25_V2889.tasks.delete(id);}
function b25ResetPointerV2889(){
 b25CancelV2889(B25_V2889.pointerRaf);B25_V2889.pointerRaf=0;
 const a=document.getElementById('combatArena');if(a){a.style.setProperty('--b25x','0');a.style.setProperty('--b25y','0');}
}
function b25ClearV2889(){
 B25_V2889.epoch++;for(const id of B25_V2889.tasks.keys())b25CancelV2889(id);
 B25_V2889.fx=[];B25_V2889.kickTimer=0;b25ResetPointerV2889();B25_V2889.meters.clear();B25_V2889.boss.clear();B25_V2889.meterOwner=null;
 for(const e of document.querySelectorAll('.b25-burst-v2889, .b25-chip-v2889'))e.remove();
 for(const id of ['combatArena','bossFightV2887']){const e=document.getElementById(id);if(e){e.style.setProperty('--b25-kick','0');e.classList.remove('b25-quake-v2889');}}
}
// ------------------------------------------------------------------ stage ----
function b25RidgeV2889(r,base,amp,step){let d=`M0 100 L0 ${base}`;for(let x=0;x<=400;x+=step)d+=` L${x} ${(base-amp*(.3+.7*r())).toFixed(1)}`;return d+' L400 100 Z';}
function b25StageHtmlV2889(region,tier,seed){
 const C=BATTLE25D_V2889,p=C.regions[region]||C.regions.south,r=b25RandV2889(seed);
 const svg=(d,body)=>`<div class="b25-layer-v2889" style="--d:${d}"><svg viewBox="0 0 400 100" preserveAspectRatio="none" focusable="false">${body}</svg></div>`;
 return `<div class="b25-sky-v2889" style="background:linear-gradient(180deg,${p[0]},${p[1]})"></div>`
  +`<div class="b25-glow-v2889" style="left:${Math.round(18+r()*55)}%"></div>`
  +svg(.12,`<path d="${b25RidgeV2889(r,52,34,22)}" fill="${p[2]}" opacity=".75"/>`)
  +`<div class="b25-mist-v2889" style="--m:rgba(${p[5]},.30)"></div>`
  +svg(.3,`<path d="${b25RidgeV2889(r,70,22,16)}" fill="${p[3]}"/>`)
  +`<div class="b25-floor-v2889" style="--floor:${p[4]}"><i></i></div>`
  +`<div class="b25-tier-v2889" style="background:radial-gradient(ellipse at 70% 40%,${C.tier[tier]||C.tier.normal},transparent 65%)"></div>`
  +svg(.55,`<path d="M0 100 L0 ${88+r()*6} Q40 ${80+r()*8} 70 ${90+r()*6} L120 100 Z M310 100 Q340 ${82+r()*6} 400 ${84+r()*8} L400 100Z" fill="rgba(8,12,10,.82)"/>`)
  +'<div class="b25-vignette-v2889"></div>';
}
function b25EnsureStageV2889(){
 const arena=document.getElementById('combatArena'),panel=document.getElementById('combatPanel');if(!arena||!panel)return null;
 const on=battle25dOnV2889()&&b25InBattleV2889()&&!b25DuelV2889();
 panel.classList.toggle('b25-on-v2889',on);
 let stage=arena.querySelector('.b25-stage-v2889');
 if(!on){b25ClearV2889();stage?.remove();for(const el of arena.querySelectorAll('.b25-pedestal-v2889, .b25-fx-v2889, .b25-marker-v2889'))el.remove();return null;}
 const region=b25RegionV2889(),tier=b25TierV2889(),key=`${region}|${tier}|${currentEnemy?.name||''}`;
 if(!stage){stage=document.createElement('div');stage.className='b25-stage-v2889';stage.setAttribute('aria-hidden','true');arena.prepend(stage);}
 if(stage.dataset.key!==key){stage.dataset.key=key;stage.dataset.region=region;stage.dataset.tier=tier;stage.innerHTML=b25StageHtmlV2889(region,tier,b25HashV2889(key));}
 for(const id of ['playerCombatant','enemyCombatant']){
  const c=document.getElementById(id);if(c&&!b25ChildV2889(c,'b25-pedestal-v2889')){const p=document.createElement('div');p.className='b25-pedestal-v2889';p.setAttribute('aria-hidden','true');c.prepend(p);}
  if(c&&!b25ChildV2889(c,'b25-marker-v2889')){const m=document.createElement('div');m.className='b25-marker-v2889';m.setAttribute('aria-hidden','true');c.appendChild(m);}
 }
 if(!arena.querySelector('.b25-fx-v2889')){const fx=document.createElement('div');fx.className='b25-fx-v2889';fx.setAttribute('aria-hidden','true');arena.appendChild(fx);}
 return stage;
}

// ------------------------------------------------------------------ turn cue ----
function b25TurnV2889(){
 try{if(!b25InBattleV2889()||gameState==='combat-ending')return 'end';return isPlayerTurn?'player':'enemy';}catch(_){return 'end';}
}
function b25SyncTurnV2889(force){
 const panel=document.getElementById('combatPanel');if(!panel)return;
 const turn=b25TurnV2889();if(!force&&panel.dataset.b25Turn===turn)return;
 panel.dataset.b25Turn=turn;
}

// ------------------------------------------------------------------ bars: tween + damage chip ----
function b25MetersV2889(){
 const status=document.getElementById('battleVitalsV286816');if(!status||!battle25dOnV2889()||document.hidden)return;
 if(B25_V2889.meterOwner!==currentEnemy){B25_V2889.meterOwner=currentEnemy;B25_V2889.meters.clear();}
 const calm=battle25dCalmV2889();
 [...status.children].forEach((side,si)=>{
  for(const m of side.querySelectorAll('.battle-meter-v286816')){
   const fill=m.querySelector('i');if(!fill||fill.dataset.b25)continue;
   fill.dataset.b25='1';
   const cls=String(m.className||'').split(/\s+/).find(c=>c&&c!=='battle-meter-v286816')||'x',key=si+':'+cls;
   const to=parseFloat(fill.style.width)||0,from=B25_V2889.meters.has(key)?B25_V2889.meters.get(key):to;
   B25_V2889.meters.set(key,to);
   if(calm||Math.abs(to-from)<.05)continue;
   const chip=document.createElement('u');chip.className='b25-chip-v2889 '+(to<from?'loss':'gain');chip.style.width=Math.max(from,to)+'%';m.prepend(chip);
   fill.style.transition='none';fill.style.width=from+'%';void fill.offsetWidth;
   fill.style.transition='';fill.style.width=to+'%';
   b25FrameV2889(()=>b25FrameV2889(()=>{chip.style.width=to+'%';}));
   b25LaterV2889(()=>chip.remove(),1100);
  }
 });
}

// ------------------------------------------------------------------ feedback bursts ----
function b25FxV2889(kind,side,text=''){
 if(!battle25dOnV2889()||document.hidden||b25DuelV2889())return null;
 const layer=document.getElementById('combatArena')?.querySelector('.b25-fx-v2889');if(!layer)return null;
 while(B25_V2889.fx.length>=BATTLE25D_V2889.fxMax){const old=B25_V2889.fx.shift();b25CancelV2889(old.timer);old.el.remove();}
 const el=document.createElement('div');el.className=`b25-burst-v2889 ${kind} at-${side==='enemy'?'enemy':'player'}`;
 if(text){const b=document.createElement('b');b.textContent=text;el.appendChild(b);}
 layer.appendChild(el);
 const rec={el,timer:b25LaterV2889(()=>{el.remove();B25_V2889.fx=B25_V2889.fx.filter(x=>x!==rec);},BATTLE25D_V2889.fxLife)};B25_V2889.fx.push(rec);
 return el;
}
function b25KickV2889(side,strong){
 const arena=document.getElementById('combatArena');if(!arena||document.hidden||b25DuelV2889()||battle25dCalmV2889()||!battle25dOnV2889())return;
 arena.style.setProperty('--b25-kick',String((side==='enemy'?-1:1)*(strong?1.6:1)));
 arena.classList.toggle('b25-quake-v2889',!!strong);
 b25CancelV2889(B25_V2889.kickTimer);
 B25_V2889.kickTimer=b25LaterV2889(()=>{arena.style.setProperty('--b25-kick','0');arena.classList.remove('b25-quake-v2889');},BATTLE25D_V2889.kickMs);
}
function b25ClassifyLogV2889(text){
 const t=String(text||'').replace(/<[^>]*>/g,'');
 if(BATTLE25D_V2889.dodge.test(t))return 'dodge';
 if(BATTLE25D_V2889.block.test(t))return 'block';
 return null;
}

// ------------------------------------------------------------------ skill buttons ----
function b25ButtonsV2889(){
 const box=document.getElementById('combatChoices');if(!box||!battle25dOnV2889())return;
 for(const b of box.querySelectorAll('button')){
  const m=/^combat\(\s*'skill'\s*,\s*(\d+)\s*\)/.exec(b.getAttribute('onclick')||'');
  if(!m){if(/^combat\(\s*'attack'/.test(b.getAttribute('onclick')||''))b.dataset.b25El='strike';continue;}
  const s=player?.skills?.[Number(m[1])];if(!s)continue;
  b.dataset.b25El=BATTLE25D_V2889.elements[s.element]?s.element:'sword';
  const short=Number(s.mpCost)>Number(player.mp);
  if(short)b.dataset.b25Why=`灵力差 ${Math.ceil(Number(s.mpCost)-Number(player.mp))}`;else delete b.dataset.b25Why;
 }
}

// ------------------------------------------------------------------ one sync for everything ----
function b25SyncV2889(force=false){
 try{
  if(B25_V2889.owner!==player||B25_V2889.foe!==currentEnemy){b25ClearV2889();B25_V2889.owner=player;B25_V2889.foe=currentEnemy;}
  const stage=b25EnsureStageV2889();
  if(stage||force)b25SyncTurnV2889(force);
  if(stage){b25MetersV2889();b25ButtonsV2889();b25ToggleV2889();}
 }catch(e){console.warn('立体战场同步失败',e);}
}
function b25WrapV2889(name,after,before){
 const base=window[name];if(typeof base!=='function'||base._b25V2889)return;
 const w=function(...args){
  let pre;try{if(before)pre=before.apply(this,args);}catch(e){console.warn('立体战场',name,e);}
  const r=w._baseV2889.apply(this,args);              // looked up on call, so a test can swap the base
  try{if(after)after.call(this,args,r,pre);}catch(e){console.warn('立体战场',name,e);}
  return r;
 };
 w._b25V2889=true;w._baseV2889=base;window[name]=w;
}

// ------------------------------------------------------------------ regular battle hooks ----
function installBattle25dV2889(){
 if(B25_V2889.lifecycle)return;B25_V2889.lifecycle=true;
 for(const n of ['resetRuntimeState','endCombatAfterCapture','startCombat','showStory'])b25WrapV2889(n,()=>b25SyncV2889(),()=>b25ClearV2889());
 document.addEventListener('visibilitychange',()=>{if(document.hidden)b25ClearV2889();else b25SyncV2889(true);});
 window.addEventListener('pagehide',b25ClearV2889);
 window.addEventListener('storage',e=>{if(e.key===BATTLE25D_V2889.key||e.key===null)setBattle25dV2889(e.key===null||e.newValue!=='off');});
 window.matchMedia?.('(prefers-reduced-motion: reduce)')?.addEventListener?.('change',b25ClearV2889);
 for(const n of ['pointerup','pointercancel','pointerleave'])document.addEventListener(n,b25ResetPointerV2889,{passive:true});
 for(const n of ['startCombat','updateCombatUI','updateCombatChoices','combat','checkBattleEnd','useCombatBagItem','completeCombatFinishV2764'])b25WrapV2889(n,()=>b25SyncV2889());
 b25WrapV2889('enemyTurn',()=>b25SyncV2889(),()=>{const p=document.getElementById('combatPanel');if(p&&battle25dOnV2889())p.dataset.b25Turn='enemy';});
 b25WrapV2889('playHitEffect',([target])=>{if(!b25InBattleV2889())return;b25FxV2889('hit',target);b25KickV2889(target,false);});
 b25WrapV2889('showDamageNumber',([damage,target,isHeal,isCrit])=>{
  if(!b25InBattleV2889()||!Number.isFinite(Number(damage)))return;
  if(isHeal){b25FxV2889('heal',target);return;}
  if(isCrit){b25FxV2889('crit',target,'暴击');b25KickV2889(target,true);}
 });
 b25WrapV2889('addCombatLog',([text])=>{
  if(!b25InBattleV2889())return;const k=b25ClassifyLogV2889(text);if(!k)return;
  let side='player';try{side=isPlayerTurn?'enemy':'player';}catch(_){}
  b25FxV2889(k,side,k==='dodge'?'闪避':'格挡');
 });
 const arena=()=>document.getElementById('combatArena');
 document.addEventListener('pointermove',e=>{
  const a=arena();if(!a||!a.contains(e.target)||document.hidden||b25DuelV2889()||!b25InBattleV2889()||battle25dCalmV2889()||!battle25dOnV2889()||(e.pointerType==='touch'&&!e.buttons)){b25ResetPointerV2889();return;}
  const b=a.getBoundingClientRect();B25_V2889.xy=[Math.max(-1,Math.min(1,(e.clientX-b.left)/Math.max(1,b.width)*2-1)),Math.max(-1,Math.min(1,(e.clientY-b.top)/Math.max(1,b.height)*2-1))];
  if(B25_V2889.pointerRaf)return;
  B25_V2889.pointerRaf=b25FrameV2889(()=>{B25_V2889.pointerRaf=0;const x=arena();if(!x)return;x.style.setProperty('--b25x',B25_V2889.xy[0].toFixed(3));x.style.setProperty('--b25y',B25_V2889.xy[1].toFixed(3));});
 },{passive:true});
 }
// the off switch lives in the existing 战斗设置 drawer
function b25ToggleV2889(){
 const box=document.getElementById('battleSettingsV286816');if(!box||box.querySelector('[data-b25-toggle]'))return;
 const b=document.createElement('button');b.type='button';b.className='choice-btn';b.setAttribute('data-b25-toggle','1');
 const label=()=>{const on=battle25dOnV2889();b.textContent=on?'立体战场：开':'立体战场：关';b.setAttribute('aria-pressed',String(on));};label();
 b.addEventListener('click',()=>{setBattle25dV2889(!battle25dOnV2889());label();});box.appendChild(b);
}

// ------------------------------------------------------------------ 镇岳台 (V2887) ----
function b25BossStageV2889(){
 const host=document.getElementById('bossFightV2887');if(!host||!battle25dOnV2889())return null;
 if(b25ChildV2889(host,'b25-stage-v2889'))return host;
 const F=typeof bossPeekV2887==='function'?bossPeekV2887().fight:null;
 const ph=F&&typeof BOSS_V2887!=='undefined'?BOSS_V2887.bosses[F.id]?.phases?.[F.phase-1]:null;
 host.classList.add('b25-boss-v2889');
 const stage=document.createElement('div');stage.className='b25-stage-v2889';stage.setAttribute('aria-hidden','true');
 const region=F?.phase===3?'demon_domain':F?.phase===2?'immortal_domain':'north';
 stage.innerHTML=b25StageHtmlV2889(region,'boss',b25HashV2889('boss'+(F?.phase||1)));
 if(ph?.accent)stage.style.setProperty('--b25-accent',ph.accent);
 host.prepend(stage);
 const fx=document.createElement('div');fx.className='b25-fx-v2889';fx.setAttribute('aria-hidden','true');host.appendChild(fx);
 return host;
}
function b25BossBarsV2889(){
 const host=document.getElementById('bossFightV2887');if(!host||document.hidden||!battle25dOnV2889()||battle25dCalmV2889())return;
 const bars=[...host.querySelectorAll('[role="meter"]')];
 bars.forEach((bar,i)=>{
  const now=Number(bar.getAttribute('aria-valuenow'));const fill=bar.querySelector('span');if(!Number.isFinite(now)||!fill)return;
  const key=String(i),from=B25_V2889.boss.has(key)?B25_V2889.boss.get(key):now;B25_V2889.boss.set(key,now);
  if(Math.abs(from-now)<.5)return;
  const target=fill.style.width;fill.style.transition='none';fill.style.width=from+'%';void fill.offsetWidth;fill.style.transition='width .45s cubic-bezier(.2,.8,.2,1)';fill.style.width=target;
  if(now<from){const chip=document.createElement('u');chip.className='b25-chip-v2889 loss';chip.style.width=from+'%';bar.style.position='relative';bar.prepend(chip);b25FrameV2889(()=>b25FrameV2889(()=>{chip.style.width=now+'%';}));b25LaterV2889(()=>chip.remove(),1100);}
 });
}
function b25BossFloatV2889(host,side,text,kind){
 const layer=b25ChildV2889(host,'b25-fx-v2889');if(!layer||document.hidden||!battle25dOnV2889())return;
 const el=document.createElement('div');el.className=`b25-burst-v2889 ${kind} at-${side}`;const b=document.createElement('b');b.textContent=text;el.appendChild(b);layer.appendChild(el);
 b25LaterV2889(()=>el.remove(),BATTLE25D_V2889.fxLife);
}
function installBoss25dV2889(){
 b25WrapV2889('showBossFightV2887',()=>{const h=b25BossStageV2889();if(h)b25BossBarsV2889();});
 b25WrapV2889('showBossAltarV2887',()=>{B25_V2889.boss.clear();});
 b25WrapV2889('bossActV2887',([action],ok,before)=>{
  if(!ok||!before||!battle25dOnV2889())return;
  const F=typeof bossPeekV2887==='function'?bossPeekV2887().fight:null,host=document.getElementById('bossFightV2887');if(!F||!host)return;
  const dealt=before.bossHp-Math.max(0,F.bossHp),taken=before.hp-F.hp;
  if(dealt>0)b25BossFloatV2889(host,'enemy','-'+Math.round(dealt),'hit');
  if(taken>0)b25BossFloatV2889(host,'player','-'+Math.round(taken),'hit');
  if(taken<0)b25BossFloatV2889(host,'player','+'+Math.round(-taken),'heal');
  if(action==='evade'&&taken<=0&&before.canEvade&&!F.over)b25BossFloatV2889(host,'player','避开','dodge');
  if(action==='guard'&&taken>0&&before.canGuard)b25BossFloatV2889(host,'player','守势','block');
  if(dealt>0||taken>0)b25KickBossV2889(host,dealt>=taken?'enemy':'player');
 },()=>{const F=typeof bossPeekV2887==='function'?bossPeekV2887().fight:null;if(!F)return null;const it=F.intent,d=it?.stage==='release'?BOSS_V2887.bosses[F.id].skills[it.skill]?.release:it?.stage==='act'?BOSS_V2887.bosses[F.id].skills[it.skill]:null;return {bossHp:Math.max(0,F.bossHp),hp:F.hp,canEvade:!!d?.evadable&&it.read!=='evade',canGuard:!!d&&d.guard<1&&it.read!=='guard'};});
}
function b25KickBossV2889(host,side){
 if(document.hidden||!battle25dOnV2889()||battle25dCalmV2889())return;host.style.setProperty('--b25-kick',side==='enemy'?'-1':'1');b25LaterV2889(()=>host.style.setProperty('--b25-kick','0'),BATTLE25D_V2889.kickMs);
}

// ------------------------------------------------------------------ styles ----
function installBattleStylesV2889(){
 if(document.getElementById('battle25dStyleV2889'))return;
 const st=document.createElement('style');st.id='battle25dStyleV2889';
 const P='html body #combatPanel.b25-on-v2889';
 st.textContent=`
${P} #combatArena{isolation:isolate;--b25x:0;--b25y:0;--b25-kick:0;background:#10161a}
${P} #combatArena.duel25-active .b25-stage-v2889,${P} #combatArena.duel25-active .b25-pedestal-v2889,${P} #combatArena.duel25-active .b25-marker-v2889{display:none}
.b25-stage-v2889{position:absolute;inset:0;z-index:-1;overflow:hidden;border-radius:inherit;pointer-events:none;contain:paint}
.b25-stage-v2889>*{position:absolute;inset:0}
.b25-sky-v2889{transform:translate3d(calc(var(--b25x) * -2px),0,0)}
.b25-glow-v2889{inset:auto;top:8%;width:90px;height:90px;margin-left:-45px;border-radius:50%;background:radial-gradient(circle,rgba(255,248,214,.85),rgba(255,236,170,.25) 35%,transparent 70%);opacity:.75}
.b25-layer-v2889{top:auto;height:62%;bottom:24%;left:-6%;right:-6%;transform:translate3d(calc((var(--b25x) * -10px - var(--b25-kick) * 6px) * var(--d)),calc(var(--b25y) * var(--d) * -4px),0);transition:transform .22s ease-out}
.b25-layer-v2889:last-of-type{bottom:0;height:34%}
.b25-layer-v2889 svg{width:100%;height:100%;display:block}
.b25-mist-v2889{top:38%;bottom:30%;left:-15%;right:-15%;background:radial-gradient(ellipse 35% 45% at 25% 50%,var(--m),transparent 70%),radial-gradient(ellipse 30% 40% at 72% 55%,var(--m),transparent 70%);animation:b25MistV2889 26s ease-in-out infinite alternate}
.b25-floor-v2889{top:auto;height:38%;bottom:0;perspective:220px;perspective-origin:50% 0}
.b25-floor-v2889 i{position:absolute;left:-60%;right:-60%;top:0;bottom:-40%;transform:rotateX(58deg) translate3d(calc(var(--b25x) * -18px - var(--b25-kick) * 10px),0,0);transform-origin:50% 0;transition:transform .22s ease-out;background:linear-gradient(180deg,rgba(0,0,0,.18),rgba(0,0,0,.55)),repeating-linear-gradient(90deg,rgba(255,255,255,.07) 0 1px,transparent 1px 42px),repeating-linear-gradient(0deg,rgba(255,255,255,.05) 0 1px,transparent 1px 30px),var(--floor)}
.b25-tier-v2889{mix-blend-mode:screen}
.b25-vignette-v2889{background:radial-gradient(ellipse at 50% 45%,transparent 45%,rgba(0,0,0,.55) 100%),linear-gradient(180deg,rgba(0,0,0,.25),transparent 25%)}
@keyframes b25MistV2889{from{transform:translateX(-4%)}to{transform:translateX(4%)}}
${P} #combatArena>.combatant{position:relative}
${P} .b25-pedestal-v2889{position:absolute;left:50%;bottom:34px;width:118px;height:30px;margin-left:-59px;border-radius:50%;background:radial-gradient(closest-side,rgba(0,0,0,.6),rgba(0,0,0,.25) 60%,transparent);z-index:-1;pointer-events:none}
${P} .b25-pedestal-v2889::after{content:"";position:absolute;inset:-4px -8px;border-radius:50%;border:2px solid transparent;opacity:0;transition:opacity .25s,border-color .25s}
${P}[data-b25-turn="player"] #playerCombatant .b25-pedestal-v2889::after{border-color:rgba(127,220,255,.75);opacity:1;box-shadow:0 0 18px rgba(127,220,255,.45)}
${P}[data-b25-turn="enemy"] #enemyCombatant .b25-pedestal-v2889::after{border-color:rgba(255,120,110,.75);opacity:1;box-shadow:0 0 18px rgba(255,110,100,.45)}
${P} #playerCombatant .combatant-avatar{scale:1.05;translate:0 6px;filter:drop-shadow(-3px 6px 4px rgba(0,0,0,.45)) drop-shadow(0 0 1px rgba(255,255,255,.35))}
${P} #enemyCombatant .combatant-avatar{scale:.95;translate:0 -4px;filter:drop-shadow(-3px 6px 4px rgba(0,0,0,.5)) drop-shadow(0 0 1px rgba(255,220,200,.3))}
${P} .vs-text{opacity:.35}
${P} .b25-marker-v2889{position:absolute;left:50%;top:-4px;width:14px;height:14px;margin-left:-7px;rotate:45deg;border-radius:3px;opacity:0;pointer-events:none;transition:opacity .2s;z-index:3}
${P}[data-b25-turn="player"] #playerCombatant .b25-marker-v2889{opacity:1;background:#7fdcff;box-shadow:0 0 12px #7fdcff;animation:b25BobV2889 1.2s ease-in-out infinite}
${P}[data-b25-turn="enemy"] #enemyCombatant .b25-marker-v2889{opacity:1;background:#ff7c70;box-shadow:0 0 12px #ff7c70;animation:b25BobV2889 1.2s ease-in-out infinite}
@keyframes b25BobV2889{50%{translate:0 -4px}}
${P}[data-b25-turn="player"] #battleReadoutV2856{box-shadow:inset 4px 0 0 #7fdcff}
${P}[data-b25-turn="enemy"] #battleReadoutV2856{box-shadow:inset 4px 0 0 #ff7c70}
.b25-fx-v2889{position:absolute;inset:0;z-index:60;pointer-events:none;overflow:hidden}
.b25-burst-v2889{position:absolute;top:44%;width:120px;height:120px;margin:-60px 0 0 -60px}
.b25-burst-v2889::before{content:"";position:absolute;inset:0;border-radius:50%;animation:b25BurstV2889 .55s ease-out forwards}
.b25-burst-v2889.at-player{left:24%}.b25-burst-v2889.at-enemy{left:76%}
.b25-burst-v2889.hit::before{background:radial-gradient(circle,rgba(255,255,255,.75),rgba(255,210,150,.35) 30%,transparent 62%)}
.b25-burst-v2889.crit{width:170px;height:170px;margin:-85px 0 0 -85px}
.b25-burst-v2889.crit::before{background:repeating-conic-gradient(from 0deg,rgba(255,221,96,.85) 0 6deg,transparent 6deg 24deg),radial-gradient(circle,rgba(255,250,220,.95),transparent 55%);-webkit-mask:radial-gradient(circle,#000 30%,transparent 70%);mask:radial-gradient(circle,#000 30%,transparent 70%)}
.b25-burst-v2889.heal::before{background:radial-gradient(circle,rgba(132,255,208,.65),transparent 62%)}
.b25-burst-v2889.dodge::before,.b25-burst-v2889.block::before{border:2px dashed rgba(180,230,255,.75);animation-duration:.7s}
.b25-burst-v2889.block::before{border-style:solid;border-color:rgba(255,230,150,.8)}
.b25-burst-v2889 b{position:absolute;left:50%;top:50%;translate:-50% -50%;font-size:20px;font-weight:900;color:#fff;white-space:nowrap;-webkit-text-stroke:1px rgba(0,0,0,.6);text-shadow:0 3px 0 rgba(0,0,0,.45),0 0 12px rgba(255,255,255,.4);animation:b25RiseV2889 .9s ease-out forwards}
.b25-burst-v2889.crit b{font-size:22px;color:#ffe26b}
@keyframes b25BurstV2889{0%{transform:scale(.35);opacity:0}25%{opacity:1}100%{transform:scale(1.15);opacity:0}}
@keyframes b25RiseV2889{0%{translate:-50% -20%;scale:.7;opacity:0}15%{scale:1.15;opacity:1}75%{opacity:1}100%{translate:-50% -140%;scale:1;opacity:0}}
#combatArena.b25-quake-v2889 .b25-stage-v2889{animation:b25QuakeV2889 .24s linear}
@keyframes b25QuakeV2889{25%{transform:translate(3px,-2px)}50%{transform:translate(-3px,2px)}75%{transform:translate(2px,1px)}}
${P} #combatArena .combat-values-v2817 .damage-number{top:calc(30% + var(--value-stack)*48px);background:linear-gradient(180deg,rgba(14,18,24,.86),rgba(14,18,24,.62));border:1px solid rgba(255,255,255,.18);box-shadow:0 8px 18px rgba(0,0,0,.45),inset 0 1px 0 rgba(255,255,255,.15)}
${P} #combatArena .combat-value-number-v2817{-webkit-text-stroke:.6px rgba(0,0,0,.55);text-shadow:0 2px 0 rgba(0,0,0,.5)}
${P} #combatArena .combat-values-v2817 .crit{border-color:rgba(255,214,90,.8);box-shadow:0 0 22px rgba(255,214,90,.45),0 8px 18px rgba(0,0,0,.45)}
@media(max-width:640px){${P} #combatArena .combat-values-v2817 .damage-number{top:calc(34% + var(--value-stack)*46px)}}
${P} .battle-meter-v286816{position:relative;overflow:hidden}
${P} .battle-meter-v286816 i{position:relative;z-index:1;transition:width .45s cubic-bezier(.2,.8,.2,1)}
.b25-chip-v2889{position:absolute;left:0;top:0;bottom:0;z-index:0;transition:width .7s ease-in .3s;text-decoration:none}
.b25-chip-v2889.loss{background:rgba(255,236,200,.9)}.b25-chip-v2889.gain{background:rgba(132,255,208,.55);transition:none}
${P} #combatChoices button[data-b25-el]{position:relative;min-height:52px;border-top:3px solid var(--b25-el,#dce9ff)!important;box-shadow:0 6px 14px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.12);transition:scale .08s ease-out}
${P} #combatChoices button[data-b25-el]:active:not(:disabled){scale:.97}
${P} #combatChoices button[data-b25-el="fire"]{--b25-el:#ff9348}${P} #combatChoices button[data-b25-el="ice"]{--b25-el:#9fe8ff}${P} #combatChoices button[data-b25-el="thunder"]{--b25-el:#efe88f}
${P} #combatChoices button[data-b25-el="heal"]{--b25-el:#84ffd0}${P} #combatChoices button[data-b25-el="strike"]{--b25-el:#ffd98a}${P} #combatChoices button[data-b25-el="wood"]{--b25-el:#9be27d}
${P} #combatChoices button[data-b25-why]::after{content:attr(data-b25-why);display:block;margin-top:3px;font-size:10px;padding:1px 6px;border-radius:8px;background:rgba(120,140,200,.25);color:#cfe0ff}
${P}[data-b25-turn="enemy"] #combatChoices{opacity:.72}
#bossFightV2887.b25-boss-v2889{position:relative;overflow:hidden;isolation:isolate;--b25x:0;--b25y:0;--b25-kick:0}
#bossFightV2887.b25-boss-v2889>.b25-stage-v2889{z-index:-1;opacity:.55}
#bossFightV2887.b25-boss-v2889>:not(.b25-stage-v2889):not(.b25-fx-v2889){position:relative;z-index:1}
#bossFightV2887.b25-boss-v2889 .b25-burst-v2889{top:30%}
#bossFightV2887.b25-boss-v2889 .b25-burst-v2889 b{font-size:26px;color:#ffe26b}
#bossFightV2887.b25-boss-v2889 .b25-burst-v2889.at-player b{color:#ff9b8f}
#bossFightV2887.b25-boss-v2889 .b25-burst-v2889.heal b{color:#84ffd0}
#bossFightV2887.b25-boss-v2889 .b25-burst-v2889.dodge b,#bossFightV2887.b25-boss-v2889 .b25-burst-v2889.block b{color:#cfe8ff}
#bossFightV2887.b25-boss-v2889 [role="meter"]{position:relative;overflow:hidden}
#bossFightV2887.b25-boss-v2889 [role="meter"]>span{position:relative;z-index:1}
@media(max-width:600px){#storyText .choice-btn[onclick^="bossActV2887"]{min-height:52px;font-size:14px}}
.xiantu-v2762-page-hidden .b25-mist-v2889,.xiantu-v2762-page-hidden .b25-marker-v2889{animation-play-state:paused!important}
@media (prefers-reduced-motion: reduce){.b25-mist-v2889,.b25-burst-v2889::before,.b25-burst-v2889 b,.b25-marker-v2889,#combatArena.b25-quake-v2889 .b25-stage-v2889{animation:none!important}.b25-burst-v2889{opacity:.85}.b25-layer-v2889,.b25-floor-v2889 i,.b25-chip-v2889,${P} .battle-meter-v286816 i{transition:none!important}}
`;
 document.head.appendChild(st);
}

// ------------------------------------------------------------------ install ----
function installBattleAll25dV2889(){installBattleStylesV2889();installBattle25dV2889();installBoss25dV2889();}
try{installBattleAll25dV2889();}catch(e){console.warn('立体战场安装失败',e);}

// END BATTLE25D_V2889

// BEGIN GUIDE_V2890
// V28.68.64 修行指引：按主题分页、手机可读；数字尽量取自当前代码常量，读不到时用与 28.68.62 一致的默认值。
// 只改说明文字与指引面板，不改任何玩法与数值。依赖（均可缺省）：V2887 镇岳台、V2872/V2880 宗主、V2888 山河图立体、V2889 立体战场。
const GUIDE_V2890=Object.freeze({
 storeKey:'xiantu_guide_tab_v2890',
 tabs:['start','cultivate','combat','sect','boss','travel','items','save']
});
let guideTabV2890='start',guideOwnerV2890=null,guideOpenerV2890=null;
function guideJourneyReadV2890(){const raw=player?.firstJourneyV28687;return raw&&typeof raw==='object'?{...raw,step:Math.max(0,Math.min(5,Math.floor(Number(raw.step)||0)))}:null;}

function guideEscV2890(v){
 const s=String(v===undefined||v===null?'':v);
 return typeof escapeGameText==='function'?escapeGameText(s):s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function guideTryV2890(fn,fallback){try{const v=fn();return v===undefined||v===null||(typeof v==='number'&&!Number.isFinite(v))?fallback:v;}catch(_){return fallback;}}
function guideRealmV2890(i){
 const fb=['凡人','练气','筑基','金丹','元婴','化神','炼虚','合体','大乘','渡劫','地仙','天仙','金仙','太乙金仙','大罗金仙','准圣','圣人'];
 return guideTryV2890(()=>CULTIVATION_REALMS[i].name,fb[i]||'');
}
function guideStoreV2890(id){try{if(id)localStorage.setItem(GUIDE_V2890.storeKey,id);else return localStorage.getItem(GUIDE_V2890.storeKey);}catch(_){}return null;}

// 读取说明中用到的数字；每一项都有与当前版本一致的默认值。
function guideFactsV2890(){
 const f={};
 f.unlock=guideTryV2890(()=>({south:REGION_UNLOCK_LEVEL.south,east:REGION_UNLOCK_LEVEL.east,north:REGION_UNLOCK_LEVEL.north,west:REGION_UNLOCK_LEVEL.west}),{south:0,east:2,north:2,west:3});
 f.realms=guideTryV2890(()=>CULTIVATION_REALMS.map(r=>r.name),null)||Array.from({length:17},(_,i)=>guideRealmV2890(i));
 f.phases=guideTryV2890(()=>REALM_PHASES.slice(),['初期','中期','后期','圆满']);
 f.yearDays=guideTryV2890(()=>GAME_DAYS_PER_YEAR,360);
 f.monthDays=guideTryV2890(()=>GAME_DAYS_PER_MONTH,30);
 f.ranks=guideTryV2890(()=>SECT_RANKS.map(r=>({name:r.name,need:r.contributionRequired})),[{name:'外门弟子',need:0},{name:'内门弟子',need:100},{name:'真传弟子',need:300},{name:'长老',need:600},{name:'宗主',need:1000}]);
 f.master=guideTryV2890(()=>({realm:SECT_MASTER_RULES_V2872.realm,contribution:SECT_MASTER_RULES_V2872.contribution,tasks:SECT_MASTER_RULES_V2872.tasks}),{realm:4,contribution:1000,tasks:5});
 f.mentor=guideTryV2890(()=>MENTOR_V2892,null);
 f.council=guideTryV2890(()=>({...SECT_MASTER_COUNCIL_V2872}),{cooldown:30,repairContribution:100,repairGold:200,prosperityGain:5,lessonContribution:50});
 f.doctrines=guideTryV2890(()=>SECT_DOCTRINES_V2880.map(d=>({name:d.name,desc:d.desc})),[]);
 f.discipleCap={member:12,master:16};          // sectDiscipleCapV2880(): 宗主16，其余12
 const B=guideTryV2890(()=>BOSS_V2887,null);
 if(B){
  const Y=f.yearDays,start=guideTryV2890(()=>bossWindowStartV2887(),Math.min(B.window.openOffset,Y-B.window.days)),end=start+B.window.days-1;
  const md=d=>`${Math.floor(d/f.monthDays)+1}月${d%f.monthDays+1}日`;
  f.boss={
   from:md(start),to:md(end),days:B.window.days,maxRounds:B.maxRounds,defeatDays:B.defeatDays,bone:B.bone,
   tiers:B.tiers.map(t=>({id:t.id,realm:guideRealmV2890(t.minLevel),gold:t.gold,exp:t.exp,contribution:t.contribution,bones:t.bones})),
   minRealm:guideRealmV2890(B.tiers[0].minLevel),
   offering:{bones:B.offering.bones,locks:B.offering.locks},
   repeat:{gold:Math.round(B.repeat.gold*100),bones:B.repeat.bones},
   seal:{hp:Math.round(B.seal.missedHp*100),member:B.seal.memberCap,master:B.seal.missedCap,prosperity:B.seal.missedProsperity,reinforce:B.seal.reinforceBones,reinforceGain:B.seal.reinforceProsperity},
   masterHp:Math.round((B.masterHp-1)*100),
   aspects:B.aspectOrder.map(id=>({icon:B.aspects[id].icon,name:B.aspects[id].name,desc:B.aspects[id].desc})),
   boons:Object.values(B.boons).map(x=>({name:x.name,desc:x.desc})),
   names:B.actionNames
  };
 }else f.boss=null;
 return f;
}

// 依据当前角色给出至多三条“下一步”；任何一项读不到就跳过。
function guideNextStepsV2890(f){
 const out=[];
 const add=t=>{if(out.length<3&&t)out.push(t);};
 const p=typeof player==='object'&&player?player:null;if(!p)return out;
 guideTryV2890(()=>{const s=guideJourneyReadV2890();if((p.level||0)<2&&(!s||s.step<5))add('完成【初入仙途】五步引导：试手、穿戴、配功法、山道挑战、查看来信。');},0);
 guideTryV2890(()=>{if((Number(p.exp)||0)>=getCurrentExpNeed()&&!(p.breakthrough?.cooldownDays>0))add('修为已至瓶颈：可以尝试突破了（闭关不会自动破境）。');},0);
 guideTryV2890(()=>{if(p.breakthrough?.cooldownDays>0)add(`突破受挫，尚需调息 ${p.breakthrough.cooldownDays} 日；可在突破面板一次调息完毕。`);},0);
 guideTryV2890(()=>{if(!p.sect||p.sect==='散修')add('尚无宗门：主线【拜入宗门】会在练气后引你参加凌霄宗入门考核。');},0);
 guideTryV2890(()=>{if(!document.getElementById('tutorialUnlock')&&typeof bossEligibleV2887==='function'&&bossEligibleV2887()&&bossWindowV2887().open)add(`镇岳台封印松动中（余 ${bossWindowV2887().daysLeft} 天）：宗门大殿 → ⛰️ 镇岳台。`);},0);
 guideTryV2890(()=>{if(p.sect&&p.sect!=='散修'&&typeof sectMasterRequirementsV2872==='function'&&sectMasterRequirementsV2872().ready)add('宗主传承考核条件已齐：宗门大殿 → 👑 宗主传承考核，开始三试。');},0);
 if(!out.length)add((p.level|0)<1?'出门游历、清剿妖兽或闭关攒修为，踏入练气后再接宗门任务。':'接宗门任务稳攒修为、贡献与灵石；也可出门游历、清剿妖兽。');
 return out;
}

function guideSectionsV2890(){
 const f=guideFactsV2890(),e=guideEscV2890,u=f.unlock,R=i=>e(guideRealmV2890(i));
 const ul=items=>`<ul class="guide-list-v2890">${items.map(t=>`<li>${t}</li>`).join('')}</ul>`;
 const tip=t=>`<p class="guide-tip-v2890">${t}</p>`;
 const B=f.boss;
 return [
  {id:'start',icon:'🌅',tab:'起步',title:'初入仙途',html:()=>{
   const next=guideNextStepsV2890(f);
   return `<div class="guide-next-v2890" role="note"><b>此刻宜行</b>${ul(next.map(e))}</div>`
   +'<h4>三步上手</h4>'+ul([
    '<b>行走</b>：拖动左下摇杆，或轻点地面自动前往。走进地点外圈后，按右下【交互】进入。',
    '<b>初战</b>：角色 → 修行与设置中的【初入仙途】会带你走完五步：山脚试手 → 穿戴木剑 → 配置御剑术 → 山道挑战 → 查看来信。可随时收起，之后从本指引继续。',
    '<b>修行</b>：修为攒满瓶颈后尝试突破；踏入练气后接宗门任务，换取修为、贡献与灵石。'])
   +'<h4>常用入口</h4>'+ul([
    '<b>角色</b>：装备、功法、宗门待办；另有【修真造化之路】（四项一次性目标，旧角色达标也可补领）、【上一场战斗 · 回看】、【☯ 天机】参详推演。',
    '<b>探索</b>：小地图旁【探索】可展开【卷 山河图】与探索手册。',
    '<b>手机</b>：右上【☰】快捷菜单里有记档、存档管理、成就录、静音与本指引。'])
   +'<h4>仙历与寿元</h4>'+`<p>一年 ${f.yearDays} 日（${Math.round(f.yearDays/f.monthDays)} 月 × ${f.monthDays} 日）。修炼、闭关、调息、休息都会推着仙历前行，年岁随之增长。寿元将尽时，须突破大境界或服延寿丹。</p>`;
  }},
  {id:'cultivate',icon:'🧘',tab:'修炼',title:'修炼与突破',html:()=>
   `<p>大境界自 ${e(f.realms[0])} 起，依次为 ${e(f.realms.slice(1,11).join(' → '))} → ……直至${e(f.realms[f.realms.length-1])}。每个大境界又分<b>${e(f.phases.join('、'))}</b>四段。</p>`
   +'<h4>积攒修为</h4>'+ul([
    '宗门任务、战斗胜利、修炼与闭关都能增长修为。',
    '洞府【短期修炼】最多一年；【洞府闭关】与宗门闭关最多十年，洞府闭关另得家具的修为加成。',
    '闭关只把修为补到<b>当前小段的瓶颈</b>为止：修为一满即提前出关，绝不会自行破境；百年大比将开或寿元只剩一年时，也会提前出关。'])
   +'<h4>突破</h4>'+ul([
    '修为达到瓶颈即可尝试突破，<b>每次只进一段</b>：成功只扣去本段所需修为，余下的保留。',
    '成功率受境界、丹药、宗门与心境影响；南域仙市的稀有丹药中有破境丹可助一臂之力。',
    '失败会损失部分修为，并需调息若干日；可在突破面板一次调息完毕。',
    `${e(f.realms[9]||'渡劫')}圆满后，须亲手渡过<b>飞升天劫</b>（不可逃），方入${e(f.realms[10]||'地仙')}。`])
   +tip('寿元：突破大境界会提高寿元上限；三种延寿丹合计最多延寿 600 年，服用次数不因突破或读档重置。')
  },
  {id:'combat',icon:'⚔️',tab:'战斗',title:'战斗与功法',html:()=>
   ul([
    '<b>出手</b>：普通攻击命中可回些许灵力；功法消耗灵力，冰冻、灼烧、治疗等效果各有妙用。',
    '<b>携带功法</b>：每系最多携带 3 个，在【更换战斗技能】中配置；战斗技能栏默认收起，点系别即可展开。',
    '<b>丹药</b>：战斗中只能从【战斗背包】服用。',
    '<b>境界威压</b>：高境界对低境界有伤害优势；越级而战更险，胜了收益也更丰。'])
   +'<h4>脱身</h4>'+ul([
    '【逃跑】按钮会直接显示成功率（15%～95%），取决于身法速度与双方境界差。',
    '首领、天劫、宗门大比、正魔大战、宗门任务战与引导战不可逃。<b>神行符</b>只在允许逃跑的战斗中保证脱身，禁逃战斗也不能用符。'])
   +'<h4>看得清楚</h4>'+ul([
    '【🎬 动画演武】与【📜 简略战报】可随时切换；【详细战报】可展开查看每一笔数值。',
    '【战斗设置】里有【立体战场】开关：立体背景、命中/暴击/闪避特效、飘字与血条动画，<b>只改画面，不改数值</b>；系统开启“减少动态效果”时会自动收敛。',
    '战后简报可【回看本场战斗】，之后也能在角色面板【上一场战斗 · 回看】。'])
   +'<h4>灵宠</h4>'+ul([
    '把可收服的灵兽压到 <b>25% 气血及以下</b>，再用灵兽绳、缚灵玉、御灵葫芦等契具尝试收服；魔宠需魔缚索，神兽须结缘。',
    '东域灵兽谷可培养、选择出战灵宠；本指引底部的【🐾 灵宠完整指引】讲得更细。'])
  },
  {id:'sect',icon:'🏯',tab:'宗门',title:'宗门与宗主',html:()=>
   '<p>主线【拜入宗门】：练气之后，通过凌霄宗入门考核即可入门。宗门诸事都在<b>宗门大殿</b>：宗门任务、藏经阁（以贡献换功法）、贡献商店、贡献榜、正魔大战、宗门小秘境，以及【宗门总览 · 待办与晋升】。</p>'
   +'<h4>贡献与职位</h4>'
   +`<p>${f.ranks.map(r=>`<span class="help-tag">${e(r.name)} ${e(r.need)}</span>`).join('')}</p>`
   +'<p>职位看<b>累计贡献</b>；花掉可用贡献不会降低累计贡献或职位。</p>'
   +ul([
    `弟子事务：招募、培养、派遣门下弟子，最多 ${f.discipleCap.member} 人，宗主可收 ${f.discipleCap.master} 人。`,
    '百年宗门大比：前三的人类宗门获得本世纪进入<b>万宗秘境</b>的资格。'])
   +'<h4>正魔大战</h4>'+ul(['加入尚存宗门后，可从【三万年仙魔战 → 宗门会战】筹备出征；散修不能发起会战、邀请盟军或请求仙援。已有战史与军功仍保留。','邀请人族盟军每宗 30 贡献，可一键按战力优先邀请预算内的全部可邀宗门；仙援仍沿用成功 150、未回应 75 贡献。确认后才扣费，保存失败恢复本次操作。','每阶段先按公开敌情选择战术，再指挥联军或亲自交锋；军师布阵使用同一份公开敌情。奖励统一在战役结束发放，不新增递减或盟军分成。'])
   +'<h4>宗主之路</h4>'+ul([
    `<b>一 · 考核</b>：位至长老后，宗门大殿出现【👑 宗主传承考核】。须${R(f.master.realm)}境、累计贡献 ${e(f.master.contribution)}、完成 ${e(f.master.tasks)} 次宗门委托。`,
    '<b>二 · 三试</b>：问心（只记录决、仁、守的倾向）→ 守山（三种方案任选；布阵每次耗 100 贡献，失败也扣；失败需调息 3 日，不损境界与物品）→ 受印（择一种传承）。每步都会保存，可暂离续接。',
    `<b>三 · 立道统</b>：${f.doctrines.length?f.doctrines.map(d=>`${e(d.name)}（${e(d.desc)}）`).join('；'):'剑道、丹道、阵道三选一'}。立下后暂不可更改。`])
   +(f.mentor?`<h4>宗主亲传</h4><p>在弟子的【成长履历与后续】中，支出 ${f.mentor.goldBase}＋${f.mentor.goldPerLevel}×弟子等级灵石进行讲道、济危演练或寻幽推演。每名弟子每 ${f.mentor.cooldownDays} 个游戏日一次，各类最多 ${f.mentor.perKindCap} 次；讲道另升一级（最高 ${f.mentor.maxLevel} 级）。称号仍需真实历练，演练不会发放答谢或古洞奖励。派遣或随军期间不能亲传。</p>`:'')
   +'<h4>宗主议事</h4>'+ul([
    `<b>整饬山门</b>：支出 ${e(f.council.repairContribution)} 贡献、${e(f.council.repairGold)} 灵石，繁荣度 +${e(f.council.prosperityGain)}。`,
    `<b>亲授弟子</b>：支出 ${e(f.council.lessonContribution)} 贡献，亲授的弟子等级 +1、忠诚 +2。两项议事共用 ${e(f.council.cooldown)} 个游戏日冷却。`,
    '<b>季度岁入 · 敕令 · 绝学 · 官职</b>：新季度须手动结算；余额不足时灵石归零，繁荣度另减 2。护法、执事、先锋三职还会随你登镇岳台。'])
  },
  {id:'boss',icon:'⛰️',tab:'镇岳台',title:'镇岳台 · 玄冥蜕影',html:()=>{
   if(!B)return '<p>本版本未载入镇岳台。</p>';
   return '<p>万年前被九锁镇于山腹的玄冥，每逢灵潮之秋便蜕下一缕魂影爬上镇岳台。镇之，护宗门气运。</p>'
   +'<h4>何人、何时、何处</h4>'+ul([
    `<b>条件</b>：身在宗门（非散修、宗门尚存）且达${e(B.minRealm)}境。`,
    `<b>时间</b>：每年 <b>${e(B.from)}～${e(B.to)}</b>，封印松动 ${e(B.days)} 日。`,
    '<b>入口</b>：宗门大殿【⛰️ 镇岳台】，按钮上直接写着封印状态与剩余天数。'])
   +'<h4>层级与年度首胜</h4><div class="guide-table-v2890" role="table" aria-label="镇岳台层级">'
   +'<div role="row" class="guide-tr-v2890 guide-th-v2890"><span role="columnheader">层</span><span role="columnheader">境界起</span><span role="columnheader">灵石</span><span role="columnheader">修为</span><span role="columnheader">贡献</span><span role="columnheader">残骨</span></div>'
   +B.tiers.map(t=>`<div role="row" class="guide-tr-v2890"><span role="cell">第${e(t.id)}层</span><span role="cell">${e(t.realm)}</span><span role="cell">${e(t.gold)}</span><span role="cell">${e(t.exp)}</span><span role="cell">${e(t.contribution)}</span><span role="cell">${e(t.bones)}</span></div>`).join('')+'</div>'
   +`<p>每年只有<b>第一次</b>胜利全额领奖，按回合快慢另评甲、乙、丙。同年再胜算练手：每个游戏日最多一份，得 ${e(B.repeat.gold)}% 灵石与 ${e(B.repeat.bones)} 枚${e(B.bone)}。</p>`
   +'<h4>六式</h4>'+ul([
    `<b>${e(B.names.strike)}</b>：消耗全部道韵，每层增伤 25%。`,
    `<b>${e(B.names.guard)}</b>：减伤，回 3% 气血、12% 灵力并积 1 层道韵。`,
    `<b>${e(B.names.evade)}</b>：躲开可避之招并反击，积 1 层道韵。`,
    `<b>${e(B.names.break)}</b>：耗 25% 灵力，打断蓄力（吞灵诀）或碎一层骨甲。`,
    `<b>${e(B.names.cleanse)}</b>：解除蚀咒与被封之招。`,
    `<b>${e(B.names.lock)}</b>：消耗一道锁，整回合锁住蜕影；对“无法避让”的大招最管用。`])
   +tip('每回合都会<b>预告</b>蜕影下一招与应对之法。同一招式连用两次后，再用会被<b>看破</b>（避让躲不开、守势被破、强攻减半）；进入噬灵相后，它还会记住你上次如何应对同一招。')
   +'<h4>年相与九锁</h4>'+ul(B.aspects.map(a=>`${e(a.icon)} <b>${e(a.name)}</b>：${e(a.desc)}`).concat([
    '三相按年轮转，台上会提前写出来年之相。',
    `每次换相可选一次<b>九锁回应</b>：${B.boons.map(b=>`${e(b.name)}（${e(b.desc)}）`).join('、')}；宗主另有一应，由道统决定。`,
    `<b>献骨入阵</b>：任何人都可献 ${e(B.offering.bones)} 枚${e(B.bone)}，开战多 ${e(B.offering.locks)} 道镇岳锁。`]))
   +'<h4>失守与加固</h4>'+ul([
    `某年未镇，即记失守一年：蜕影气血与灵石奖励各 +${e(B.seal.hp)}%/年；门人最多感受 ${e(B.seal.member)} 年，宗主最多 ${e(B.seal.master)} 年，且宗主每失守一年繁荣度 −${e(B.seal.prosperity)}。`,
    `宗主可在【季度岁入 · 敕令 · 绝学 · 官职】的镇岳封印栏，以 ${e(B.seal.reinforce)} 枚${e(B.bone)}加固封印：清除失守，繁荣度 +${e(B.seal.reinforceGain)}。`,
    `宗主亲临：开战即有镇岳锁与道韵，护法、执事、先锋随行；但蜕影恨透了宗主，气血 +${e(B.masterHp)}%。`])
   +tip(`魂影代身：战斗中的损伤不伤真身，战败只需调息 ${e(B.defeatDays)} 日。一战最多 ${e(B.maxRounds)} 回合；未完之战可继续，也可放弃（不发战果、不退献骨）。`);
  }},
  {id:'travel',icon:'🗺️',tab:'行路',title:'山河与行路',html:()=>
   `<p><span class="help-tag">南域 ${R(u.south)}</span><span class="help-tag">东域 ${R(u.east)}</span><span class="help-tag">北域 ${R(u.north)}</span><span class="help-tag">西域 ${R(u.west)}</span></p>`
   +'<p>标签是开放该地域所需的境界。南域的【四方驿道】通往他域，他域的【归途界门】可回南域。</p>'
   +ul([
    '<b>南域</b>：初始之地；仙市可购丹药，洞府也在这里。',
    '<b>东域</b>：迷雾森林、灵兽谷。',
    '<b>北域</b>：问道山、凌霄宗、三界势力碑。',
    '<b>西域</b>：古战场、炼丹房、法宝台。古战场最险，先备足补给。',
    '<b>万宗秘境</b>：须所在宗门在百年大比中取得本世纪资格。'])
   +'<h4>认路</h4>'+ul([
    '右上小地图可看周围地点，点选地图位置即可寻路。',
    '【探索】→【卷 山河图】展开整幅地域绘卷；绘卷中的【立体】按钮可开关层叠景深与光影，只影响画面。',
    '【探索】→【灵动】切换高、低、关：天气、鸟群、脚步与建筑动效只影响画面，手机默认低；关闭后仍保留原有地图画面与镜头修正。',
    '画面类开关（立体山河、立体战场、战斗呈现方式）记在本机浏览器里，不随存档转移。'])
  },
  {id:'items',icon:'🎒',tab:'物品',title:'物品与锻造',html:()=>
   '<h4>装备</h4>'+ul([
    '装备分凡品至神器多个品质，品质会放大基础属性；高阶装备有境界要求，成套可激活额外加成。',
    `戒指两格、法宝三格；<b>本命法宝位于${R(3)}境开启</b>。`,
    '装备栏：【⚡ 一键装备最佳】、【⬆️ 升品 / 继承】、【⚒️ 强化 / 洗练】、【📦 背包装备】、【↩️ 一键卸下未锁定】，另有装备与功法预设。'])
   +'<h4>装备工坊</h4>'+ul([
    '<b>强化</b>：最高 +10，每级提升原有攻击、防御、气血、灵力 5%，成功率 100%，不降级，消耗灵石。',
    '<b>洗练</b>：生成两条不同的百分比词条，先对比再决定是否替换。',
    '加工过的装备自动锁定，卸下或换装后保留进度。战斗或突破中不能开工坊。'])
   +'<h4>丹药与法宝</h4>'+ul([
    '南域仙市【稀有丹药】可买破境丹、延寿丹等；西域炼丹房按丹方炼制。',
    '西域法宝台可查看与强化已有法宝。',
    '灵兽丹等御兽材料用于灵宠养成。'])
   +tip('战斗中只能用【战斗背包】里的物品；平时点背包中的捕捉契具只会提示用法，不会误耗。')
  },
  {id:'save',icon:'💾',tab:'存档',title:'存档与备份',html:()=>
   ul([
    '<b>自动记档</b>：每 30 秒一次，切到后台或关闭页面时也会尝试记档，离开前仍建议手动保存。',
    '<b>手动记档</b>：【💾 记档】在存档栏；手机在右上【☰】快捷菜单里。',
    '<b>战斗中记档</b>：普通战斗只保留开战前的记录；未结算离开时回到战前快照。镇岳台按每回合保存，正魔大战已付战备的交锋可续行，不能依靠刷新退还战备。'])
   +'<h4>📁 存档管理</h4>'+ul([
    '<b>导出当前存档</b> / <b>复制存档文本</b>：换设备或留底时用。',
    '<b>导入存档</b>：JSON 文件，最大 8MB，会替换当前主存档（导入前会确认）。',
    '<b>上一次有效备份</b>：可导出或恢复。',
    '<b>替换前记录</b>：导入或恢复前自动留一份，仅存一份。',
    '<b>上一位角色</b>：重新入世时保留，自动记档不会覆盖。'])
   +tip('修行记录只保存在<b>当前这个浏览器</b>里。清除网站数据会让存档消失；换手机、换浏览器前，请先导出。')
  }
 ];
}

function guideRenderBodyV2890(id){
 const list=guideSectionsV2890(),sec=list.find(s=>s.id===id)||list[0];
 guideTabV2890=sec.id;
 let html='';try{html=sec.html();}catch(err){console.warn('修行指引分页失败',sec.id,err);html='<p>此页暂时无法显示。</p>';}
 const i=list.indexOf(sec),prev=list[i-1],next=list[i+1];
 return `<h3 class="guide-h3-v2890" id="guideTitleV2890" tabindex="-1">${sec.icon} ${guideEscV2890(sec.title)}</h3>${html}`
  +`<nav class="guide-pager-v2890" aria-label="翻页">${prev?`<button type="button" data-guide-tab="${prev.id}">‹ ${guideEscV2890(prev.tab)}</button>`:'<span></span>'}${next?`<button type="button" data-guide-tab="${next.id}">${guideEscV2890(next.tab)} ›</button>`:'<span></span>'}</nav>`;
}
function guideTabV2890Go(id,focus){
 const root=document.getElementById('helpManual');if(!root||guideOwnerV2890!==player||!root.classList.contains('guide-v2890'))return false;
 const body=document.getElementById('guideBodyV2890');if(!body)return false;
 body.innerHTML=guideRenderBodyV2890(id);body.scrollTop=0;
 for(const b of root.querySelectorAll('.guide-tab-v2890')){const on=b.getAttribute('data-guide-tab')===guideTabV2890;b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;b.className='guide-tab-v2890'+(on?' on':'');if(on){try{const strip=b.parentNode;if(strip&&strip.clientWidth)strip.scrollLeft=Math.max(0,b.offsetLeft-(strip.clientWidth-b.offsetWidth)/2);}catch(_){}if(focus)try{b.focus();}catch(_){}}}
 body.setAttribute('aria-labelledby','guideTabBtnV2890-'+guideTabV2890);
 guideStoreV2890(guideTabV2890);
 return true;
}
function guideActionsV2890(){
 const t=player?.tutorial;
 const s=guideJourneyReadV2890(),lv=guideTryV2890(()=>player.level,0);
 let html=typeof showPetGuideV211==='function'?'<button id="helpPetGuideV211" type="button" onclick="closeHelpManual();showPetGuideV211(\'overview\')">🐾 灵宠完整指引</button>':'';
 if(s&&s.step<5)html+='<button type="button" onclick="beginFirstJourneyV28687()">继续初入仙途</button>';
 else if(!s&&lv<2&&typeof beginFirstJourneyV28687==='function')html+='<button type="button" onclick="beginFirstJourneyV28687()">开始初入仙途</button>';
 if(typeof restartTutorial==='function')html+='<button type="button" onclick="restartTutorial()">🌅 重走新手引路</button>';
 if(typeof toggleTutorialTooltips==='function')html+=`<button type="button" onclick="toggleTutorialTooltips()">${t?.showTooltips!==false?'关闭':'开启'}问号提示</button>`;
 html+='<button type="button" onclick="closeHelpManual()">返回仙途</button>';
 return html;
}
function renderGuideV2890(tab){
 if(!document.getElementById('helpManual'))guideOpenerV2890=document.activeElement;guideOwnerV2890=player;
 if(typeof stopNavigationV2830==='function')stopNavigationV2830();if(typeof resetWorldMovementV28686==='function')resetWorldMovementV28686();
 let el=document.getElementById('helpManual');
 if(!el){el=document.createElement('div');el.id='helpManual';el.onclick=ev=>{if(ev.target===el)closeHelpManual();};document.body.appendChild(el);}
 el.className='help-manual-overlay active guide-v2890';
 const list=guideSectionsV2890();
 const want=tab&&GUIDE_V2890.tabs.includes(tab)?tab:(guideStoreV2890()||guideTabV2890);
 const start=GUIDE_V2890.tabs.includes(want)?want:'start';
 const tabs=list.map(s=>`<button type="button" role="tab" class="guide-tab-v2890" id="guideTabBtnV2890-${s.id}" data-guide-tab="${s.id}" aria-controls="guideBodyV2890" aria-selected="false" tabindex="-1">${s.icon} ${guideEscV2890(s.tab)}</button>`).join('');
 el.innerHTML=`<div class="help-manual-content guide-sheet-v2890" role="dialog" aria-modal="true" aria-labelledby="guideHeadV2890" onclick="event.stopPropagation()">`
  +`<div class="help-manual-title guide-head-v2890"><span id="guideHeadV2890">📖 仙途 · 修行指引</span><button type="button" aria-label="关闭修行指引" class="help-manual-close" onclick="closeHelpManual()">✕</button></div>`
  +`<div class="guide-tabs-v2890" role="tablist" aria-label="指引分类">${tabs}</div>`
  +`<div class="guide-body-v2890" id="guideBodyV2890" role="tabpanel" tabindex="0"></div>`
  +`<div class="help-manual-actions guide-actions-v2890">${guideActionsV2890()}</div></div>`;
 guideTabV2890Go(start,true);
 if(!el.__guideOwnerGuardV2890){el.__guideOwnerGuardV2890=true;el.addEventListener('click',ev=>{if(guideOwnerV2890!==player){ev.preventDefault();ev.stopImmediatePropagation();closeHelpManual();}},true);}
 return el;
}
function guideKeyV2890(ev){
 const root=document.getElementById('helpManual');if(!root||guideOwnerV2890!==player||!root.classList.contains('guide-v2890'))return;
 if(!root.contains(ev.target))return;ev.stopPropagation?.();
 if(ev.key==='Escape'){ev.preventDefault?.();ev.stopPropagation?.();closeHelpManual();return;}
 if(ev.key==='Tab'){trapJourneyFocusV2838(ev,root);return;}
 const onTab=ev.target?.classList?.contains?.('guide-tab-v2890');
 if(onTab&&(ev.key==='ArrowRight'||ev.key==='ArrowLeft'||ev.key==='Home'||ev.key==='End')){
  const ids=GUIDE_V2890.tabs,i=ids.indexOf(guideTabV2890);
  const j=ev.key==='Home'?0:ev.key==='End'?ids.length-1:(i+(ev.key==='ArrowRight'?1:-1)+ids.length)%ids.length;
  ev.preventDefault?.();guideTabV2890Go(ids[j],true);
 }
}
function guideClickV2890(ev){
 const t=ev.target?.closest?.('[data-guide-tab]');if(!t||!t.closest?.('#helpManual'))return;
 const fromPager=!!t.closest('.guide-pager-v2890');
 guideTabV2890Go(t.getAttribute('data-guide-tab'),fromPager);
}

// 修正新手引路中“闭关十年最多推进一个小段”的含糊说法，并在元婴时补一张镇岳台提示。
function installGuideTextV2890(){
 try{
  if(typeof TUTORIAL_STEPS==='object'&&TUTORIAL_STEPS.cultivation){
   TUTORIAL_STEPS.cultivation.desc='修为攒到当前小段的瓶颈后，即可尝试突破；<b>每次突破只进一段</b>，成功只扣本段所需修为。失败会损失部分修为并需调息，可在突破面板一次调息完毕。<br><br>闭关最多十年，但只会把修为补到瓶颈，<b>不会自行破境</b>；渡劫圆满须亲手渡过飞升天劫，方入地仙。<br><br>踏入练气后，沿主线走入凌霄宗，再接宗门差事，稳定获取修为、贡献与灵石。随时可从【📖 修行指引】查看各项玩法。';
  }
 }catch(_){}
 const base=window.checkTutorialRealm;
 if(typeof base==='function'&&!base.__guideV2890){
  const wrapped=function(level){
   const r=base.apply(this,arguments);
   try{
    if(!document.getElementById('tutorialUnlock')&&typeof bossEligibleV2887==='function'&&bossEligibleV2887()&&typeof showTutorialUnlockPopup==='function'){
     const f=guideFactsV2890().boss;
     if(f)showTutorialUnlockPopup('unlock_boss_v2890','⛰️ 镇岳台可往',`你已入${guideEscV2890(f.minRealm)}，又身在宗门。每年 ${guideEscV2890(f.from)}～${guideEscV2890(f.to)} 镇岳封印松动，可从宗门大殿登台镇压玄冥蜕影。详见【📖 修行指引 → 镇岳台】。`);
    }
   }catch(err){console.warn('镇岳台提示失败',err);}
   return r;
  };
  wrapped.__guideV2890=true;window.checkTutorialRealm=wrapped;
 }
}
function installGuideStylesV2890(){
 if(document.getElementById('guideStyleV2890'))return;
 const st=document.createElement('style');st.id='guideStyleV2890';
 st.textContent=`
#helpManual.guide-v2890 .guide-sheet-v2890{display:flex;flex-direction:column;width:min(760px,94vw);max-height:min(88vh,920px);max-height:min(88dvh,920px);padding:0;overflow:hidden}
#helpManual.guide-v2890 .guide-head-v2890{margin:0;padding:14px 16px 8px;flex:none}
#helpManual.guide-v2890 .guide-tabs-v2890{flex:none;display:flex;gap:6px;overflow-x:auto;padding:2px 14px 10px;scrollbar-width:none;-webkit-overflow-scrolling:touch;border-bottom:1px solid rgba(242,210,122,.18)}
#helpManual.guide-v2890 .guide-tabs-v2890::-webkit-scrollbar{display:none}
#helpManual.guide-v2890 .guide-tab-v2890{flex:none;min-height:38px;padding:6px 12px;border-radius:999px;border:1px solid rgba(242,210,122,.28);background:rgba(255,255,255,.04);color:#d8ccb0;font-size:14px;white-space:nowrap}
#helpManual.guide-v2890 .guide-tab-v2890.on{background:linear-gradient(135deg,rgba(242,210,122,.28),rgba(217,181,236,.18));color:#fff3cf;border-color:#f2d27a;font-weight:700}
#helpManual.guide-v2890 .guide-tab-v2890:focus-visible,#helpManual.guide-v2890 .guide-pager-v2890 button:focus-visible{outline:2px solid #f2d27a;outline-offset:2px}
#helpManual.guide-v2890 .guide-body-v2890{flex:1 1 auto;min-height:0;overflow-y:auto;padding:12px 18px 6px;font-size:15px;line-height:1.75;color:#e8e2d4;-webkit-overflow-scrolling:touch;overscroll-behavior:contain}
#helpManual.guide-v2890 .guide-body-v2890:focus{outline:none}
#helpManual.guide-v2890 .guide-h3-v2890{margin:2px 0 8px;font-size:18px;color:#f2d27a;outline:none}
#helpManual.guide-v2890 .guide-body-v2890 h4{margin:14px 0 4px;font-size:15px;color:#d9b5ec}
#helpManual.guide-v2890 .guide-body-v2890 p{margin:6px 0}
#helpManual.guide-v2890 .guide-body-v2890 b{color:#fff1c4}
#helpManual.guide-v2890 .guide-list-v2890{margin:4px 0 6px;padding-left:1.2em}
#helpManual.guide-v2890 .guide-list-v2890 li{margin:5px 0}
#helpManual.guide-v2890 .guide-next-v2890{padding:9px 12px;border:1px solid rgba(105,240,174,.35);border-radius:10px;background:rgba(105,240,174,.07)}
#helpManual.guide-v2890 .guide-next-v2890 b{color:#9ff5c8}
#helpManual.guide-v2890 .guide-tip-v2890{padding:8px 11px;border-left:3px solid #f2d27a;border-radius:6px;background:rgba(242,210,122,.08);font-size:14px}
#helpManual.guide-v2890 .guide-table-v2890{display:grid;gap:2px;margin:6px 0;max-width:560px;font-size:14px;overflow-x:auto}
#helpManual.guide-v2890 .guide-tr-v2890{display:grid;grid-template-columns:4em 4.5em repeat(4,minmax(3em,1fr));gap:4px;padding:4px 6px;border-radius:6px;background:rgba(255,255,255,.035)}
#helpManual.guide-v2890 .guide-th-v2890{color:#d9b5ec;background:rgba(217,181,236,.10)}
#helpManual.guide-v2890 .guide-pager-v2890{display:flex;justify-content:space-between;gap:8px;margin:16px 0 8px}
#helpManual.guide-v2890 .guide-pager-v2890 button{min-height:40px;padding:6px 14px;border-radius:10px;border:1px solid rgba(242,210,122,.3);background:rgba(255,255,255,.05);color:#f2d27a;font-size:14px}
#helpManual.guide-v2890 .guide-actions-v2890{flex:none;display:flex;flex-wrap:wrap;gap:6px;margin:0;padding:10px 14px calc(10px + env(safe-area-inset-bottom,0px));border-top:1px solid rgba(242,210,122,.18)}
#helpManual.guide-v2890 .guide-actions-v2890 button{flex:1 1 auto;min-height:40px;font-size:14px}
@media (max-width:620px){#helpManual.guide-v2890 .guide-sheet-v2890{width:100%;max-height:92vh;max-height:92dvh;border-radius:16px 16px 12px 12px}#helpManual.guide-v2890 .guide-body-v2890{padding:10px 14px 4px}#helpManual.guide-v2890 .guide-actions-v2890{gap:5px;padding:8px 10px calc(8px + env(safe-area-inset-bottom,0px))}#helpManual.guide-v2890 .guide-actions-v2890 button{flex:1 1 auto;min-height:36px;padding:5px 8px;font-size:13px}}
html.xiantu-mobile-dedicated #helpManual.guide-v2890 .guide-sheet-v2890{padding:0!important}
@media (prefers-reduced-motion:no-preference){#helpManual.guide-v2890 .guide-body-v2890>*{animation:guideInV2890 .18s ease-out}}
@keyframes guideInV2890{from{opacity:.4;transform:translateY(3px)}to{opacity:1;transform:none}}
`;
 (document.head||document.documentElement).appendChild(st);
}
function installGuideV2890(){
 installGuideStylesV2890();
 installGuideTextV2890();
 const base=window.showHelpManual;
 if(typeof base==='function'&&!base.__guideV2890){
  const wrapped=function(tab){
   // Keep the existing public entry and actions; render without save normalization.
   // Render read-only; legacy guide normalizers must not mutate a save when browsing help.
   try{renderGuideV2890(typeof tab==='string'?tab:null);}catch(err){console.warn('修行指引渲染失败',err);}
  };
  wrapped.__guideV2890=true;window.showHelpManual=wrapped;
 }
 const hud=document.getElementById('guideHudBtn');if(hud)hud.onclick=window.showHelpManual;
 if(!window.__guideListenersV2890){
  const close=window.closeHelpManual;window.closeHelpManual=function(){const opener=guideOpenerV2890,owner=guideOwnerV2890;guideOpenerV2890=null;guideOwnerV2890=null;if(typeof resetWorldMovementV28686==='function')resetWorldMovementV28686();const r=close.apply(this,arguments);if(owner===player&&opener?.isConnected)opener.focus?.();return r;};
  const reset=window.resetRuntimeState;window.resetRuntimeState=function(){closeHelpManual();return reset.apply(this,arguments);};
  window.__guideListenersV2890=true;
  document.addEventListener('keydown',guideKeyV2890);
  document.addEventListener('click',guideClickV2890,true);   // capture: the sheet stops bubbling clicks
 }
}
try{installGuideV2890();}catch(e){console.warn('修行指引安装失败',e);}

// END GUIDE_V2890
// BEGIN MAP_ALIVE_V2893
// V28.93 山河灵动：镜头手感（前瞻、柔性死区、换图瞬切）、像素对齐、地标视觉放大、桌面清晰度修正，
// 以及纯表现层的地图生气：季节与地域飘落物、天象、昼夜色调、鸟群萤火、建筑炊烟旗幡阵光、足下尘涟、行走起伏、
// 三个小彩蛋。全部只画在画布上：不改 r、碰撞、交互、存档或数值。可调数值集中在 MAP_ALIVE_V2893。
const MAP_ALIVE_V2893=(()=>{const deep=o=>{for(const v of Object.values(o))if(v&&typeof v==='object')deep(v);return Object.freeze(o);};return deep({
 camera:{
  rate:10,             // 跟随速度（原为 24）：1-exp(-rate·dt)，与帧率无关
  lookAhead:56,        // 行走方向前瞻像素
  lookAheadY:.6,       // 纵向前瞻比例
  lookAheadRate:3,     // 前瞻缓入速度
  deadzone:26,         // 柔性死区：偏离小于此距离时跟随明显变慢
  snapViewport:.6      // 目标跳变超过视口 60% 时直接切换（换图、传送）
 },
 pixelSnap:true,
 dpr:{desktopCap:1.5,mobileCap:2,memoryFloorGB:4,fpsFloor:40,fpsFloorMobile:24,fpsStrikes:3},  // 连续低帧回退；手机的正常30帧不触发桌面40帧阈值
 landmarks:{baseY:30,scale:{sect:1.22,faction_gate:1.2,palace:1.18,travel_gate:1.15,market:1.12,artifacts:1.12,alchemy:1.1,village:1.08}},
 quality:{
  key:'xiantu_map_alive_v2893',
  order:['high','low','off'],
  names:{high:'高',low:'低',off:'关'},
  levels:{
   high:{fall:36,rain:90,glow:14,birds:2,dust:12,buildings:true,eggs:true,bob:true},
   low:{fall:14,rain:40,glow:6,birds:1,dust:6,buildings:true,eggs:false,bob:true},
   off:{fall:0,rain:0,glow:0,birds:0,dust:0,buildings:false,eggs:false,bob:false}
  }
 },
 juice:{stride:30,hop:2.2,squash:.045,breath:.012,feetY:16,dustLife:.55,rippleLife:.9},
 seasons:{1:'spring',2:'spring',3:'spring',4:'summer',5:'summer',6:'summer',7:'autumn',8:'autumn',9:'autumn',10:'winter',11:'winter',12:'winter'},
 fall:{spring:'petal',summer:null,autumn:'leaf',winter:'snow'},
 regionFall:{demon_domain:'ember',immortal_domain:'mote',north:'snow'},
 weather:{
  south:{clear:.62,mist:.18,rain:.2},east:{clear:.5,mist:.25,rain:.25},west:{clear:.75,mist:.15,rain:.1},
  north:{clear:.55,mist:.15,snow:.3},demon_domain:{clear:.55,ash:.45},immortal_domain:{clear:.7,mist:.3},
  default:{clear:.65,mist:.17,rain:.18}
 },
 weatherNames:{clear:'晴',mist:'薄雾',rain:'小雨',snow:'飞雪',ash:'灰烬'},
 dayNight:{mode:'realtime',dawn:[5,7],dusk:[17,19],tints:{dawn:'rgba(255,186,160,.08)',dusk:'rgba(255,140,70,.12)',night:'rgba(16,26,66,.26)'},names:{dawn:'清晨',day:'白昼',dusk:'黄昏',night:'夜'}},
 weatherTint:{rain:'rgba(70,86,104,.10)',mist:'rgba(232,238,240,.10)',snow:'rgba(236,244,255,.08)',ash:'rgba(60,30,40,.10)'},
 buildings:{   // local anchors (before scaling) of small idle effects, by building kind
  sect:[{fx:'banner',x:-25,y:-8},{fx:'banner',x:25,y:-8},{fx:'lantern',x:0,y:4}],
  faction_gate:[{fx:'banner',x:-30,y:-18},{fx:'banner',x:30,y:-18},{fx:'lantern',x:-25,y:4},{fx:'lantern',x:25,y:4}],
  lingxiao_building:[{fx:'lantern',x:-25,y:4},{fx:'lantern',x:25,y:4}],
  alchemy:[{fx:'smoke',x:16,y:-14},{fx:'lantern',x:16,y:-10}],
  home:[{fx:'smoke',x:-14,y:-22},{fx:'lantern',x:4,y:6}],
  village:[{fx:'smoke',x:-36,y:-12},{fx:'smoke',x:8,y:-22},{fx:'lantern',x:-25,y:4},{fx:'lantern',x:25,y:4}],
  market:[{fx:'lantern',x:-32,y:23},{fx:'lantern',x:0,y:23},{fx:'lantern',x:32,y:23}],
  shop:[{fx:'lantern',x:0,y:6}],
  artifacts:[{fx:'pulse',x:0,y:-6}],
  travel_gate:[{fx:'formation',x:0,y:18}],
  secret:[{fx:'formation',x:0,y:14},{fx:'motes',x:0,y:-4}]
 },
 eggs:{meteorPerSec:.006,craneIdleSec:9,craneCooldownSec:240,foxChancePerSec:.01,foxFleeDist:80,foxRange:260}
});})();

const ALIVE_V2893={
 la:{x:0,y:0},snap:true,lastCam:null,dprStrikes:0,dprDowngraded:false,lastFpsAt:0,
 fall:[],rain:[],glow:[],birds:[],dust:[],ripples:[],
 strideDist:0,stridePhase:0,moveAmt:0,lastP:null,idle:0,
 meteor:null,crane:null,craneCd:0,fox:null,toldCrane:false,toldFox:false,toldMeteor:false,
 sprites:null,regionKey:''
};
// Visual randomness must never consume the combat/loot RNG.
let aliveSeedV2893=0x2893cafe;
function aliveRandV2893(){aliveSeedV2893=(Math.imul(aliveSeedV2893,1664525)+1013904223)>>>0;return aliveSeedV2893/4294967296;}
let aliveQualityV2893=null;
try{const q=localStorage.getItem(MAP_ALIVE_V2893.quality.key);if(MAP_ALIVE_V2893.quality.order.includes(q))aliveQualityV2893=q;}catch(_){}
const aliveMotionV2893=window.matchMedia?.('(prefers-reduced-motion: reduce)');
aliveMotionV2893?.addEventListener?.('change',()=>resetMapAliveV2893());
window.addEventListener('storage',e=>{if(e.key!==MAP_ALIVE_V2893.quality.key&&e.key!==null)return;aliveQualityV2893=MAP_ALIVE_V2893.quality.order.includes(e.newValue)?e.newValue:null;resetMapAliveV2893();syncMapAliveButtonV2893();});

// ------------------------------------------------------------ settings ----
function mapAliveCalmV2893(){return !!aliveMotionV2893?.matches;}
function mapAliveQualityV2893(){return aliveQualityV2893||((typeof PERF_CONFIG!=='undefined'&&PERF_CONFIG.mobile)?'low':'high');}
function mapAliveLevelV2893(){return MAP_ALIVE_V2893.quality.levels[mapAliveQualityV2893()];}
function setMapAliveQualityV2893(v){
 const Q=MAP_ALIVE_V2893.quality;if(!Q.order.includes(v))return false;aliveQualityV2893=v;resetMapAliveV2893();try{localStorage.setItem(Q.key,v);}catch(_){}
 syncMapAliveButtonV2893();return true;
}
function cycleMapAliveV2893(){
 const Q=MAP_ALIVE_V2893.quality,next=Q.order[(Q.order.indexOf(mapAliveQualityV2893())+1)%Q.order.length];setMapAliveQualityV2893(next);
 showFloatingText?.(`山河灵动：${Q.names[next]}${next==='off'?'（关闭新增环境动效）':''}`,'#ccefdc');return next;
}

// ------------------------------------------------------------ 1. camera ----
// Called by drawFlatWorld with the clamped target it already computed (includes the war-camera offset).
function worldCameraStepV2893(cam,p,targetX,targetY,dt,vw,vh){
 const C=MAP_ALIVE_V2893.camera,W=FLAT_WORLD.width,H=FLAT_WORLD.height;dt=Math.max(.001,Math.min(.1,Number(dt)||1/60));
 const calm=mapAliveCalmV2893()||mapAliveQualityV2893()==='off',moving=!!FLAT_WORLD.moving&&!calm;
 if(calm)ALIVE_V2893.la.x=ALIVE_V2893.la.y=0;
 const lr=1-Math.exp(-C.lookAheadRate*dt);
 ALIVE_V2893.la.x+=((moving?(Number(FLAT_WORLD.moveDirX)||0)*C.lookAhead:0)-ALIVE_V2893.la.x)*lr;
 ALIVE_V2893.la.y+=((moving?(Number(FLAT_WORLD.moveDirY)||0)*C.lookAhead*C.lookAheadY:0)-ALIVE_V2893.la.y)*lr;
 const tx=Math.max(0,Math.min(Math.max(0,W-vw),targetX+ALIVE_V2893.la.x)),ty=Math.max(0,Math.min(Math.max(0,H-vh),targetY+ALIVE_V2893.la.y));
 const dx=tx-cam.x,dy=ty-cam.y,dist=Math.hypot(dx,dy);
 if(ALIVE_V2893.snap||dist>C.snapViewport*Math.max(vw,vh)){
  cam.x=targetX;cam.y=targetY;ALIVE_V2893.la.x=ALIVE_V2893.la.y=0;ALIVE_V2893.snap=false;ALIVE_V2893.lastCam=null;return 'snap';
 }
 const soft=dist<C.deadzone?Math.max(.15,(dist/C.deadzone)*(dist/C.deadzone)):1;
 const k=1-Math.exp(-C.rate*soft*dt);
 cam.x+=dx*k;cam.y+=dy*k;
 if(Math.abs(tx-cam.x)<.02)cam.x=tx;if(Math.abs(ty-cam.y)<.02)cam.y=ty;
 return 'follow';
}
function worldCameraSnapV2893(v,dpr){if(!MAP_ALIVE_V2893.pixelSnap)return v;const d=Math.max(1,Number(dpr)||1);return Math.round(v*d)/d;}
function resetMapAliveV2893(full=false){
 for(const k of ['fall','rain','glow','birds','dust','ripples'])ALIVE_V2893[k].length=0;
 Object.assign(ALIVE_V2893,{meteor:null,crane:null,fox:null,lastP:null,lastCam:null,snap:true,la:{x:0,y:0},strideDist:0,stridePhase:0,moveAmt:0,idle:0,craneCd:0,regionKey:'',clock:0});
 if(typeof FLAT_WORLD!=='undefined')delete FLAT_WORLD._camDrawV2893;
 if(full){ALIVE_V2893.toldCrane=ALIVE_V2893.toldFox=ALIVE_V2893.toldMeteor=false;aliveSeedV2893=0x2893cafe;}
}

// ------------------------------------------------------------ 2. world canvas DPR ----
// Auto mobile stays economical; explicit high can use 2x with a mobile-specific FPS fallback.
function worldDprCapV2893(){
 const D=MAP_ALIVE_V2893.dpr;
 if(PERF_CONFIG.graphicsQuality==='low')return 1;
 if(PERF_CONFIG.mobile){
  const mem=Number(navigator?.deviceMemory);
  if(PERF_CONFIG.graphicsQuality!=='high'||ALIVE_V2893.dprDowngraded||(Number.isFinite(mem)&&mem>0&&mem<D.memoryFloorGB))return 1;
  return D.mobileCap;
 }
 const mem=Number(navigator?.deviceMemory);if(PERF_CONFIG.graphicsQuality!=='high'&&Number.isFinite(mem)&&mem>0&&mem<D.memoryFloorGB)return 1;
 return ALIVE_V2893.dprDowngraded?1:D.desktopCap;
}
function watchDprV2893(){
 const D=MAP_ALIVE_V2893.dpr;if(ALIVE_V2893.dprDowngraded||typeof PERF_CONFIG==='undefined')return;
 const c=document.getElementById('worldCanvas');if(!c||(c._dpr||1)<=1)return;
 if(PERF_CONFIG.fpsStartedAt===ALIVE_V2893.lastFpsAt||!PERF_CONFIG.measuredFps)return;ALIVE_V2893.lastFpsAt=PERF_CONFIG.fpsStartedAt;
 ALIVE_V2893.dprStrikes=PERF_CONFIG.measuredFps<(PERF_CONFIG.mobile?D.fpsFloorMobile:D.fpsFloor)?ALIVE_V2893.dprStrikes+1:0;
 if(ALIVE_V2893.dprStrikes>=D.fpsStrikes){ALIVE_V2893.dprDowngraded=true;try{resizeWorldCanvas?.();}catch(_){}}
}

// ------------------------------------------------------------ 3. landmark scale (visual only) ----
function landmarkKindV2893(o){
 if(!o||o.enemy||o.t==='tree'||o._warUnitV2840||o.action==='explore_v2828'||o.action==='war_map_v2840')return null;
 if(o.action==='faction_gate_v2806')return 'faction_gate';
 const k=typeof getPoiVisualKind==='function'?getPoiVisualKind(o):'default',M=MAP_ALIVE_V2893;
 if(M.landmarks.scale[k]||M.buildings[k])return k;          // its own kind first (the 宗门 is also a painted palace)
 if(typeof scrollPalacePoiV2831==='function'&&scrollPalacePoiV2831(o))return 'palace';
 return k;
}
function landmarkScaleV2893(o){const k=landmarkKindV2893(o);return k&&MAP_ALIVE_V2893.landmarks.scale[k]||1;}
// Called by drawWorldPoi right after it moves to the building's centre; grows the drawing upward from its base.
// The painted building only: r, collision and the interaction ring logic stay in world units.
function landmarkPoiApplyV2893(ctx,o){
 if(!ctx||ctx.canvas?.id!=='worldCanvas')return 1;const s=landmarkScaleV2893(o);if(s===1)return 1;
 const by=MAP_ALIVE_V2893.landmarks.baseY;ctx.translate(0,by);ctx.scale(s,s);ctx.translate(0,-by);return s;
}
// Match rendering: integrated architecture has a fixed world scale; legacy sprites retain depth scaling.
function landmarkPointV2893(o,lx,ly){
 const grounded=typeof joinedArchitectureReadyV286896==='function'&&joinedArchitectureReadyV286896(o);
 const d=!grounded&&typeof scene25dOnV2888==='function'&&scene25dOnV2888()&&typeof s25DepthScaleV2888==='function'?s25DepthScaleV2888(o.y):1;
 const L=landmarkScaleV2893(o),B=MAP_ALIVE_V2893.landmarks.baseY;
 const pivot=grounded?30:0;
 return {x:o.x+d*lx*L,y:o.y+pivot+d*(B+(ly-B)*L-pivot),s:d*L};
}

// ------------------------------------------------------------ environment ----
function mapSeasonV2893(){let m=1;try{m=getGameDate().month;}catch(_){}return MAP_ALIVE_V2893.seasons[m]||'spring';}
function mapRegionV2893(){try{return currentRegion||player?.worldMapId||'south';}catch(_){return 'south';}}
function mapWeatherV2893(day,region){
 if(day===undefined){try{day=Math.floor(player.worldTime.totalDays)||0;}catch(_){day=0;}}region=region||mapRegionV2893();
 const W=MAP_ALIVE_V2893.weather,table=W[region]||W.default;let h=2166136261;for(const ch of `${region}:${day}`)h=Math.imul(h^ch.charCodeAt(0),16777619);
 let r=((h>>>0)%10000)/10000;for(const [k,p] of Object.entries(table)){if(r<p)return k;r-=p;}return 'clear';
}
function mapDayPhaseV2893(hour){
 // Explicit game night also drives the existing tint, lamps and night ambience.
 if(hour===undefined&&typeof isLingxiaoNight==='function'&&isLingxiaoNight())return 'night';
 const D=MAP_ALIVE_V2893.dayNight;if(D.mode!=='realtime')return 'day';
 if(hour===undefined)hour=new Date().getHours();
 if(hour>=D.dawn[0]&&hour<D.dawn[1])return 'dawn';if(hour>=D.dawn[1]&&hour<D.dusk[0])return 'day';if(hour>=D.dusk[0]&&hour<D.dusk[1])return 'dusk';return 'night';
}
function mapFallKindV2893(region=mapRegionV2893(),season=mapSeasonV2893(),weather=mapWeatherV2893()){
 if(weather==='rain')return null;if(weather==='snow')return 'snow';if(weather==='ash')return 'ember';
 return MAP_ALIVE_V2893.regionFall[region]||MAP_ALIVE_V2893.fall[season]||null;
}
function aliveSpritesV2893(){
 if(ALIVE_V2893.sprites)return ALIVE_V2893.sprites;
 const make=(rgb)=>{const c=document.createElement('canvas');c.width=c.height=32;const x=c.getContext?.('2d');if(!x)return null;
  const g=x.createRadialGradient(16,16,0,16,16,16);g.addColorStop(0,`rgba(${rgb},1)`);g.addColorStop(.35,`rgba(${rgb},.55)`);g.addColorStop(1,`rgba(${rgb},0)`);x.fillStyle=g;x.fillRect(0,0,32,32);return c;};
 ALIVE_V2893.sprites={warm:make('255,206,120'),green:make('200,255,150'),cyan:make('170,235,255'),ember:make('255,120,60')};
 return ALIVE_V2893.sprites;
}

// ------------------------------------------------------------ particles (session only) ----
function fillPoolV2893(pool,n,make){while(pool.length<n)pool.push(make());if(pool.length>n)pool.length=n;}
function updateFallV2893(dt,vw,vh,camDX,camDY,kind,n,t){
 const pool=ALIVE_V2893.fall;
 fillPoolV2893(pool,kind?n:0,()=>({x:aliveRandV2893()*vw,y:aliveRandV2893()*vh,vx:0,vy:0,rot:aliveRandV2893()*6,vr:0,size:0,ph:aliveRandV2893()*6,kind:''}));
 for(const q of pool){
  if(q.kind!==kind){q.kind=kind;const up=kind==='ember'||kind==='mote';q.vy=up?-(10+aliveRandV2893()*16):kind==='snow'?18+aliveRandV2893()*16:24+aliveRandV2893()*22;q.vx=(aliveRandV2893()-.5)*10;q.vr=(aliveRandV2893()-.5)*2.4;q.size=kind==='snow'?1.2+aliveRandV2893()*1.6:kind==='ember'||kind==='mote'?1.2+aliveRandV2893()*1.4:3+aliveRandV2893()*2.5;}
  q.y+=q.vy*dt-camDY*.25;q.x+=(q.vx+Math.sin(t*1.3+q.ph)*14)*dt-camDX*.3;q.rot+=q.vr*dt;
  if(q.vy>0&&q.y>vh+12){q.y=-12;q.x=aliveRandV2893()*vw;}else if(q.vy<0&&q.y<-12){q.y=vh+12;q.x=aliveRandV2893()*vw;}
  if(q.x<-20)q.x+=vw+40;else if(q.x>vw+20)q.x-=vw+40;
 }
}
function drawFallV2893(ctx,dpr){
 const colors={petal:'rgba(255,188,206,.85)',leaf:'rgba(214,140,60,.85)',snow:'rgba(250,252,255,.9)'};
 const sp=aliveSpritesV2893();
 for(const q of ALIVE_V2893.fall){
  if(q.kind==='ember'||q.kind==='mote'){const img=q.kind==='ember'?sp.ember:sp.warm;if(!img)continue;ctx.globalAlpha=.55;const s=q.size*5;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.drawImage(img,q.x-s/2,q.y-s/2,s,s);continue;}
  const c=Math.cos(q.rot),s=Math.sin(q.rot);ctx.setTransform(dpr*c,dpr*s,-dpr*s,dpr*c,dpr*q.x,dpr*q.y);ctx.globalAlpha=1;ctx.fillStyle=colors[q.kind]||colors.petal;
  ctx.beginPath();if(q.kind==='snow')ctx.arc(0,0,q.size,0,Math.PI*2);else ctx.ellipse(0,0,q.size,q.size*.55,0,0,Math.PI*2);ctx.fill();
 }
 ctx.globalAlpha=1;
}
function updateRainV2893(dt,vw,vh,n){
 const pool=ALIVE_V2893.rain;fillPoolV2893(pool,n,()=>({x:aliveRandV2893()*vw,y:aliveRandV2893()*vh,v:380+aliveRandV2893()*160}));
 for(const q of pool){q.y+=q.v*dt;q.x-=q.v*.18*dt;if(q.y>vh+16){q.y=-16;q.x=aliveRandV2893()*(vw+60);}}
}
function drawRainV2893(ctx,dpr){
 if(!ALIVE_V2893.rain.length)return;ctx.setTransform(dpr,0,0,dpr,0,0);ctx.strokeStyle='rgba(200,220,235,.38)';ctx.lineWidth=1;ctx.beginPath();
 for(const q of ALIVE_V2893.rain){ctx.moveTo(q.x,q.y);ctx.lineTo(q.x+2.4,q.y-13);}ctx.stroke();
}
// Fireflies / spirit motes / butterflies, wandering inside the view (world space).
function updateGlowV2893(dt,view,n,kind,t){
 const pool=ALIVE_V2893.glow,rand=aliveRandV2893;
 fillPoolV2893(pool,kind?n:0,()=>({x:0,y:0,ph:rand()*6,sp:.4+rand()*.6,live:false,kind:''}));
 for(const q of pool){
  if(!q.live||q.kind!==kind||q.x<view.minX-60||q.x>view.maxX+60||q.y<view.minY-60||q.y>view.maxY+60){q.x=view.minX+rand()*(view.maxX-view.minX);q.y=view.minY+rand()*(view.maxY-view.minY);q.live=true;q.kind=kind;}
  q.x+=Math.cos(t*q.sp+q.ph)*22*dt;q.y+=Math.sin(t*q.sp*1.3+q.ph*2)*14*dt;
 }
}
function drawGlowV2893(ctx,t){
 const sp=aliveSpritesV2893();
 for(const q of ALIVE_V2893.glow){
  if(q.kind==='butterfly'){const f=Math.abs(Math.sin(t*9+q.ph));ctx.fillStyle=q.ph>3?'rgba(255,236,150,.9)':'rgba(255,255,255,.9)';ctx.beginPath();ctx.ellipse(q.x-2.5*f,q.y,3*f+.6,2.2,0,0,Math.PI*2);ctx.ellipse(q.x+2.5*f,q.y,3*f+.6,2.2,0,0,Math.PI*2);ctx.fill();continue;}
  const img=q.kind==='firefly'?sp.green:q.kind==='mote'?sp.warm:sp.cyan;if(!img)continue;
  const a=.25+.4*(.5+.5*Math.sin(t*2.2+q.ph*3)),s=10+4*Math.sin(t+q.ph);ctx.globalAlpha=a;ctx.drawImage(img,q.x-s/2,q.y-s/2,s,s);
 }
 ctx.globalAlpha=1;
}
function glowKindV2893(region,season,phase,weather){
 if(weather==='rain')return null;if(region==='immortal_domain')return 'mote';if(region==='demon_domain')return null;
 if(phase==='night'||phase==='dusk')return season==='winter'?'spirit':'firefly';
 return season==='spring'||season==='summer'?'butterfly':null;
}
function updateBirdsV2893(dt,view,n){
 const B=ALIVE_V2893.birds,rand=aliveRandV2893;
 while(B.length<n)B.push({live:false,wait:4+rand()*10,x:0,y:0,vx:0,count:3,ph:0});if(B.length>n)B.length=n;
 for(const b of B){
  if(!b.live){b.wait-=dt;if(b.wait>0)continue;const left=rand()<.5;b.live=true;b.vx=(left?1:-1)*(60+rand()*30);b.x=left?view.minX-40:view.maxX+40;b.y=view.minY+(view.maxY-view.minY)*(.1+rand()*.35);b.count=3+Math.floor(rand()*3);b.ph=rand()*6;continue;}
  b.x+=b.vx*dt;b.y+=Math.sin(b.x*.01+b.ph)*6*dt;
  if(b.x<view.minX-260||b.x>view.maxX+260){b.live=false;b.wait=12+rand()*14;}
 }
}
function drawBirdsV2893(ctx,t){
 ctx.strokeStyle='rgba(40,46,44,.7)';ctx.lineWidth=1.4;ctx.beginPath();
 for(const b of ALIVE_V2893.birds){if(!b.live)continue;const dir=b.vx>0?-1:1;
  for(let i=0;i<b.count;i++){const ox=b.x+dir*(i?Math.ceil(i/2)*14:0),oy=b.y+(i?Math.ceil(i/2)*8*(i%2?1:-1):0),f=Math.sin(t*10+i+b.ph)*3.5;
   ctx.moveTo(ox-6,oy-f);ctx.quadraticCurveTo(ox-3,oy-2,ox,oy);ctx.quadraticCurveTo(ox+3,oy-2,ox+6,oy-f);}
 }
 ctx.stroke();
}
function drawBirdShadowsV2893(ctx){
 ctx.fillStyle='rgba(10,16,14,.12)';
 for(const b of ALIVE_V2893.birds){if(!b.live)continue;ctx.beginPath();ctx.ellipse(b.x+24,b.y+150,10,3,0,0,Math.PI*2);ctx.fill();}
}

// ------------------------------------------------------------ juice: footsteps + player ----
function stepJuiceV2893(dt,weather,lv,region){
 const J=MAP_ALIVE_V2893.juice,p=FLAT_WORLD.player,last=ALIVE_V2893.lastP;
 const moved=last?Math.hypot(p.x-last.x,p.y-last.y):0;ALIVE_V2893.lastP={x:p.x,y:p.y};
 const moving=!!FLAT_WORLD.moving&&moved>0&&moved<80;
 ALIVE_V2893.moveAmt+=((moving?1:0)-ALIVE_V2893.moveAmt)*(1-Math.exp(-8*dt));
 ALIVE_V2893.idle=moving?0:ALIVE_V2893.idle+dt;
 if(moving){ALIVE_V2893.stridePhase+=moved/J.stride*Math.PI;ALIVE_V2893.strideDist+=moved;}
 if(moving&&ALIVE_V2893.strideDist>=J.stride&&lv.dust>0&&!mapAliveCalmV2893()){
  ALIVE_V2893.strideDist=0;const side=(Math.floor(ALIVE_V2893.stridePhase/Math.PI)%2)?5:-5;
  const kind=weather==='rain'?'ripple':(weather==='snow'||region==='north')?'snow':region==='west'?'sand':'dust';
  const pool=kind==='ripple'?ALIVE_V2893.ripples:ALIVE_V2893.dust,cap=kind==='ripple'?Math.ceil(lv.dust/2):lv.dust;
  if(pool.length>=cap)pool.shift();pool.push({x:p.x+side,y:p.y+J.feetY,age:0,kind});
 }
 for(const pool of [ALIVE_V2893.dust,ALIVE_V2893.ripples]){for(const d of pool)d.age+=dt;while(pool.length&&pool[0].age>(pool===ALIVE_V2893.ripples?J.rippleLife:J.dustLife))pool.shift();}
}
function drawStepsV2893(ctx){
 const J=MAP_ALIVE_V2893.juice,col={dust:'150,132,104',sand:'196,166,112',snow:'245,248,255'};
 for(const d of ALIVE_V2893.dust){const k=d.age/J.dustLife;ctx.fillStyle=`rgba(${col[d.kind]||col.dust},${.3*(1-k)})`;ctx.beginPath();ctx.ellipse(d.x,d.y-2*k,3+6*k,2+3*k,0,0,Math.PI*2);ctx.fill();}
 ctx.lineWidth=1.2;
 for(const r of ALIVE_V2893.ripples){const k=r.age/J.rippleLife;ctx.strokeStyle=`rgba(210,232,245,${.45*(1-k)})`;ctx.beginPath();ctx.ellipse(r.x,r.y,4+12*k,(4+12*k)*.42,0,0,Math.PI*2);ctx.stroke();}
}
// Called by drawWorldPlayer around the painted actor; returns true when it saved the context (the caller restores).
function playerJuiceV2893(ctx,p){
 try{
  const lv=mapAliveLevelV2893();if(!lv.bob||mapAliveCalmV2893()||!ctx||ctx.canvas?.id!=='worldCanvas'||!p)return false;
  const J=MAP_ALIVE_V2893.juice,m=ALIVE_V2893.moveAmt,ph=ALIVE_V2893.stridePhase,t=(ALIVE_V2893.clock||0);
  const bob=-Math.abs(Math.sin(ph))*J.hop*m,sq=Math.sin(2*ph)*J.squash*m,breath=1+J.breath*Math.sin(t*1.8)*(1-m);
  const fx=p.x,fy=p.y+J.feetY;
  ctx.save();ctx.translate(fx,fy+bob);ctx.scale(1+sq,(1-sq)*breath);ctx.translate(-fx,-fy);return true;
 }catch(e){console.warn('行走起伏失败',e);return false;}
}

// ------------------------------------------------------------ building idle life ----
function drawBuildingLifeV2893(ctx,items,t,phase,ground){
 const night=phase==='night'||phase==='dusk',sp=aliveSpritesV2893(),FX=MAP_ALIVE_V2893.buildings;
 for(const o of items){
  if(o.buildingId==='spirit_spring')continue;
  const k=landmarkKindV2893(o),list=k&&FX[k];if(!list)continue;
  for(const a of list){
   const isGround=a.fx==='formation';if(isGround!==ground)continue;
   const q=landmarkPointV2893(o,a.x,a.y),s=q.s,seed=(o.x*7+o.y*3+a.x)%17;
   if(a.fx==='formation'){const pulse=.5+.5*Math.sin(t*1.6+seed);ctx.save();ctx.translate(q.x,q.y);ctx.rotate(t*.25);ctx.strokeStyle=`rgba(150,230,255,${.18+.22*pulse})`;ctx.lineWidth=1.6;ctx.setLineDash([6,7]);ctx.beginPath();ctx.ellipse(0,0,34*s,14*s,0,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);ctx.restore();}
   else if(a.fx==='smoke'){for(let i=0;i<3;i++){const age=((t*.22+i/3+seed*.05)%1);ctx.fillStyle=`rgba(225,225,215,${.32*(1-age)})`;ctx.beginPath();ctx.arc(q.x+Math.sin(t*.8+i+seed)*4*age+age*8,q.y-age*34*s,(3+age*7)*s,0,Math.PI*2);ctx.fill();}}
   else if(a.fx==='banner'){const w=Math.sin(t*3.2+seed)*3;ctx.fillStyle='rgba(176,44,44,.9)';ctx.beginPath();ctx.moveTo(q.x,q.y-16*s);ctx.quadraticCurveTo(q.x+7*s,q.y-15*s+w,q.x+14*s,q.y-13*s+w*1.4);ctx.lineTo(q.x+13*s,q.y-6*s+w*1.4);ctx.quadraticCurveTo(q.x+7*s,q.y-8*s+w,q.x,q.y-8*s);ctx.closePath();ctx.fill();ctx.strokeStyle='rgba(80,50,30,.9)';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(q.x,q.y);ctx.lineTo(q.x,q.y-17*s);ctx.stroke();}
   else if(a.fx==='pulse'){const img=sp.cyan;if(img){ctx.globalAlpha=.25+.25*Math.sin(t*2+seed);const z=26*s;ctx.drawImage(img,q.x-z/2,q.y-z/2,z,z);ctx.globalAlpha=1;}}
   else if(a.fx==='motes'){const img=sp.warm;if(img)for(let i=0;i<3;i++){const age=(t*.3+i/3)%1;ctx.globalAlpha=.5*(1-age);const z=8;ctx.drawImage(img,q.x+Math.sin(t+i*2)*10-z/2,q.y-age*30-z/2,z,z);}ctx.globalAlpha=1;}
   else if(a.fx==='lantern'&&night){const img=sp.warm;if(img){const f=.75+.25*Math.sin(t*7+seed*3)*Math.sin(t*3.1+seed);ctx.globalAlpha=.55*f;const z=30*s;ctx.drawImage(img,q.x-z/2,q.y-z/2,z,z);ctx.globalAlpha=1;}}
  }
 }
}

// ------------------------------------------------------------ easter eggs (session only, no rewards) ----
function updateEggsV2893(dt,view,vw,vh,phase,region,lv){
 const E=MAP_ALIVE_V2893.eggs,rand=aliveRandV2893,p=FLAT_WORLD.player;
 if(!lv.eggs){ALIVE_V2893.meteor=ALIVE_V2893.crane=ALIVE_V2893.fox=null;return;}
 // 流星: night sky, screen space
 if(!ALIVE_V2893.meteor&&phase==='night'&&rand()<E.meteorPerSec*dt)ALIVE_V2893.meteor={x:vw*(.2+rand()*.6),y:vh*(.05+rand()*.2),age:0};
 if(ALIVE_V2893.meteor){ALIVE_V2893.meteor.age+=dt;if(ALIVE_V2893.meteor.age>1.1){ALIVE_V2893.meteor=null;if(!ALIVE_V2893.toldMeteor){ALIVE_V2893.toldMeteor=true;showFloatingText?.('流星划过天际。','#d9e8ff');}}}
 // 仙鹤: after standing still for a while
 ALIVE_V2893.craneCd=Math.max(0,ALIVE_V2893.craneCd-dt);
 if(!ALIVE_V2893.crane&&ALIVE_V2893.craneCd<=0&&ALIVE_V2893.idle>=E.craneIdleSec&&region!=='demon_domain'){
  const left=rand()<.5;ALIVE_V2893.crane={x:left?view.minX-60:view.maxX+60,y:p.y-120-rand()*60,vx:left?70:-70,age:0};ALIVE_V2893.craneCd=E.craneCooldownSec;
 }
 const c=ALIVE_V2893.crane;if(c){c.age+=dt;c.x+=c.vx*dt;c.y+=Math.sin(c.age*1.4)*8*dt;
  if(!ALIVE_V2893.toldCrane&&Math.abs(c.x-p.x)<40){ALIVE_V2893.toldCrane=true;showFloatingText?.('鹤鸣于九皋，声闻于天。','#f2f0e0');}
  if(c.x<view.minX-200||c.x>view.maxX+200)ALIVE_V2893.crane=null;}
 // 灵狐: peeks near trees or forest landmarks, flees when approached
 const f=ALIVE_V2893.fox;
 if(!f&&rand()<E.foxChancePerSec*dt){
  const near=(FLAT_WORLD.decor||[]).find(d=>d.t==='tree'&&d.x>view.minX&&d.x<view.maxX&&d.y>view.minY&&d.y<view.maxY&&Math.hypot(d.x-p.x,d.y-p.y)<E.foxRange&&Math.hypot(d.x-p.x,d.y-p.y)>E.foxFleeDist*1.6);
  if(near)ALIVE_V2893.fox={x:near.x+18,y:near.y+12,fleeing:false,vx:0,age:0,alpha:0};
 }
 if(f){f.age+=dt;if(!f.fleeing)f.alpha=Math.min(1,f.alpha+dt*2);
  if(!f.fleeing&&Math.hypot(f.x-p.x,f.y-p.y)<E.foxFleeDist){f.fleeing=true;f.vx=(f.x>p.x?1:-1)*220;if(!ALIVE_V2893.toldFox){ALIVE_V2893.toldFox=true;showFloatingText?.('一只灵狐倏然遁入林间。','#ffd2a0');}}
  if(f.fleeing){f.x+=f.vx*dt;f.alpha-=dt*1.6;}
  if(f.alpha<=0&&f.fleeing||f.age>20)ALIVE_V2893.fox=null;}
}
function drawFoxV2893(ctx,t){
 const f=ALIVE_V2893.fox;if(!f)return;const dir=f.vx<0?-1:1;
 ctx.save();ctx.globalAlpha=Math.max(0,f.alpha);ctx.translate(f.x,f.y);ctx.scale(dir,1);
 ctx.fillStyle='rgba(10,14,12,.18)';ctx.beginPath();ctx.ellipse(0,6,11,3,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#e48a3c';ctx.beginPath();ctx.ellipse(0,0,8,5,0,0,Math.PI*2);ctx.fill();
 ctx.beginPath();ctx.ellipse(-10,-2+Math.sin(t*6)*1.5,7,3.2,-.5,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#fff3e0';ctx.beginPath();ctx.ellipse(-15,-5+Math.sin(t*6)*1.5,2.4,1.6,-.5,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#e48a3c';ctx.beginPath();ctx.arc(8,-4,4,0,Math.PI*2);ctx.fill();
 ctx.beginPath();ctx.moveTo(6,-7);ctx.lineTo(7,-12);ctx.lineTo(9,-7);ctx.moveTo(9,-7);ctx.lineTo(11,-11);ctx.lineTo(11.5,-6);ctx.fill();
 ctx.restore();
}
function drawCraneV2893(ctx,t){
 const c=ALIVE_V2893.crane;if(!c)return;const dir=c.vx<0?-1:1,f=Math.sin(t*4)*7;
 ctx.save();ctx.translate(c.x,c.y);ctx.scale(dir,1);ctx.strokeStyle='rgba(250,250,245,.95)';ctx.lineWidth=2.4;ctx.lineCap='round';
 ctx.beginPath();ctx.moveTo(-16,-f);ctx.quadraticCurveTo(-6,-4,0,0);ctx.quadraticCurveTo(6,-4,16,-f);ctx.stroke();
 ctx.lineWidth=1.6;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(12,-2);ctx.moveTo(0,0);ctx.lineTo(-12,3);ctx.stroke();
 ctx.fillStyle='#c0392b';ctx.beginPath();ctx.arc(12.5,-2.5,1.4,0,Math.PI*2);ctx.fill();ctx.restore();
 ctx.fillStyle='rgba(10,16,14,.1)';ctx.beginPath();ctx.ellipse(c.x+30,c.y+170,14,3.5,0,0,Math.PI*2);ctx.fill();
}
function drawMeteorV2893(ctx,dpr){
 const m=ALIVE_V2893.meteor;if(!m)return;const k=m.age/1.1,x=m.x+k*180,y=m.y+k*70;
 ctx.setTransform(dpr,0,0,dpr,0,0);const g=ctx.createLinearGradient(x-60,y-24,x,y);g.addColorStop(0,'rgba(220,235,255,0)');g.addColorStop(1,`rgba(240,248,255,${.9*(1-k)})`);
 ctx.strokeStyle=g;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x-60,y-24);ctx.lineTo(x,y);ctx.stroke();
}

// ------------------------------------------------------------ frame: ground layer ----
// Called by drawFlatWorld right after the ground ambience, before buildings and actors are drawn.
function mapAliveGroundV2893(ctx,t){
 try{
  if(ctx?.canvas?.id==='worldCanvas'&&mapAliveQualityV2893()!=='off'){
   const tt=ALIVE_V2893.clock||0,calm=mapAliveCalmV2893();
   if(!calm)drawStepsV2893(ctx);if(!calm)drawBirdShadowsV2893(ctx);
   if(mapAliveLevelV2893().buildings)drawBuildingLifeV2893(ctx,FLAT_WORLD._drawItems||[],calm?0:tt,mapDayPhaseV2893(),true);
  }
 }catch(e){console.warn('灵动地面层失败',e);}
}

// ------------------------------------------------------------ frame: top + screen layers ----
// Called by drawFlatWorld once the world layer is finished (screen space), before V2888's haze and mist.
function mapAliveFrameV2893(t,dt){try{mapAliveFrameInnerV2893(t,dt);}catch(e){console.warn('山河灵动失败',e);}}
function mapAliveFrameInnerV2893(t,dt){
 const c=document.getElementById('worldCanvas');if(!c)return;
 const q=mapAliveQualityV2893();if(q==='off')return;
 const lv=MAP_ALIVE_V2893.quality.levels[q],ctx=c.getContext('2d'),dpr=c._dpr||1,vw=c.width/dpr,vh=c.height/dpr;
 dt=Math.max(0,Math.min(.05,Number(dt)||1/60));const calm=mapAliveCalmV2893();
 if(!calm)ALIVE_V2893.clock=(ALIVE_V2893.clock||0)+dt;const tt=ALIVE_V2893.clock||0;
 const region=mapRegionV2893(),season=mapSeasonV2893(),weather=mapWeatherV2893(),phase=mapDayPhaseV2893();
 const key=region+'|'+weather;if(key!==ALIVE_V2893.regionKey){ALIVE_V2893.regionKey=key;ALIVE_V2893.fall.length=0;ALIVE_V2893.rain.length=0;ALIVE_V2893.glow.length=0;}
 const cam=FLAT_WORLD._camDrawV2893||FLAT_WORLD.camera,last=ALIVE_V2893.lastCam,camDX=last?cam.x-last.x:0,camDY=last?cam.y-last.y:0;ALIVE_V2893.lastCam={x:cam.x,y:cam.y};
 const view={minX:cam.x,maxX:cam.x+vw,minY:cam.y,maxY:cam.y+vh};
 // update (skipped when the player asked for reduced motion)
 if(!calm){
  stepJuiceV2893(dt,weather,lv,region);
  updateFallV2893(dt,vw,vh,camDX,camDY,mapFallKindV2893(region,season,weather),lv.fall,tt);
  updateRainV2893(dt,vw,vh,weather==='rain'?lv.rain:0);
  updateGlowV2893(dt,view,lv.glow,glowKindV2893(region,season,phase,weather),tt);
  updateBirdsV2893(dt,view,region==='demon_domain'?0:lv.birds);
  updateEggsV2893(dt,view,vw,vh,phase,region,lv);
 }else{for(const k of ['fall','rain','glow','birds','dust','ripples'])ALIVE_V2893[k].length=0;ALIVE_V2893.meteor=ALIVE_V2893.crane=ALIVE_V2893.fox=null;}
 ctx.save();
 try{
  // world space: buildings, birds, fox, crane
  ctx.setTransform(dpr,0,0,dpr,-cam.x*dpr,-cam.y*dpr);

  drawFoxV2893(ctx,tt);drawBirdsV2893(ctx,tt);drawCraneV2893(ctx,tt);
  // screen space: falling things, rain, weather and day tint
  drawFallV2893(ctx,dpr);drawRainV2893(ctx,dpr);
  ctx.setTransform(dpr,0,0,dpr,0,0);
  const wt=MAP_ALIVE_V2893.weatherTint[weather];if(wt){ctx.fillStyle=wt;ctx.fillRect(0,0,vw,vh);}
  const dn=MAP_ALIVE_V2893.dayNight.tints[phase];if(dn){ctx.fillStyle=dn;ctx.fillRect(0,0,vw,vh);}
  // glows shine through the tint; additive only at night (on light daytime ground it washes out to white)
  if(phase==='night')ctx.globalCompositeOperation='lighter';
  ctx.setTransform(dpr,0,0,dpr,-cam.x*dpr,-cam.y*dpr);drawGlowV2893(ctx,tt);
  ctx.globalCompositeOperation='source-over';
  drawMeteorV2893(ctx,dpr);
 }finally{ctx.restore();}
}

// ------------------------------------------------------------ quality button ----
function ensureMapAliveButtonV2893(){
 const host=document.getElementById('worldExploreActions');if(!host)return;if(document.getElementById('mapAliveBtnV2893')){syncMapAliveButtonV2893();return;}
 const b=document.createElement('button');b.type='button';b.id='mapAliveBtnV2893';b.onclick=cycleMapAliveV2893;host.appendChild(b);syncMapAliveButtonV2893();
}
function syncMapAliveButtonV2893(){
 const b=document.getElementById('mapAliveBtnV2893');if(!b)return;const Q=MAP_ALIVE_V2893.quality,q=mapAliveQualityV2893();
 b.textContent=`灵动 · ${Q.names[q]}`;b.setAttribute('aria-pressed',String(q!=='off'));
 try{b.title=`今日天象：${MAP_ALIVE_V2893.weatherNames[mapWeatherV2893()]||'晴'} · ${MAP_ALIVE_V2893.dayNight.names[mapDayPhaseV2893()]}。点按切换 高 / 低 / 关（只影响画面）`;}catch(_){}
}


function mapAliveBuildingV2893(ctx,o){
 if(ctx?.canvas?.id!=='worldCanvas'||!mapAliveLevelV2893().buildings)return;
 ctx.save();try{drawBuildingLifeV2893(ctx,[o],mapAliveCalmV2893()?0:(ALIVE_V2893.clock||0),mapDayPhaseV2893(),false);}finally{ctx.restore();}
}
// END MAP_ALIVE_V2893
;// BEGIN SAVE_UI_V2895
// V28.68.73 存档护身 + 手机界面（内部标识 V2895）：
//  1) 申请浏览器持久保存（navigator.storage.persist）；
//  2) 主存档写入成功后，另存一份到 IndexedDB 备用库（独立于 localStorage），本地存档丢失时可在开场恢复；
//  3) 定期提醒导出存档（7天未导出且有进展、或新入大境界）；
//  4) 小地图缩放按钮与顶部状态文字放大。
// 不改存档格式、数值、战斗或剧情。localStorage 仍是唯一的“主存档”；备用库只读出来做恢复，绝不自动覆盖主档。
const SAVEUI_V2895=(()=>{const deep=o=>{for(const v of Object.values(o))if(v&&typeof v==='object')deep(v);return Object.freeze(o);};return deep({
 mirror:{
  db:'xiantu_save_mirror_v2895',store:'saves',
  minIntervalMs:15000,        // at most one IndexedDB write per 15 s (autosave runs every 30 s); flushed on page hide
  dailyMs:20*3600*1000,       // refresh the older fallback at most every 20 h; its age is not guaranteed to be a full day
  openTimeoutMs:4000
 },
 persist:{
  retryMs:3*86400*1000,       // re-ask the browser at most every 3 days until granted
  autoAsk:true,               // ask on the first tap of a session (Chromium and Safari decide silently)
  autoAskFirefox:false        // Firefox shows a permission prompt, so there it is only asked from the button
 },
 remind:{
  everyDays:7,                // overdue after 7 days without an export, if the character progressed since
  firstAfterDays:2,           // a character that was never exported: first reminder 2 days after it was first saved here
  milestoneMinGapDays:1,      // a new major realm since the last export also reminds, at most once a day
  snoozeHours:20,             // 稍后 hides it for 20 h
  sessionDelayMs:90000,       // never in the first 90 s of a session
  checkMs:60000
 },
 ui:{
  zoomButton:36,              // minimap −/＋ visible size (was 26 px); the pill is only as wide as the minimap
  zoomGap:2,                  // gap inside the zoom pill (was 5 px)
  zoomLabelWidth:26,          // 1.0× label width (was 34 px)
  hitTarget:44,               // invisible touch area around them
  zoomFont:21,
  realmText:12,               // 凡人初期 under the name (was 10 px)
  hudButtonText:12,           // 任务 / 角色 / 物品 (was 11 px)
  areaText:12,                // 南域 · 繁华人间 (was 11 px)
  minimapHead:12,             // 小地图 (was 8 px)
  zoomLabel:12,               // 1.0× (was 9 px)
  saveIndicator:12,           // ✓ 已记入玉简 (was 11 px)
  hudToggleMin:44,            // ▾ button width (was 36 px)
  narrowWidth:379             // at or below this width the HUD buttons put the icon above the word instead of cutting it off
 },
 keys:{persist:'xiantu_persist_v2895',exported:'xiantu_export_v2895',firstSeen:'xiantu_first_seen_v2895',
  snooze:'xiantu_export_snooze_v2895',cleared:'xiantu_mirror_cleared_v2895'}
});})();

const SAVEUI_STATE_V2895={
 mirror:{epoch:0,clearing:null,pending:null,timer:null,busy:false,lastWrite:0,status:'idle',lastOkAt:0,lastMeta:null,writes:0},
 persist:{state:'unknown',busy:false,askedThisSession:false},
 remind:{sessionStart:Date.now(),shownThisSession:false,timer:null},
 offerShown:false
};

// ---------------------------------------------------------------- small helpers
function suLsGetV2895(k){try{return localStorage.getItem(k);}catch(_){return null;}}
function suLsSetV2895(k,v){try{localStorage.setItem(k,v);return true;}catch(_){return false;}}
function suJsonV2895(k){try{return JSON.parse(suLsGetV2895(k)||'null');}catch(_){return null;}}
function suEscV2895(v){return typeof escapeGameText==='function'?escapeGameText(v):String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function suHasLocalSaveV2895(){
 try{return localStorage.getItem(SAVE_KEY)!==null||localStorage.getItem(SAVE_BACKUP_KEY)!==null;}catch(_){return true;}
}
// gameState starts as 'exploring' even on the title screen, so the screen itself decides.
function suOnStartScreenV2895(){const s=document.getElementById('startScreen'),g=document.getElementById('gameScreen');return !!s&&!s.classList.contains('hidden')&&(!g||g.classList.contains('hidden'));}
function suIsIOSV2895(){const ua=navigator.userAgent||'';return /iPhone|iPad|iPod/i.test(ua)||(/Macintosh/i.test(ua)&&navigator.maxTouchPoints>1);}
function suStandaloneV2895(){try{return navigator.standalone===true||!!window.matchMedia?.('(display-mode: standalone)').matches;}catch(_){return false;}}
function suIsFirefoxV2895(){return /Firefox\//.test(navigator.userAgent||'');}
function suAgoV2895(t){
 if(!t)return'';const d=Date.now()-t;if(d<3600e3)return'不到一小时前';if(d<86400e3)return Math.floor(d/3600e3)+' 小时前';return Math.floor(d/86400e3)+' 天前';
}
function suMetaV2895(raw){
 try{const d=JSON.parse(raw),p=d?.player||{};
  const realm=typeof getCultivationName==='function'?getCultivationName(p.level,p.phase):String(p.level);
  return {name:String(p.name||'无名').slice(0,24),realm,level:Number(p.level)||0,ts:Number(d.timestamp)||0};
 }catch(_){return null;}
}

// ---------------------------------------------------------------- IndexedDB mirror
let suDbPromiseV2895=null;
function suDbV2895(){
 if(suDbPromiseV2895)return suDbPromiseV2895;
 const M=SAVEUI_V2895.mirror;
 suDbPromiseV2895=new Promise((resolve,reject)=>{
  let req;try{if(!window.indexedDB)throw Error('IndexedDB unavailable');req=indexedDB.open(M.db,1);}catch(e){reject(e);return;}
  let ended=false;const fail=e=>{ended=true;reject(e);};
  const timer=setTimeout(()=>fail(Error('IndexedDB open timeout')),M.openTimeoutMs);
  req.onupgradeneeded=()=>{try{req.result.createObjectStore(M.store);}catch(_){}};
  req.onsuccess=()=>{clearTimeout(timer);const db=req.result;if(ended){db.close();return;}db.onversionchange=()=>{try{db.close();}catch(_){}suDbPromiseV2895=null;};resolve(db);};
  req.onerror=()=>{clearTimeout(timer);fail(req.error||Error('IndexedDB open failed'));};
  req.onblocked=()=>{clearTimeout(timer);fail(Error('IndexedDB blocked'));};
 });
 suDbPromiseV2895.catch(()=>{suDbPromiseV2895=null;SAVEUI_STATE_V2895.mirror.status='unavailable';});
 return suDbPromiseV2895;
}
function suTxV2895(mode,fn){
 return suDbV2895().then(db=>new Promise((resolve,reject)=>{
  const tx=db.transaction(SAVEUI_V2895.mirror.store,mode),st=tx.objectStore(SAVEUI_V2895.mirror.store);let out;
  try{out=fn(st);}catch(e){try{tx.abort();}catch(_){}reject(e);return;}
  tx.oncomplete=()=>resolve(out&&'result' in out?out.result:undefined);
  tx.onerror=()=>reject(tx.error||Error('IndexedDB write failed'));tx.onabort=()=>reject(tx.error||Error('IndexedDB aborted'));
 }));
}
function suIdbGetV2895(key){return suTxV2895('readonly',st=>st.get(key));}

// Called by writeSaveV2768 after the localStorage main save succeeded. Coalesces to the latest raw.
function saveMirrorV2895(raw){
 if(typeof raw!=='string'||!raw||suLsGetV2895(SAVE_KEY)!==raw)return;
 try{if(parseSaveV2768(raw).player.testAccount999)return;}catch(_){return;}
 const S=SAVEUI_STATE_V2895.mirror;S.pending=raw;
 if(!suLsGetV2895(SAVEUI_V2895.keys.firstSeen))suLsSetV2895(SAVEUI_V2895.keys.firstSeen,String(Date.now()));
 suMirrorScheduleV2895();
}
function suMirrorScheduleV2895(now){
 const S=SAVEUI_STATE_V2895.mirror;if(S.busy||!S.pending)return;
 if(now){if(S.timer){clearTimeout(S.timer);S.timer=null;}suMirrorFlushV2895();return;}
 if(S.timer)return;
 const wait=Math.max(0,S.lastWrite+SAVEUI_V2895.mirror.minIntervalMs-Date.now());
 S.timer=setTimeout(()=>{S.timer=null;suMirrorFlushV2895();},wait);
}
async function suMirrorFlushV2895(){
 const S=SAVEUI_STATE_V2895.mirror;if(S.busy||!S.pending)return;
 const raw=S.pending,epoch=S.epoch,queuedAt=Date.now();S.pending=null;S.busy=true;S.lastWrite=queuedAt;
 try{
  if(S.clearing)await S.clearing;
  if(epoch!==S.epoch||suLsGetV2895(SAVE_KEY)!==raw)return;
  const meta=suMetaV2895(raw);if(!meta)throw Error('存档无法读取');
  const rec={raw,...meta,savedAt:Date.now()};
  let written=false;
  // Read/rotate/write in one transaction. A durable tombstone also blocks older writes from other tabs.
  await suTxV2895('readwrite',st=>{
   const cleared=st.get('cleared'),previous=st.get('main'),oldDaily=st.get('daily');
   oldDaily.onsuccess=()=>{
    if(epoch!==S.epoch||suLsGetV2895(SAVE_KEY)!==raw||queuedAt<=(Number(cleared.result)||0))return;
    const prevMain=previous.result,daily=oldDaily.result;
    const rotate=prevMain&&prevMain.raw!==raw&&(!daily||rec.savedAt-daily.savedAt>=SAVEUI_V2895.mirror.dailyMs);
    st.put(rec,'main');if(rotate)st.put(prevMain,'daily');written=true;
   };
  });
  if(!written||epoch!==S.epoch)return;
  S.status='ok';S.lastOkAt=rec.savedAt;S.lastMeta=meta;S.writes++;
 }catch(e){
  S.status=S.status==='unavailable'||/unavailable|blocked|timeout|open/i.test(String(e?.message))?'unavailable':'error';
  console.warn('备用库写入失败（不影响主存档）',e);
 }finally{
  S.busy=false;if(S.pending)suMirrorScheduleV2895();
 }
}
// deleteSave() was called: older mirror records must never be offered back.
function saveMirrorClearedV2895(){
 const S=SAVEUI_STATE_V2895.mirror,at=Date.now();S.epoch++;
 suLsSetV2895(SAVEUI_V2895.keys.cleared,String(at));
 S.pending=null;if(S.timer)clearTimeout(S.timer);S.timer=null;
 document.getElementById('mirrorOfferV2895')?.remove();
 document.getElementById('saveRemindV2895')?.remove();
 S.clearing=suTxV2895('readwrite',st=>{st.put(at,'cleared');st.delete('main');st.delete('daily');}).catch(()=>{});
}
function suMirrorCurrentV2895(rec,epoch){
 return epoch===SAVEUI_STATE_V2895.mirror.epoch&&rec.savedAt>(Number(suLsGetV2895(SAVEUI_V2895.keys.cleared))||0);
}
// Newest valid mirror record that is newer than the last deliberate delete. Never throws.
async function suMirrorBestV2895(onlyKey=null){
 const epoch=SAVEUI_STATE_V2895.mirror.epoch;
 if(SAVEUI_STATE_V2895.mirror.clearing)await SAVEUI_STATE_V2895.mirror.clearing;
 let durable;try{durable=Number(await suIdbGetV2895('cleared'))||0;}catch(_){return null;}
 const cleared=Math.max(durable,Number(suLsGetV2895(SAVEUI_V2895.keys.cleared))||0);
 for(const key of onlyKey?[onlyKey]:['main','daily']){
  try{
   const rec=await suIdbGetV2895(key);
   if(!rec||typeof rec.raw!=='string'||!Number.isFinite(rec.savedAt)||!(rec.savedAt>cleared)||!suMirrorCurrentV2895(rec,epoch))continue;
   const data=dryRunLoadV2870(rec.raw);
   return {key,rec,data,epoch};
  }catch(_){}
 }
 return null;
}

// Start screen with no local save at all: offer the mirror copy. Only ever writes after the player agrees.
async function saveMirrorOfferV2895(){
 const st=SAVEUI_STATE_V2895;
 if(st.offerShown||suHasLocalSaveV2895()||!suOnStartScreenV2895())return false;
 st.offerShown=true;
 const best=await suMirrorBestV2895();
 if(!best||!suMirrorCurrentV2895(best.rec,best.epoch)||suHasLocalSaveV2895()||!suOnStartScreenV2895()){st.offerShown=false;return false;}
 const {rec}=best,m=suMetaV2895(rec.raw)||{};
 document.getElementById('mirrorOfferV2895')?.remove();
 const el=document.createElement('div');el.id='mirrorOfferV2895';el.className='mobile-inventory-overlay';el.style.zIndex='100002';
 el.innerHTML=`<div class="mobile-inventory-card su-card-v2895" role="dialog" aria-modal="true" aria-labelledby="mirrorOfferTitleV2895">
  <h3 id="mirrorOfferTitleV2895">📜 找到备用玉简</h3>
  <p>这台设备上的主存档已经不在了，但浏览器备用库里还留着一份修行记录：</p>
  <p class="su-rec-v2895"><b>${suEscV2895(m.name)}</b> · ${suEscV2895(m.realm)}<br><small>保存于 ${suEscV2895(typeof formatSaveTime==='function'?formatSaveTime(rec.savedAt):new Date(rec.savedAt).toLocaleString())}${best.key==='daily'?'（较早的一份）':''}</small></p>
  <p>恢复后可直接续行仙途。不恢复也不会删除它，之后仍可在【存档管理】里找到。</p>
  <div class="su-row-v2895"><button type="button" class="choice-btn" data-su="restore">恢复这份记录</button><button type="button" class="choice-btn" data-su="skip">暂不恢复</button></div></div>`;
 el.addEventListener('click',e=>{
  const b=e.target.closest('[data-su]');if(!b)return;
  if(b.dataset.su==='skip'){el.remove();return;}
  try{
   if(!el.isConnected||!suOnStartScreenV2895()||!suMirrorCurrentV2895(rec,best.epoch))throw Error('恢复入口已过期，请重新打开。');
   dryRunLoadV2870(rec.raw);
   if(suHasLocalSaveV2895())throw Error('本地已有存档，未覆盖。请到【存档管理】中操作。');
   writeSaveV2768(rec.raw);
   el.remove();
   const info=document.getElementById('saveInfo');if(info)info.innerHTML='已从浏览器备用库恢复修行记录。<br>点击“续行仙途”继续。';
   const dialog=document.getElementById('loadDialog');if(dialog)dialog.style.display='flex';
   try{window.refreshTitleSaveCardV2868120?.();}catch(_){}
  }catch(err){gameAlertV2868114('恢复失败：'+(err?.message||err));}
 });
 document.body.appendChild(el);el.querySelector('[data-su="restore"]')?.focus?.();
 return true;
}

// ---------------------------------------------------------------- persistent storage
async function suPersistQueryV2895(){
 const P=SAVEUI_STATE_V2895.persist;
 if(!navigator.storage?.persist||!navigator.storage?.persisted){P.state='unsupported';return P.state;}
 try{if(await navigator.storage.persisted())P.state='granted';else P.state='not';}catch(_){}
 return P.state;
}
async function requestPersistV2895(){
 const P=SAVEUI_STATE_V2895.persist;
 if(!navigator.storage?.persist){P.state='unsupported';return P.state;}
 if(P.busy)return P.state;P.busy=true;P.askedThisSession=true;
 try{const ok=await navigator.storage.persist();P.state=ok?'granted':'denied';}
 catch(_){P.state='error';}
 finally{P.busy=false;suLsSetV2895(SAVEUI_V2895.keys.persist,JSON.stringify({at:Date.now(),state:P.state}));}
 return P.state;
}
function suPersistAutoOkV2895(){
 const C=SAVEUI_V2895.persist,P=SAVEUI_STATE_V2895.persist;
 if(!C.autoAsk||P.askedThisSession||P.state==='granted'||P.state==='unsupported')return false;
 if(suIsFirefoxV2895()&&!C.autoAskFirefox)return false;
 if(suOnStartScreenV2895()||!suHasLocalSaveV2895())return false;
 const last=suJsonV2895(SAVEUI_V2895.keys.persist);
 return !(last&&Date.now()-last.at<C.retryMs);
}
function suPersistGestureV2895(){
 if(!suPersistAutoOkV2895())return;
 suPersistQueryV2895().then(state=>{if(state!=='granted'&&suPersistAutoOkV2895())requestPersistV2895();});
}

// ---------------------------------------------------------------- export reminder
function suFingerprintV2895(p=player){
 if(!p)return'';return [p.level|0,p.phase|0,Math.floor(Number(p.exp)||0),Math.floor(Number(p.gold)||0)].join('|');
}
// Called after a successful export or copy of the current save. Writes device-only keys, never the save,
// so exporting cannot itself count as "progress since the export".
function saveExportedV2895(kind,raw){
 let source=player;try{if(raw)source=parseSaveV2768(raw).player;}catch(_){return null;}
 if(source?.testAccount999)return null;
 const rec={at:Date.now(),fp:suFingerprintV2895(source),level:source?.level|0,kind:String(kind||'file')};
 suLsSetV2895(SAVEUI_V2895.keys.exported,JSON.stringify(rec));
 document.getElementById('saveRemindV2895')?.remove();
 return rec;
}
// Pure decision, testable: returns null or {reason, days}.
function exportReminderDueV2895(now=Date.now(),p=player){
 const C=SAVEUI_V2895.remind,K=SAVEUI_V2895.keys,day=86400e3;
 if(!p||p.testAccount999)return null;
 const snooze=Number(suLsGetV2895(K.snooze))||0;if(now-snooze<C.snoozeHours*3600e3)return null;
 const last=suJsonV2895(K.exported);
 if(!last){
  const first=Number(suLsGetV2895(K.firstSeen))||0;
  if(!first||now-first<C.firstAfterDays*day)return null;
  return {reason:'never',days:Math.floor((now-first)/day)};
 }
 const days=Math.floor((now-last.at)/day),progressed=last.fp!==suFingerprintV2895(p);
 if((p.level|0)>(last.level|0)&&now-last.at>=C.milestoneMinGapDays*day)return {reason:'realm',days};
 if(days>=C.everyDays&&progressed)return {reason:'overdue',days};
 return null;
}
function suQuietV2895(){
 if(document.hidden||typeof gameState==='undefined'||gameState!=='exploring'||suOnStartScreenV2895())return false;
 if(typeof isWorldOverlayOpen==='function'&&isWorldOverlayOpen())return false;
 if(document.querySelector('.mobile-inventory-overlay, .help-manual-overlay.active, #tutorialUnlock, #saveRemindV2895, #mirrorOfferV2895'))return false;
 if(player?.breakthrough?.isAnimating)return false;
 return true;
}
function suIosHintV2895(){
 if(!suIsIOSV2895()||suStandaloneV2895())return'';
 return '<p class="su-small-v2895">iPhone / iPad：Safari 可能清理久未打开网站的数据。可先导出存档，再用「分享 → 添加到主屏幕」从主屏幕打开游戏，并在那里导入存档（不同打开方式的数据可能不共享，请先确认备份可用）。</p>';
}
function showExportReminderV2895(due){
 document.getElementById('saveRemindV2895')?.remove();
 const realm=typeof getCultivationName==='function'?getCultivationName():'';
 const why=due.reason==='realm'?`你已踏入<b>${suEscV2895(realm)}</b>，建议把这一刻导出留存。`
  :due.reason==='never'?'这位角色还没有导出过存档。'
  :`距上次导出已 <b>${due.days}</b> 天，期间修为又有长进。`;
 const el=document.createElement('div');el.id='saveRemindV2895';el.className='su-remind-v2895';el.setAttribute('role','status');
 el.innerHTML=`<div class="su-remind-title-v2895">📜 玉简备份</div><p>${why}修行记录只存在这台设备的浏览器里，清理浏览器数据或换手机都会丢失。</p>${suIosHintV2895()}
  <div class="su-row-v2895"><button type="button" class="choice-btn" data-su="export">导出存档</button><button type="button" class="choice-btn" data-su="copy">复制存档文本</button><button type="button" class="choice-btn su-later-v2895" data-su="later">稍后</button></div>`;
 el.addEventListener('click',e=>{
  const b=e.target.closest('[data-su]');if(!b)return;
  if(b.dataset.su==='export')exportSaveV2768();
  else if(b.dataset.su==='copy')copySaveTextV2870();
  else{suLsSetV2895(SAVEUI_V2895.keys.snooze,String(Date.now()));el.remove();}
 });
 document.body.appendChild(el);SAVEUI_STATE_V2895.remind.shownThisSession=true;
 return el;
}
function suRemindTickV2895(){
 const R=SAVEUI_STATE_V2895.remind;
 const card=document.getElementById('saveRemindV2895');if(card&&(document.hidden||gameState!=='exploring'||suOnStartScreenV2895()||isWorldOverlayOpen()||player?.breakthrough?.isAnimating))card.remove();
 if(R.shownThisSession||Date.now()-R.sessionStart<SAVEUI_V2895.remind.sessionDelayMs||!suQuietV2895())return null;
 const due=exportReminderDueV2895();if(!due)return null;
 return showExportReminderV2895(due);
}

// ---------------------------------------------------------------- save manager section
function suPersistTextV2895(state){
 return {granted:'已获浏览器授予，可降低空间紧张时被清理的风险；手动清除网站数据仍会删除存档。',denied:'浏览器暂未授予。存档仍会保存，但空间紧张时可能被清理，请定期导出。',
  not:'尚未授予。存档仍会保存，但空间紧张时可能被清理，请定期导出。',unsupported:'此浏览器不支持持久保存，请定期导出。',
  error:'申请时出错，请稍后再试。',unknown:'正在查询…'}[state]||'正在查询…';
}
async function saveManagerExtraV2895(el){
 const owner=player;const card=el?.querySelector?.('.mobile-inventory-card');if(!card)return;
 card.querySelector('.su-manager-v2895')?.remove();
 const sec=document.createElement('section');sec.className='su-manager-v2895';
 const last=suJsonV2895(SAVEUI_V2895.keys.exported);
 sec.innerHTML=`<hr><h4>🛡️ 存档护身</h4>
  <p><b>持久保存：</b><span data-su="persist">${suPersistTextV2895(SAVEUI_STATE_V2895.persist.state)}</span></p>
  <button type="button" class="choice-btn" data-su="ask" hidden>申请持久保存</button>
  <p class="su-small-v2895">备用库与主档都在当前浏览器中。清除整站数据可能同时删除两份；请另行导出留存。</p>
  <p><b>备用库：</b><span data-su="mirror">正在查询…</span></p>
  <div class="su-row-v2895" data-su="mirrorBtns" hidden><button type="button" class="choice-btn" data-su="mrestore">从备用库恢复</button><button type="button" class="choice-btn" data-su="mexport">导出备用库记录</button></div>
  <p><b>上次导出：</b>${last?suAgoV2895(last.at):'尚未导出过'}。建议每周导出一次，存到网盘、电脑或聊天文件里。</p>${suIosHintV2895()}`;
 const close=[...card.querySelectorAll(':scope > button')].pop();
 close?card.insertBefore(sec,close):card.appendChild(sec);
 const ask=sec.querySelector('[data-su="ask"]');
 const paint=state=>{sec.querySelector('[data-su="persist"]').textContent=suPersistTextV2895(state);ask.hidden=!(state==='not'||state==='denied'||state==='error');};
 const state=await suPersistQueryV2895();if(!el.isConnected||player!==owner||!sec.querySelector('[data-su="persist"]'))return;paint(state);
 ask.onclick=async()=>{ask.disabled=true;const state=await requestPersistV2895();if(el.isConnected&&sec.querySelector('[data-su="persist"]')){paint(state);ask.disabled=false;}};
 const best=await suMirrorBestV2895();
 if(!el.isConnected||player!==owner)return;
 const mt=sec.querySelector('[data-su="mirror"]');
 if(!best){mt.textContent=SAVEUI_STATE_V2895.mirror.status==='unavailable'?'此浏览器不能使用（例如无痕模式）。':'暂无记录（下次自动保存后生成）。';return;}
 const m=suMetaV2895(best.rec.raw)||{};
 mt.textContent=`${m.name} · ${m.realm} · ${suAgoV2895(best.rec.savedAt)}${best.key==='daily'?'（较早的一份）':''}`;
 sec.querySelector('[data-su="mirrorBtns"]').hidden=false;
 sec.querySelector('[data-su="mexport"]').onclick=()=>exportRawSaveV2870(best.rec.raw,'xiantu-mirror-'+Date.now()+'.json').catch(e=>gameAlertV2868114('导出失败：'+e.message));
 const restore=chosen=>{
  const best=chosen,m=suMetaV2895(best.rec.raw)||{};
  if(typeof saveChangeAllowedV2838==='function'&&!saveChangeAllowedV2838()){gameAlertV2868114('请先结束战斗或突破。');return;}
  if(saveConfirmOpenV2868114())return;
  try{const data=dryRunLoadV2870(best.rec.raw);
   // The game keeps ticking while the in-game dialog is open; replaceSaveV2870 archives the state as of confirm time.
   saveConfirmV2868114(`将用备用库中的记录（${m.realm}，${suAgoV2895(best.rec.savedAt)}）替换当前修行记录，替换前的记录会单独保留（仅一份）。是否继续？`,
    ()=>(!el.isConnected||player!==owner||!suMirrorCurrentV2895(best.rec,best.epoch))&&'角色、存档或页面已变化，请重新打开。',
    ()=>replaceSaveV2870(best.rec.raw,data),'恢复失败：');
  }catch(e){gameAlertV2868114('恢复失败：'+e.message);}
 };
 sec.querySelector('[data-su="mrestore"]').onclick=()=>restore(best);
 const daily=await suMirrorBestV2895('daily');
 if(daily&&daily.rec.raw!==best.rec.raw&&el.isConnected&&player===owner){
  const older=document.createElement('div');older.className='su-row-v2895';
  const label=document.createElement('p');const meta=suMetaV2895(daily.rec.raw);label.textContent=`较早备份：${meta.name} · ${meta.realm} · ${suAgoV2895(daily.rec.savedAt)}`;
  const button=document.createElement('button');button.className='choice-btn';button.textContent='恢复较早备份';button.onclick=()=>restore(daily);
  const exp=document.createElement('button');exp.className='choice-btn';exp.textContent='导出较早备份';exp.onclick=()=>exportRawSaveV2870(daily.rec.raw,'xiantu-mirror-older-'+Date.now()+'.json').catch(e=>gameAlertV2868114('导出失败：'+e.message));
  sec.appendChild(label);older.append(button,exp);sec.appendChild(older);
 }
}

// ---------------------------------------------------------------- styles
function installSaveUiStylesV2895(){
 if(document.getElementById('saveUiStyleV2895'))return;
 // ::after is positioned from inside the 1 px border, so add it back.
 const U=SAVEUI_V2895.ui,pad=Math.max(0,(U.hitTarget-(U.zoomButton-2))/2);
 const css=`
html.xiantu-mobile-dedicated body .minimap-zoom-controls button{width:${U.zoomButton}px!important;height:${U.zoomButton}px!important;min-width:${U.zoomButton}px!important;font-size:${U.zoomFont}px!important;line-height:${U.zoomButton-2}px!important;position:relative!important}
html.xiantu-mobile-dedicated body .minimap-zoom-controls button::after{content:'';position:absolute;inset:-${pad}px}
html.xiantu-mobile-dedicated body .minimap-zoom-controls{gap:${U.zoomGap}px!important;padding:3px!important}
html.xiantu-mobile-dedicated body .minimap-zoom-controls button{flex:0 0 auto!important}
html.xiantu-mobile-dedicated body #minimapZoomLabel{font-size:${U.zoomLabel}px!important;min-width:${U.zoomLabelWidth}px!important}
html.xiantu-mobile-dedicated body .world-minimap-head{font-size:${U.minimapHead}px!important}
html.xiantu-mobile-dedicated body .world-realm{font-size:${U.realmText}px!important}
html.xiantu-mobile-dedicated body .world-hud-actions>button,html.xiantu-mobile-dedicated body #panelToggleBtn,html.xiantu-mobile-dedicated body .mobile-menu-btn{font-size:${U.hudButtonText}px!important}
html.xiantu-mobile-dedicated body #worldAreaName{font-size:${U.areaText}px!important}
html.xiantu-mobile-dedicated body #mobileHudToggle{min-width:${U.hudToggleMin}px!important}
body .save-indicator{font-size:${U.saveIndicator}px!important}
@media (max-width:${U.narrowWidth}px){html.xiantu-mobile-dedicated body .world-hud-actions>button{white-space:normal!important;word-break:keep-all!important;line-height:1.15!important;padding:2px 1px!important}}
.su-remind-v2895{position:fixed;left:50%;transform:translateX(-50%);top:calc(env(safe-area-inset-top,0px) + 132px);width:min(92vw,380px);z-index:99990;
 background:rgba(14,20,16,.95);border:1px solid rgba(229,199,121,.45);border-radius:14px;padding:12px 14px;color:#efe6cc;font-size:14px;line-height:1.5;box-shadow:0 10px 28px rgba(0,0,0,.45)}
.su-remind-v2895 p{margin:6px 0}
.su-remind-title-v2895{font-weight:800;color:#f1d186;font-size:15px}
.su-row-v2895{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
.su-row-v2895>.choice-btn{flex:1 1 0;min-width:96px;min-height:44px;margin:0}
.su-later-v2895{opacity:.85}
.su-small-v2895{font-size:12px;color:#c9bfa4}
.su-rec-v2895{background:rgba(255,255,255,.05);border-radius:10px;padding:8px 10px}
.su-manager-v2895 p{margin:6px 0}
.su-manager-v2895 [hidden]{display:none!important}
@media (prefers-reduced-motion:no-preference){.su-remind-v2895{animation:suInV2895 .25s ease-out}}
@keyframes suInV2895{from{opacity:0;transform:translate(-50%,-8px)}to{opacity:1;transform:translate(-50%,0)}}`;
 const st=document.createElement('style');st.id='saveUiStyleV2895';st.textContent=css;document.head.appendChild(st);
}

// ---------------------------------------------------------------- install
function installSaveUiV2895(){
 installSaveUiStylesV2895();
 window.saveMirrorV2895=saveMirrorV2895;window.saveMirrorClearedV2895=saveMirrorClearedV2895;
 window.saveMirrorOfferV2895=saveMirrorOfferV2895;window.saveExportedV2895=saveExportedV2895;
 window.saveManagerExtraV2895=saveManagerExtraV2895;
 if(suHasLocalSaveV2895()&&!suLsGetV2895(SAVEUI_V2895.keys.firstSeen))suLsSetV2895(SAVEUI_V2895.keys.firstSeen,String(Date.now()));
 const flushNow=()=>suMirrorScheduleV2895(true);
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'){document.getElementById('saveRemindV2895')?.remove();flushNow();}});
 window.addEventListener('pagehide',flushNow);
 for(const ev of ['pointerdown','keydown'])document.addEventListener(ev,suPersistGestureV2895,{capture:true,passive:true});
 SAVEUI_STATE_V2895.remind.timer=setInterval(suRemindTickV2895,SAVEUI_V2895.remind.checkMs);
 suPersistQueryV2895();
 // The start-screen check may have run before this file loaded.
 setTimeout(()=>{try{if(suOnStartScreenV2895()&&!suHasLocalSaveV2895())saveMirrorOfferV2895();}catch(_){}},0);
}
installSaveUiV2895();

// END SAVE_UI_V2895

// BEGIN MAP_MOVEMENT_V2896
// Movement stays in the existing update loop; this device preference never changes actor base speed.
const MAP_MOVEMENT_V2896=Object.freeze({key:'xiantu_sword_flight_v2870',multiplier:1.6,skin:.05,contacts:4});
let swordFlightV2896=false;
try{swordFlightV2896=localStorage.getItem(MAP_MOVEMENT_V2896.key)==='1';}catch(_){}
function mapMoveSpeedV2896(){return FLAT_WORLD.player.speed*(swordFlightV2896?MAP_MOVEMENT_V2896.multiplier:1);}
function syncSwordFlightV2896(){
 const button=document.getElementById('swordFlightBtnV2870');if(!button)return;
 button.textContent=swordFlightV2896?'御剑疾行 · 开':'御剑疾行 · 关';
 button.setAttribute('aria-pressed',String(swordFlightV2896));
 button.title='开启后地图移动速度提升60%；仍需绕开障碍，可能更快遇到怪物。';
}
function toggleSwordFlightV2870(){
 if(gameState!=='exploring'||player?.breakthrough?.isAnimating)return false;
 swordFlightV2896=!swordFlightV2896;
 try{localStorage.setItem(MAP_MOVEMENT_V2896.key,swordFlightV2896?'1':'0');}catch(_){}
 syncSwordFlightV2896();
 showFloatingText?.(swordFlightV2896?'御剑疾行：地图移速提升60%，仍受障碍限制。':'已恢复常速行走。','#e5cf87');
 return swordFlightV2896;
}
function ensureSwordFlightV2896(){
 const host=document.getElementById('worldExploreActions');if(!host)return;
 if(!document.getElementById('swordFlightBtnV2870')){const b=document.createElement('button');b.type='button';b.id='swordFlightBtnV2870';b.onclick=toggleSwordFlightV2870;host.appendChild(b);}
 syncSwordFlightV2896();
}
window.addEventListener('storage',e=>{if(e.key!==MAP_MOVEMENT_V2896.key&&e.key!==null)return;swordFlightV2896=e.newValue==='1';syncSwordFlightV2896();});

// Sweep the player's circle through the complete displacement, then project the remaining motion
// onto the contact tangent. Monster physics keeps its existing collision routine and RNG.
function resolvePlayerMotionV2896(fromX,fromY,toX,toY,actorRadius=17){
 if(![fromX,fromY,toX,toY,actorRadius].every(Number.isFinite)||actorRadius<0)return {x:fromX,y:fromY};
 const skin=MAP_MOVEMENT_V2896.skin,colliders=FLAT_WORLD.colliders||[];
 let x=fromX,y=fromY,vx=toX-fromX,vy=toY-fromY;
 const valid=c=>Number.isFinite(c.x)&&Number.isFinite(c.y)&&Number.isFinite(c.radius)&&c.radius>=0;
 const overlaps=(px,py)=>colliders.some(c=>valid(c)&&Math.hypot(px-c.x,py-c.y)<c.radius+actorRadius-1e-5);
 // Recover an old/teleported overlap without carrying momentum across a map transition.
 if(overlaps(x,y)){
  const sceneSafe=(typeof wildSceneSafePointV286898==='function'&&wildSceneSafePointV286898(x,y,actorRadius))||(typeof sectSceneSafePointV286896==='function'&&sectSceneSafePointV286896(x,y,actorRadius));
  if(sceneSafe)return sceneSafe;
  const fixed=resolveWorldCollisionForActor(x,y,x,y,actorRadius);x=fixed.x;y=fixed.y;
  if(overlaps(x,y))return {x,y};
 }
 const safeX=x,safeY=y;
 for(let pass=0;pass<MAP_MOVEMENT_V2896.contacts;pass++){
  const a=vx*vx+vy*vy;if(a<1e-12)break;
  let hit=null,first=1;
  for(const c of colliders){
   if(!valid(c))continue;
   const r=c.radius+actorRadius+skin,fx=x-c.x,fy=y-c.y;
   // Cheap segment bounding box rejection before the quadratic intersection.
   if(c.x<Math.min(x,x+vx)-r||c.x>Math.max(x,x+vx)+r||c.y<Math.min(y,y+vy)-r||c.y>Math.max(y,y+vy)+r)continue;
   const b=fx*vx+fy*vy;if(b>=0)continue;
   const outside=fx*fx+fy*fy-r*r,disc=b*b-a*outside;if(disc<0)continue;
   const t=outside<=0?0:(-b-Math.sqrt(disc))/a;
   if(t<0||t>first)continue;
   first=t;hit=c;
  }
  if(!hit){x+=vx;y+=vy;break;}
  const cx=x+vx*first,cy=y+vy*first,norm=Math.hypot(cx-hit.x,cy-hit.y)||1;
  const nx=(cx-hit.x)/norm,ny=(cy-hit.y)/norm;
  const advance=Math.max(0,first-1e-6);x+=vx*advance;y+=vy*advance;
  vx*=1-first;vy*=1-first;
  const inward=Math.min(0,vx*nx+vy*ny);vx-=nx*inward;vy-=ny*inward;
 }
 x=Math.max(30,Math.min(FLAT_WORLD.width-30,x));y=Math.max(30,Math.min(FLAT_WORLD.height-30,y));
 // Crowded corners may exhaust the contact budget; never resolve them by crossing an obstacle.
 return overlaps(x,y)?{x:safeX,y:safeY}:{x,y};
}
// END MAP_MOVEMENT_V2896

// BEGIN ONBOARDING_V2901
// Serialized, owner-bound notices. Durable unlocks are marked read only by their renderer.
const NOTICE_V2901=Object.freeze({gapMs:600,tickMs:250,ttl:Object.freeze({toast:8000,banner:20000,modal:0}),maxQueue:12,order:Object.freeze(['toast','banner','modal'])});
const NQ_V2901={owner:null,queue:[],cur:null,lastEnd:0,timer:null,dropped:0};
function noticeBusyV2901(){
 if(document.hidden||gameState==='start'||document.getElementById('gameScreen')?.classList.contains('hidden'))return 'hidden';
 if(gameState==='combat'||gameState==='combat-ending'||COMBAT_FINISH_V2764.settling)return 'combat';
 if(player?.breakthrough?.isAnimating||document.getElementById('breakthroughSuccess')||document.getElementById('breakthroughFail'))return 'breakthrough';
 if(document.getElementById('tutorialBubble')?.classList.contains('tutorial-modal'))return 'tutorial';
 if(isWorldOverlayOpen()||document.querySelector('.mobile-inventory-overlay')||document.querySelector('.help-manual-overlay.active'))return 'panel';
 return '';
}
function noticeBlockedV2901(kind,busy){return busy==='hidden'||(kind==='modal'?!!busy:kind==='banner'?['combat','breakthrough'].includes(busy):false);}
function noticeResetV2901(){
 clearInterval(NQ_V2901.timer);NQ_V2901.timer=null;NQ_V2901.cur?.el?.remove();
 for(const id of ['tutorialUnlock','tutorialToast','worldRegionNotice'])document.getElementById(id)?.remove();
 document.querySelectorAll('.achievement-popup').forEach(e=>e.remove());
 NQ_V2901.queue=[];NQ_V2901.cur=null;NQ_V2901.lastEnd=0;NQ_V2901.owner=player;
}
function noticeOwnerV2901(){if(NQ_V2901.owner!==player)noticeResetV2901();}
function noticeAliveV2901(c){return !!c&&!(c.el&&c.el.isConnected===false)&&(c.kind==='modal'?!!c.el:Date.now()<c.endAt);}
function noticeEnsureTimerV2901(){if(!document.hidden&&!NQ_V2901.timer&&(NQ_V2901.cur||NQ_V2901.queue.length))NQ_V2901.timer=setInterval(noticeTickV2901,NOTICE_V2901.tickMs);}
function noticeShowV2901(item){
 if(item.owner!==player)return null;
 let el=null;try{el=item.show()||null;}catch(e){console.warn('提示显示失败',item.key);}
 NQ_V2901.cur=item.kind==='modal'&&!el?null:{...item,el,endAt:Date.now()+(item.dur||2400)};
 noticeEnsureTimerV2901();return el;
}
function noticeTickV2901(){
 noticeOwnerV2901();const now=Date.now(),busy=noticeBusyV2901(),c=NQ_V2901.cur;
 if(c){
  if(noticeAliveV2901(c)){if(c.kind==='modal'&&c.el)c.el.hidden=noticeBlockedV2901(c.kind,busy);return false;}
  c.el?.remove();NQ_V2901.cur=null;NQ_V2901.lastEnd=now;
 }
 NQ_V2901.queue=NQ_V2901.queue.filter(q=>q.owner===player&&(!NOTICE_V2901.ttl[q.kind]||now-q.at<=NOTICE_V2901.ttl[q.kind]));
 if(!NQ_V2901.queue.length){clearInterval(NQ_V2901.timer);NQ_V2901.timer=null;return false;}
 if(now-NQ_V2901.lastEnd<NOTICE_V2901.gapMs)return false;
 for(const kind of NOTICE_V2901.order){const i=NQ_V2901.queue.findIndex(q=>q.kind===kind&&!noticeBlockedV2901(kind,busy));if(i>=0){noticeShowV2901(NQ_V2901.queue.splice(i,1)[0]);return true;}}
 return false;
}
function noticePushV2901(item){
 if(!item?.key||typeof item.show!=='function'||!player)return null;
 noticeOwnerV2901();const kind=NOTICE_V2901.order.includes(item.kind)?item.kind:'modal';
 const it={...item,kind,owner:player,at:Date.now()},c=NQ_V2901.cur;
 if(noticeAliveV2901(c)&&c.key===it.key&&kind==='modal')return null;
 const old=NQ_V2901.queue.find(q=>q.key===it.key);if(old){Object.assign(old,it,{at:old.at});return null;}
 if(kind==='toast'&&c?.kind==='toast'&&noticeAliveV2901(c)){c.el?.remove();NQ_V2901.cur=null;return noticeShowV2901(it);}
 if(NQ_V2901.queue.length>=NOTICE_V2901.maxQueue){
  const i=NQ_V2901.queue.findIndex(q=>q.kind!=='modal');
  if(i>=0)NQ_V2901.queue.splice(i,1);else if(kind!=='modal'){NQ_V2901.dropped++;return null;} // Never discard durable unlocks; their fixed keys deduplicate.
 }
 NQ_V2901.queue.push(it);noticeTickV2901();noticeEnsureTimerV2901();return NQ_V2901.cur?.key===it.key?NQ_V2901.cur.el:null;
}
function installNoticeQueueV2901(){
 const wrap=(name,fn)=>{const base=window[name];if(typeof base==='function')window[name]=fn(base);};
 wrap('showTutorialToast',base=>function(text,duration=3600){return noticePushV2901({key:'toast:'+text,kind:'toast',dur:(Number(duration)||3600)+300,show:()=>{base(text,duration);return document.getElementById('tutorialToast');}});});
 wrap('showAchievementPopup',base=>function(ach){return noticePushV2901({key:'ach:'+(ach?.id||ach?.name||''),kind:'banner',dur:2400,show:()=>{base(ach);return document.querySelector('.achievement-popup');}});});
 wrap('showRegionEntryNotification',base=>function(region,message=''){return noticePushV2901({key:'region',kind:'banner',dur:PERF_CONFIG.lowEnd?1400:2000,show:()=>{base(region,message);return document.getElementById('worldRegionNotice');}});});
 wrap('showExportReminderV2895',base=>function(due){return noticePushV2901({key:'save-remind',kind:'modal',show:()=>base(due)});});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){if(NQ_V2901.cur?.el)NQ_V2901.cur.el.hidden=true;clearInterval(NQ_V2901.timer);NQ_V2901.timer=null;}else{noticeTickV2901();noticeEnsureTimerV2901();}});
}
const FIRSTPATH_V2901=Object.freeze({doneKey:'path_v2901_done',hiddenKey:'path_v2901_hidden',maxLevel:1,tickMs:500});
// ================================================================ first-hour path
const PATH_TUTORIAL_V2901={welcome:1,movement:1,interaction:1,combat:2,combat_attack:2,equipment:3,tasks:4,cultivation:4};
function pathTutDoneV2901(id){return !!(player?.tutorial?.skipped||player?.tutorial?.completedSteps?.includes(id));}
function pathJourneyV2901(n){
 const s=player?.firstJourneyV28687;
 if(s&&typeof s==='object')return Math.max(0,Math.min(5,Math.floor(Number(s.step)||0)))>=n?'done':s.paused?'paused':'todo';
 return (player.level|0)>=2?'done':'todo';   // 筑基以上的老角色本就不再显示初入仙途
}
function pathGoTutorialV2901(){if(typeof checkAndStartTutorial==='function')checkAndStartTutorial(true);}
function pathGoJourneyV2901(){if(typeof beginFirstJourneyV28687==='function')beginFirstJourneyV28687();}
function pathGoBreakV2901(){
 if((Number(player.exp)||0)>=getCurrentExpNeed()&&!(player.breakthrough?.cooldownDays>0)&&typeof checkLevelUp==='function'){checkLevelUp();return;}
 if(typeof showTutorialToast==='function')showTutorialToast('修为未满：去山野历练，或到洞府闭关。经验条满后即可突破。',4200);
}
const PATH_STEPS_V2901=Object.freeze([
 {id:'walk', title:'行走与交互',hint:'拖动摇杆或轻点地面移动，靠近地点后按【交互】。',state:()=>pathTutDoneV2901('interaction')?'done':'todo',go:pathGoTutorialV2901},
 {id:'train',title:'演武入门', hint:'击败演武傀儡，取得布衣、灵石，并开放自由探索。',state:()=>player?.tutorial?.skipped||player?.tutorial?.readPopups?.includes('training_reward')?'done':'todo',go:()=>startTutorialTraining()},
 {id:'robe', title:'穿戴布衣', hint:'装备栏 → 背包装备 → 布衣（已有其他法袍也可）。',state:()=>player.tutorial?.skipped||player.equipment?.robe?'done':'todo',go:()=>showEquipmentPanel()},
 {id:'duty', title:'修炼与突破',hint:'了解修为瓶颈与突破，以及练气后的去向。',state:()=>pathTutDoneV2901('cultivation')?'done':'todo',go:pathGoTutorialV2901},
 {id:'wolf', title:'山脚试手', hint:'击败受伤野狼，得到木剑。',state:()=>pathJourneyV2901(1),go:pathGoJourneyV2901},
 {id:'sword',title:'装备木剑', hint:'穿上木剑，攻击 +3、暴击 +1。',state:()=>pathJourneyV2901(2),go:pathGoJourneyV2901},
 {id:'skill',title:'配置御剑术',hint:'把御剑术放进兵刃系技能栏。',state:()=>pathJourneyV2901(3),go:pathGoJourneyV2901},
 {id:'pass', title:'守住山道', hint:'用御剑术击败山道壮狼，得 120 灵石。',state:()=>pathJourneyV2901(4),go:pathGoJourneyV2901},
 {id:'letter',title:'雨夜来信',hint:'收好那封发往凌霄宗的密信。',state:()=>pathJourneyV2901(5),go:pathGoJourneyV2901},
 {id:'break',title:'首次突破', hint:'修为满后突破到练气；历练、闭关都能攒修为。',state:()=>(player.level|0)>=1?'done':'todo',go:pathGoBreakV2901},
 {id:'task', title:'第一份宗门差事',hint:'沿主线走入凌霄宗，再接取并交付一份宗门差事。',state:()=>player.sectTasks?.some(t=>t.completed)?'done':(player.level|0)<1?'locked':'todo',go:()=>{if(player.sect&&player.sect!=='散修')showSectTasks();else showTaskPanel();}}
]);
const PATH_RT_V2901={owner:null,sawOpen:false,lastText:'',timer:null};
function pathStatesV2901(){return PATH_STEPS_V2901.map(s=>{let st='todo';try{st=s.state();}catch(_){}return {id:s.id,title:s.title,hint:s.hint,state:st};});}
function pathFlagsV2901(){return player?.tutorial?.readPopups||[];}
function pathEligibleV2901(){
 if(typeof player==='undefined'||!player||player.testAccount999||Number(player.level)>FIRSTPATH_V2901.maxLevel)return false;
 const f=pathFlagsV2901();if(f.includes(FIRSTPATH_V2901.doneKey))return false;
 return (player.level|0)<=FIRSTPATH_V2901.maxLevel;
}
function pathNextV2901(list=pathStatesV2901()){return list.find(s=>s.state==='todo')||list.find(s=>s.state==='paused')||null;}
function pathProgressV2901(list=pathStatesV2901()){return {done:list.filter(s=>s.state==='done').length,total:list.length};}
// 走完：记一个键（readPopups，已有字段），本局里看着走完的才贺一句。
function pathCheckDoneV2901(){
 if(!pathEligibleV2901())return false;
 const list=pathStatesV2901();
 if(list.some(s=>s.state!=='done'))return false;   // 暂停不是完成；仅余暂停项时收起地图提示，仍可手动继续
 ensureTutorialState().readPopups.push(FIRSTPATH_V2901.doneKey);try{autoSave?.();}catch(_){}
 if(PATH_RT_V2901.sawOpen&&PATH_RT_V2901.owner===player&&!list.some(s=>s.state==='paused')&&typeof showTutorialToast==='function')showTutorialToast('🧭 起步之路已走完。之后的路，看【📖 修行指引 → 起步】里的「此刻宜行」。',5200);
 document.getElementById('firstPathV2901')?.remove();return true;
}
// 凡人新手走到「雨夜来信」之前，地图只留起步提示；略过或收起引导、已推进主线的角色不受影响。
function pathOwnsMapV2901(){
 if(!pathEligibleV2901()||(player.level|0)>=1||pathFlagsV2901().includes(FIRSTPATH_V2901.hiddenKey))return false;
 if(player.tutorial?.skipped&&!player.firstJourneyV28687)return false;
 if(player.tasks?.completed?.length||(player.tasks?.active?.main_01?.currentStep|0)>0)return false;
 const next=pathNextV2901();return !!next&&next.state==='todo'&&next.id!=='break'&&next.id!=='task';
}
function pathTrackerVisibleV2901(){
 if(!pathEligibleV2901()||pathFlagsV2901().includes(FIRSTPATH_V2901.hiddenKey)||!pathStatesV2901().some(s=>s.state==='todo'))return false;
 if(typeof gameState==='undefined'||gameState!=='exploring'||noticeBusyV2901())return false;
 const s=document.getElementById('startScreen'),g=document.getElementById('gameScreen');if(s&&!s.classList.contains('hidden')&&(!g||g.classList.contains('hidden')))return false;
 if(document.getElementById('tutorialBubble'))return false;   // 引路气泡自己带「起步之路 n/11」
 const sp=document.getElementById('storyPanel');if(sp&&!sp.classList.contains('hidden'))return false;
 try{if(typeof isWorldOverlayOpen==='function'&&isWorldOverlayOpen())return false;}catch(_){}
 return true;
}
function pathTickV2901(){
 if(typeof player==='undefined'||!player)return;
 if(document.hidden||gameState==='start'||!pathEligibleV2901()||pathFlagsV2901().includes(FIRSTPATH_V2901.hiddenKey)){clearInterval(PATH_RT_V2901.timer);PATH_RT_V2901.timer=null;document.getElementById('firstPathV2901')?.remove();return;}
 if(PATH_RT_V2901.owner!==player){PATH_RT_V2901.owner=player;PATH_RT_V2901.sawOpen=false;PATH_RT_V2901.lastText='';}
 if(pathEligibleV2901()&&pathStatesV2901().some(s=>s.state!=='done'))PATH_RT_V2901.sawOpen=true;
 if(pathCheckDoneV2901()){clearInterval(PATH_RT_V2901.timer);PATH_RT_V2901.timer=null;return;}
 let el=document.getElementById('firstPathV2901');
 if(!pathTrackerVisibleV2901()){if(el)el.hidden=true;return;}
 const list=pathStatesV2901(),next=pathNextV2901(list),p=pathProgressV2901(list);if(!next){if(el)el.hidden=true;return;}
 if(!el){el=document.createElement('button');el.type='button';el.id='firstPathV2901';el.className='first-path-v2901';el.addEventListener('click',()=>showFirstPathV2901());document.body.appendChild(el);}
 const text=`🧭 起步 ${p.done}/${p.total} · ${next.state==='paused'?'可继续：':''}${next.title}`;
 if(PATH_RT_V2901.lastText!==text||el.textContent!==text){el.textContent=text;el.setAttribute('aria-label',`起步之路 ${p.done}/${p.total}，下一步：${next.title}`);PATH_RT_V2901.lastText=text;}
 const hud=document.querySelector('.world-hud');
 try{const r=hud?.getBoundingClientRect?.();if(r&&r.bottom>0){el.style.top=Math.round(r.bottom+6)+'px';el.style.left=Math.round(Math.max(8,r.left))+'px';el.style.maxWidth=Math.round(Math.max(180,r.width))+'px';}}catch(_){}
 el.hidden=false;
}
function pathEscV2901(v){return typeof escapeGameText==='function'?escapeGameText(String(v)):String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function showFirstPathV2901(){
 if(typeof player==='undefined'||!player||!forgeAllowedV2825())return null;
 closeHelpManual();stopNavigationV2830();resetWorldMovementV28686();
 const owner=player;
 document.getElementById('firstPathPanelV2901')?.remove();
 const flags=pathFlagsV2901(),hi=flags.indexOf(FIRSTPATH_V2901.hiddenKey);if(hi>=0){flags.splice(hi,1);try{autoSave?.();}catch(_){}}
 const list=pathStatesV2901(),next=pathNextV2901(list),p=pathProgressV2901(list);
 const rows=list.map((s,i)=>{const cur=next&&s.id===next.id;const mark=s.state==='done'?'✓':s.state==='paused'?'⏸':s.state==='locked'?'🔒':cur?'▶':'·';
  return `<li class="fp-step-v2901 ${s.state}${cur?' cur':''}"><span class="fp-mark-v2901">${mark}</span><span><b>${i+1}. ${pathEscV2901(s.title)}</b>${s.state==='paused'?'<em>（已收起，可继续）</em>':''}${s.state==='locked'?'<em>（踏入练气后开放）</em>':''}<br><small>${pathEscV2901(s.hint)}</small></span>${cur?`<button type="button" class="choice-btn" data-fp="go" data-id="${s.id}">前往</button>`:''}</li>`;}).join('');
 const el=document.createElement('div');el.id='firstPathPanelV2901';el.className='mobile-inventory-overlay first-path-panel-v2901';el.style.zIndex='100003';el.setAttribute('role','dialog');el.setAttribute('aria-label','起步之路');
 el.innerHTML=`<div class="mobile-inventory-card"><h3>🧭 起步之路 · ${p.done}/${p.total}</h3><p class="fp-lead-v2901">新入仙途的起步指引：引路、初入仙途、首次突破与宗门差事，一条路走完。每一步的奖励与原来相同。</p><ol class="fp-list-v2901">${rows}</ol>
  <div class="su-row-v2895" style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="choice-btn" data-fp="hide">收起起步之路</button><button type="button" class="choice-btn" data-fp="close">关闭</button></div></div>`;
 el.addEventListener('click',e=>{
  if(player!==owner||!forgeAllowedV2825()){el.remove();return;}
  const b=e.target?.closest?.('[data-fp]');if(!b){if(e.target===el)el.remove();return;}
  const k=b.dataset.fp;
  if(k==='close')el.remove();
  else if(k==='hide'){if(!pathFlagsV2901().includes(FIRSTPATH_V2901.hiddenKey))ensureTutorialState().readPopups.push(FIRSTPATH_V2901.hiddenKey);try{autoSave?.();}catch(_){}el.remove();document.getElementById('firstPathV2901')?.remove();
   if(typeof showTutorialToast==='function')showTutorialToast('起步之路已收起，可从【📖 修行指引】再打开。',3200);}
  else if(k==='go'){const s=PATH_STEPS_V2901.find(x=>x.id===b.dataset.id);el.remove();closeWorldOverlay();try{s?.go();}catch(err){console.warn('起步之路跳转失败',err);}}
 });
 document.body.appendChild(el);el.querySelector('[data-fp="close"]')?.focus();pathEnsureTimerV2901();
 try{[...el.querySelectorAll('.fp-step-v2901')].find(x=>x.classList.contains('cur'))?.scrollIntoView?.({block:'center'});}catch(_){}
 return el;
}
// 统一编号：引路气泡、初入仙途标题都改成「起步之路 n/11」
function pathRelabelTutorialV2901(id){
 const b=document.getElementById('tutorialBubble'),n=PATH_TUTORIAL_V2901[id];if(!b||!n)return;
 const total=PATH_STEPS_V2901.length,sub=pathTutorialCardV2868121(id);
 // V28.68.121 (audit G5): several cards share one path row, so each card also shows its place in that row.
 const c=b.querySelector('.tutorial-counter');
 if(c){c.textContent=`起步之路 ${n} / ${total}`+(sub?` · 本段 ${sub.i}/${sub.of}`:'');c.dataset.card=sub?`${n}.${sub.i}`:String(n);
  if(sub){const pips=document.createElement('span');pips.className='tutorial-pips-v2868121';pips.setAttribute('aria-hidden','true');
   for(let k=1;k<=sub.of;k++){const d=document.createElement('i');if(k<sub.i)d.className='done';else if(k===sub.i)d.className='cur';pips.appendChild(d);}c.appendChild(pips);}}
 const m=b.querySelector('.tutorial-mini-progress');if(m)m.textContent=`${n}/${total}`+(sub?` · ${sub.i}/${sub.of}`:'');
}
// Card position inside its path row, from the tutorial order; null when the row has a single card.
function pathTutorialCardV2868121(id){
 const n=PATH_TUTORIAL_V2901[id];if(!n||typeof TUTORIAL_ORDER==='undefined')return null;
 const row=TUTORIAL_ORDER.filter(x=>PATH_TUTORIAL_V2901[x]===n),i=row.indexOf(id)+1;
 return row.length>1&&i>0?{i,of:row.length}:null;
}
function pathRelabelJourneyV2901(){
 const box=document.getElementById('storyText'),s=typeof firstJourneyV28687==='function'?firstJourneyV28687():null;if(!box||!s)return;
 const h=box.querySelector('h3');if(!h)return;
 const total=PATH_STEPS_V2901.length,n=Math.min(4+s.step+1,9);
 const txt=String(h.textContent||'');
 if(/^初入仙途 · \d\/5 · /.test(txt))h.textContent=txt.replace(/^初入仙途 · \d\/5 · /,`起步之路 ${n}/${total} · 初入仙途 · `);
}
function pathRelabelJourneyButtonV2901(){
 const b=document.getElementById('firstJourneyV28687');if(!b||!pathEligibleV2901())return;
 const s=typeof firstJourneyV28687==='function'?firstJourneyV28687():null,total=PATH_STEPS_V2901.length;
 const i=s?Math.min(4+s.step,8):4,label=`🧭 起步 ${i+1}/${total} · ${PATH_STEPS_V2901[i].title}`;
 if(b.textContent!==label)b.textContent=label;
}
// V2890「此刻宜行」：起步之路未走完时，第一条就是它的下一步；指引底部加一个「起步之路」入口。
function installPathGuideV2901(){
 const ns=window.guideNextStepsV2890;
 if(typeof ns==='function'&&!ns.__pathV2901){
  const w=function(f){
   let out=[];try{out=ns.apply(this,arguments)||[];}catch(_){out=[];}
   try{if(pathEligibleV2901()&&!pathFlagsV2901().includes(FIRSTPATH_V2901.hiddenKey)){const list=pathStatesV2901(),next=pathNextV2901(list),p=pathProgressV2901(list);
    if(next&&next.state!=='paused'){out=out.filter(t=>!/初入仙途/.test(t));out.unshift(`起步之路 ${p.done}/${p.total}：下一步【${pathEscV2901(next.title)}】——${pathEscV2901(next.hint)}`);out=out.slice(0,3);}}}catch(_){}
   return out;
  };w.__pathV2901=true;window.guideNextStepsV2890=w;
 }
 const ga=window.guideActionsV2890;
 if(typeof ga==='function'&&!ga.__pathV2901){
  const w=function(){
   let html='';try{html=ga.apply(this,arguments)||'';}catch(_){html='';}
   if(player&&!player.testAccount999)html='<button type="button" data-fp-open="1">🧭 起步之路</button>'+html;   // 原「继续初入仙途」保留
   return html;
  };w.__pathV2901=true;window.guideActionsV2890=w;
 }
 if(!window.__pathGuideClickV2901){window.__pathGuideClickV2901=true;
  document.addEventListener('click',e=>{const b=e.target?.closest?.('[data-fp-open]');if(!b)return;try{closeHelpManual?.();}catch(_){}showFirstPathV2901();},true);}
}
function pathEnsureTimerV2901(){if(!document.hidden&&gameState!=='start'&&pathEligibleV2901()&&!pathFlagsV2901().includes(FIRSTPATH_V2901.hiddenKey)&&!PATH_RT_V2901.timer)PATH_RT_V2901.timer=setInterval(pathTickV2901,FIRSTPATH_V2901.tickMs);}
function installPathV2901(){
 const tt=window.triggerTutorial;
 if(typeof tt==='function'&&!tt.__pathV2901){const w=function(id){const r=tt.apply(this,arguments);if(r)try{pathRelabelTutorialV2901(id);}catch(_){}return r;};w.__pathV2901=true;window.triggerTutorial=w;}
 const sj=window.showFirstJourneyV28687;
 if(typeof sj==='function'&&!sj.__pathV2901){const w=function(){const r=sj.apply(this,arguments);try{pathRelabelJourneyV2901();}catch(_){}return r;};w.__pathV2901=true;window.showFirstJourneyV28687=w;}
 // 角色面板里初入仙途的按钮保留（同一入口），只换成起步之路的统一编号
 const sync=window.syncFirstJourneyV28687;
 if(typeof sync==='function'&&!sync.__pathV2901){const w=function(){const r=sync.apply(this,arguments);try{pathRelabelJourneyButtonV2901();pathEnsureTimerV2901();}catch(_){}return r;};w.__pathV2901=true;window.syncFirstJourneyV28687=w;}
 installPathGuideV2901();
 pathEnsureTimerV2901();
 document.addEventListener('visibilitychange',()=>{pathTickV2901();pathEnsureTimerV2901();});
}
function installFirstPathStylesV2901(){
 if(document.getElementById('firstPathStyleV2901'))return;
 const st=document.createElement('style');st.id='firstPathStyleV2901';
 st.textContent=`.first-path-v2901{position:fixed;top:132px;left:18px;z-index:2400;max-width:min(260px,calc(100vw - 32px));min-height:34px;padding:6px 12px;border-radius:999px;border:1px solid rgba(242,210,122,.55);background:rgba(14,16,14,.88);color:#f2d27a;font-size:14px;font-weight:700;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;box-shadow:0 2px 10px rgba(0,0,0,.4)}
.first-path-v2901[hidden]{display:none}
.first-path-panel-v2901 .fp-list-v2901{list-style:none;margin:8px 0;padding:0;max-height:58vh;overflow-y:auto}
.first-path-panel-v2901 .fp-step-v2901{display:flex;gap:8px;align-items:center;padding:7px 8px;border-radius:8px;margin:3px 0;background:rgba(255,255,255,.03);line-height:1.45}
.first-path-panel-v2901 .fp-step-v2901>span:nth-child(2){flex:1;min-width:0}
.first-path-panel-v2901 .fp-step-v2901 small{color:#bfb69e;font-size:13px}
.first-path-panel-v2901 .fp-step-v2901.done,.first-path-panel-v2901 .fp-step-v2901.locked{opacity:.6}
.first-path-panel-v2901 .fp-step-v2901.cur{background:rgba(242,210,122,.12);border:1px solid rgba(242,210,122,.45)}
.first-path-panel-v2901 .fp-step-v2901 .choice-btn{flex:none!important;width:auto!important;min-width:64px;max-width:96px;margin:0!important;padding:6px 12px!important}
.first-path-panel-v2901 .fp-mark-v2901{flex:none;width:1.4em;text-align:center;color:#9ff5c8}
.first-path-panel-v2901 .fp-lead-v2901{color:#d8ccb0;font-size:14px}`;
 (document.head||document.documentElement).appendChild(st);
}
function installFirstPathV2901(){
 try{installFirstPathStylesV2901();}catch(e){console.warn('起步之路样式失败',e);}
 try{installNoticeQueueV2901();}catch(e){console.warn('提示队列安装失败',e);}
 try{installPathV2901();}catch(e){console.warn('起步之路安装失败',e);}
 Object.assign(window,{noticePushV2901,noticeTickV2901,noticeBusyV2901,noticeResetV2901,showFirstPathV2901,pathTickV2901});
}
installFirstPathV2901();


function resetOnboardingV2901(){noticeResetV2901();clearInterval(PATH_RT_V2901.timer);PATH_RT_V2901.timer=null;PATH_RT_V2901.owner=null;PATH_RT_V2901.sawOpen=false;for(const id of ['firstPathV2901','firstPathPanelV2901','pacingStatsV2901'])document.getElementById(id)?.remove();if(typeof statsResetRuntimeV2901==='function')statsResetRuntimeV2901();}
// Optional device-only aggregates. Never change reward formulas or persist into player saves.
const STATS_V2901=Object.freeze({key:'xiantu_stats_v2901',enabledKey:'xiantu_stats_enabled_v2901',idleMs:60000,saveMs:15000});
const STAT_LABELS_V2901=Object.freeze({combat:'战斗',retreat:'闭关',boss:'镇岳台',abyss:'归墟',mini:'迷阵',elite:'凶煞',explore:'探索',war:'宗门战',tournament:'大比',forge:'锻造',market:'购买',dismantle:'分解',sect:'宗门差事',trip:'游历',other:'其他'});
const STAT_RT_V2901={enabled:false,data:null,owner:null,last:null,lastTick:0,lastInput:0,lastSave:0,dirty:false,ctx:'other',depth:0,fight:null,timer:null};
function statsNumberV2901(v){return typeof v==='number'&&Number.isFinite(v)?Math.max(0,Math.min(1e15,v)):0;}
function statsEmptyBucketV2901(){return {activeSec:0,gameDays:0,fights:0,wins:0,losses:0,exits:0,breakthroughs:0,failures:0,fightSec:{cinema:0,report:0},fightN:{cinema:0,report:0},exp:{},goldIn:{},goldOut:{}};}
function statsLoadV2901(){
 if(STAT_RT_V2901.data)return STAT_RT_V2901.data;
 let raw;try{const text=localStorage.getItem(STATS_V2901.key);if(text&&text.length<100000)raw=JSON.parse(text);}catch(_){}
 const data={v:1,realms:{}};
 if(raw?.v===1&&raw.realms&&typeof raw.realms==='object'&&!Array.isArray(raw.realms))for(let lv=0;lv<=16;lv++){
  const src=raw.realms[lv];if(!src||typeof src!=='object'||Array.isArray(src))continue;
  const b=statsEmptyBucketV2901();for(const k of Object.keys(b)){
   if(typeof b[k]==='number')b[k]=statsNumberV2901(src[k]);
   else for(const sub of (k==='fightSec'||k==='fightN'?['cinema','report']:Object.keys(STAT_LABELS_V2901)))if(statsNumberV2901(src[k]?.[sub]))b[k][sub]=statsNumberV2901(src[k][sub]);
  }data.realms[lv]=b;
 }
 return STAT_RT_V2901.data=data;
}
function statsBucketV2901(lv){const d=statsLoadV2901(),k=Math.max(0,Math.min(16,Math.floor(Number(lv)||0)));return d.realms[k]||(d.realms[k]=statsEmptyBucketV2901());}
function statsCanRecordV2901(){return STAT_RT_V2901.enabled&&player&&!player.testAccount999&&gameState!=='start'&&!document.getElementById('gameScreen')?.classList.contains('hidden');}
function statsSnapshotV2901(){return {exp:statsNumberV2901(player.exp),gold:statsNumberV2901(player.gold),days:statsNumberV2901(player.worldTime?.totalDays),level:Math.max(0,Math.min(16,Number(player.level)||0)),phase:Number(player.phase)||0};}
function statsResetRuntimeV2901(){STAT_RT_V2901.owner=null;STAT_RT_V2901.last=null;STAT_RT_V2901.lastTick=Date.now();STAT_RT_V2901.lastInput=0;STAT_RT_V2901.fight=null;STAT_RT_V2901.ctx='other';STAT_RT_V2901.depth=0;}
function statsSampleV2901(){
 const R=STAT_RT_V2901,now=Date.now();if(!statsCanRecordV2901()){R.last=null;R.owner=null;R.fight=null;R.lastTick=now;return;}
 const cur=statsSnapshotV2901();
 if(R.owner!==player){R.owner=player;R.last=cur;R.lastTick=now;R.fight=null;return;}
 const last=R.last;R.last=cur;
 const dt=Math.min(2000,Math.max(0,now-R.lastTick));R.lastTick=now;
 const active=!document.hidden&&document.visibilityState!=='hidden'&&R.lastInput>0&&now-R.lastInput<STATS_V2901.idleMs;
 if(active&&dt){statsBucketV2901(cur.level).activeSec+=dt/1000;if(R.fight?.owner===player)R.fight.sec+=dt/1000;R.dirty=true;}
 if(!last)return;
 const b=statsBucketV2901(last.level),days=cur.days-last.days,exp=cur.exp-last.exp,gold=cur.gold-last.gold;
 const ctx=R.ctx!=='other'?R.ctx:(gameState==='combat'||gameState==='combat-ending'?'combat':'other');
 const add=(obj,key,v)=>obj[key]=Math.min(1e15,(obj[key]||0)+v);
 if(days>0)b.gameDays+=days;
 if(exp>0)add(b.exp,ctx==='other'&&days>=30?'retreat':ctx,exp);
 if(cur.level>last.level||(cur.level===last.level&&cur.phase>last.phase))b.breakthroughs++;
 else if(exp<0&&player.breakthrough?.cooldownDays>0)b.failures++;
 if(gold>0)add(b.goldIn,ctx,gold);else if(gold<0)add(b.goldOut,ctx,-gold);
 if(days||exp||gold)R.dirty=true;
 if(R.dirty&&now-R.lastSave>=STATS_V2901.saveMs)statsSaveV2901();
}
function statsSaveV2901(){
 const R=STAT_RT_V2901;if(!R.enabled||!R.dirty)return true;
 try{localStorage.setItem(STATS_V2901.key,JSON.stringify(statsLoadV2901()));R.dirty=false;R.lastSave=Date.now();return true;}catch(_){return false;}
}
function statsSetEnabledV2901(enabled){
 if(STAT_RT_V2901.enabled){statsSampleV2901();statsSaveV2901();}
 STAT_RT_V2901.enabled=!!enabled;statsResetRuntimeV2901();
 try{localStorage.setItem(STATS_V2901.enabledKey,enabled?'1':'0');}catch(_){}
 clearInterval(STAT_RT_V2901.timer);STAT_RT_V2901.timer=null;
 if(enabled&&!document.hidden){STAT_RT_V2901.lastInput=Date.now();statsSampleV2901();STAT_RT_V2901.timer=setInterval(statsSampleV2901,1000);}
}
function statsFightStartV2901(){
 if(!statsCanRecordV2901())return;statsSampleV2901();let mode='cinema';try{if(localStorage.getItem('xiantu_battle_presentation_v2756')==='report')mode='report';}catch(_){}
 STAT_RT_V2901.fight={owner:player,enemy:currentEnemy,level:player.level,mode,sec:0};
}
function statsFightEndV2901(){
 statsSampleV2901();const R=STAT_RT_V2901,f=R.fight;R.fight=null;
 if(!statsCanRecordV2901()||!f||f.owner!==player||f.enemy!==currentEnemy)return;
 const b=statsBucketV2901(f.level),kind=COMBAT_FINISH_V2764.pending?.kind;b.fights++;b.fightN[f.mode]++;b.fightSec[f.mode]+=f.sec;
 if(kind==='victory')b.wins++;else if(kind==='defeat')b.losses++;else b.exits++;R.dirty=true;
}
function statsRowsV2901(){return Object.entries(statsLoadV2901().realms).sort((a,b)=>a[0]-b[0]).map(([lv,b])=>({level:+lv,realm:CULTIVATION_REALMS[lv]?.name||String(lv),...b}));}
function statsCsvV2901(){
 const q=v=>'"'+String(v).replace(/"/g,'""')+'"',lines=['level,realm,metric,source,value'];
 for(const r of statsRowsV2901())for(const [k,v] of Object.entries(r)){if(k==='level'||k==='realm')continue;
  if(typeof v==='number')lines.push([r.level,q(r.realm),k,'',v.toFixed(3)].join(','));
  else for(const [s,n] of Object.entries(v))lines.push([r.level,q(r.realm),k,q(s),n.toFixed(3)].join(','));
 }return '\ufeff'+lines.join('\r\n')+'\r\n';
}
function statsDownloadV2901(){let url,a;try{url=URL.createObjectURL(new Blob([statsCsvV2901()],{type:'text/csv;charset=utf-8'}));a=document.createElement('a');a.href=url;a.download='xiantu-local-stats.csv';document.body.appendChild(a);a.click();return true;}catch(_){showFloatingText('导出失败，请稍后重试','#ffb38a');return false;}finally{a?.remove();if(url)setTimeout(()=>URL.revokeObjectURL(url),1000);}}
function statsClearV2901(after){
 return gameConfirmOnceV2868114('stats-clear','清空本机统计？游戏存档不受影响。',()=>{
  try{localStorage.removeItem(STATS_V2901.key);}catch(_){showFloatingText('无法清空本机统计，请稍后重试','#ffb38a');return false;}
  STAT_RT_V2901.data={v:1,realms:{}};STAT_RT_V2901.dirty=false;statsResetRuntimeV2901();after?.();return true;
 });
}
function showPacingStatsV2901(){
 if(!forgeAllowedV2825())return;statsSampleV2901();statsSaveV2901();stopNavigationV2830();resetWorldMovementV28686();
 document.getElementById('pacingStatsV2901')?.remove();const owner=player,esc=escapeGameText;
 const el=document.createElement('div');el.id='pacingStatsV2901';el.className='mobile-inventory-overlay';el.style.zIndex='100003';el.setAttribute('role','dialog');el.setAttribute('aria-label','本机游玩统计');
 const sum=o=>Object.values(o).reduce((s,v)=>s+v,0),sources=o=>Object.entries(o).map(([k,v])=>`${STAT_LABELS_V2901[k]} ${Math.round(v)}`).join(' · ')||'—';
 el.innerHTML=`<div class="mobile-inventory-card" style="padding:16px;max-height:86vh;overflow:auto"><h3>📊 本机游玩统计</h3><p>默认关闭。开启后仅在本机累计，不上传、不写入角色存档。数据合计此设备上启用期间的角色；读档切换不计作收益。</p><p>在线及战斗时长仅计算页面可见且近期操作的时间。收支为实际余额变化，未识别来源归入“其他”；同次操作的收入与支出可能抵消。</p><button type="button" class="choice-btn" data-st="toggle">${STAT_RT_V2901.enabled?'暂停记录':'开启记录'}</button>
 ${statsRowsV2901().map(r=>`<section style="border-top:1px solid #665c43;padding:8px 0"><b>${esc(r.realm)}</b><p>活跃 ${(r.activeSec/60).toFixed(1)} 分钟 · 仙历 ${Math.round(r.gameDays)} 日 · 战斗 ${r.fights} 场（胜 ${r.wins} / 负 ${r.losses} / 其他结束 ${r.exits}）<br>演出平均 ${r.fightN.cinema?(r.fightSec.cinema/r.fightN.cinema).toFixed(1):'—'} 秒 · 战报平均 ${r.fightN.report?(r.fightSec.report/r.fightN.report).toFixed(1):'—'} 秒<br>破境/进阶 ${r.breakthroughs} · 失败 ${r.failures}</p><p>修为 ${Math.round(sum(r.exp))}：${esc(sources(r.exp))}<br>灵石收入 ${Math.round(sum(r.goldIn))}：${esc(sources(r.goldIn))}<br>灵石支出 ${Math.round(sum(r.goldOut))}：${esc(sources(r.goldOut))}</p></section>`).join('')||'<p>暂无统计记录。</p>'}
 <div style="display:flex;flex-wrap:wrap;gap:8px"><button class="choice-btn" data-st="csv">导出 CSV</button><button class="choice-btn" data-st="clear">清空统计</button><button class="choice-btn" data-st="close">关闭</button></div></div>`;
 el.addEventListener('click',e=>{if(player!==owner){el.remove();return;}const k=e.target.closest('[data-st]')?.dataset.st;
  if(k==='close'||e.target===el)el.remove();else if(k==='toggle'){statsSetEnabledV2901(!STAT_RT_V2901.enabled);showPacingStatsV2901();}else if(k==='csv')statsDownloadV2901();else if(k==='clear')statsClearV2901(()=>{if(document.getElementById('pacingStatsV2901'))showPacingStatsV2901();});});
 document.body.appendChild(el);el.querySelector('[data-st="close"]')?.focus();return el;
}
function saveManagerStatsV2901(el){
 const card=el?.querySelector('.mobile-inventory-card');if(!card||card.querySelector('.stats-entry-v2901'))return;
 const d=document.createElement('details');d.className='stats-entry-v2901';d.innerHTML='<summary>高级</summary><button type="button" class="choice-btn">📊 本机游玩统计（可选）</button>';
 d.querySelector('button').onclick=()=>{el.remove();showPacingStatsV2901();};card.appendChild(d);
}
function installStatsV2901(){
 // Scope source labels to actual synchronous mutations; preview formulas never start a source window.
 const groups={combat:['checkBattleEnd'],boss:['bossCommitV2887'],mini:['finishMiniWeaveV286840','finishMiniRealmV2778'],war:['settleWarV2775'],tournament:['recordTournamentRound'],retreat:['executeRetreatV2782'],forge:['mutateForgeV2825'],market:['buyMarketGearV2800','buyGeneralV2801','buyFromMapNpc','buyPetGrowthBatchV286845','buyLongevityPill','buyBreakthroughPillV28683'],dismantle:['bulkDismantleEquipment','dismantleOneEquipmentEncoded'],sect:['completeSectTask'],abyss:['claimAbyssRewardV2882'],elite:['claimEliteV2883'],explore:['claimExplorationV2828'],trip:['claimTripV286821']};
 for(const [kind,names] of Object.entries(groups))for(const name of names){const base=window[name];if(typeof base!=='function')continue;
  window[name]=function(...args){if(!statsCanRecordV2901())return base.apply(this,args);const R=STAT_RT_V2901,old=R.ctx,outer=R.depth===0;if(outer)statsSampleV2901();R.depth++;R.ctx=kind;
   try{return base.apply(this,args);}finally{R.depth--;if(outer)statsSampleV2901();R.ctx=old;}};Object.assign(window[name],base); // Preserve existing wrapper installation guards.
 }
 window.addEventListener('xiantu:combat-finishing',statsFightEndV2901);
 for(const ev of ['pointerdown','keydown','touchstart'])document.addEventListener(ev,()=>{if(STAT_RT_V2901.enabled)STAT_RT_V2901.lastInput=Date.now();},{capture:true,passive:true});
 document.addEventListener('visibilitychange',()=>{statsSampleV2901();statsSaveV2901();STAT_RT_V2901.lastTick=Date.now();clearInterval(STAT_RT_V2901.timer);STAT_RT_V2901.timer=null;if(!document.hidden&&STAT_RT_V2901.enabled)STAT_RT_V2901.timer=setInterval(statsSampleV2901,1000);});
 window.addEventListener('pagehide',()=>{statsSampleV2901();statsSaveV2901();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.getElementById('pacingStatsV2901')?.remove();document.getElementById('firstPathPanelV2901')?.remove();}});
 let enabled=false;try{enabled=localStorage.getItem(STATS_V2901.enabledKey)==='1';}catch(_){}if(enabled)statsSetEnabledV2901(true);
}
if(typeof installItemSafetyV2905==='function')installItemSafetyV2905();
installStatsV2901();
// END ONBOARDING_V2901
// V2903: local graphics preference; no game-state/reward changes or extra animation loop.
function ensureGraphicsButtonV2903(){
 const host=document.getElementById('characterUtilityActions');if(!host||document.getElementById('graphicsButtonV2903'))return;
 const b=document.createElement('button');b.type='button';b.id='graphicsButtonV2903';b.textContent='画质设置';b.onclick=showGraphicsV2903;host.appendChild(b);
}
function setGraphicsQualityV2903(mode){
 if(!forgeAllowedV2825()||!['auto','low','high'].includes(mode))return false;
 let saved=true;try{localStorage.setItem('xiantu_gfx_quality_v2876',mode);}catch(_){saved=false;}
 PERF_CONFIG.graphicsQuality=mode;PERF_CONFIG.lowEnd=graphicsLowV2903(mode);PERF_CONFIG.ultraSmooth=PERF_CONFIG.lowEnd;
 ALIVE_V2893.dprDowngraded=false;ALIVE_V2893.dprStrikes=0;ALIVE_V2893.lastFpsAt=PERF_CONFIG.fpsStartedAt;
 releaseStaticWorldCacheV2767();resizeWorldCanvas();updateWorldAtmosphere(getRegionInfo(currentRegion||'south').terrain);
 showGraphicsV2903(saved?'已应用，下次打开沿用本机选择。':'已应用；浏览器禁止保存，下次打开可能恢复自动。');return true;
}
function showGraphicsV2903(message=''){
 if(!forgeAllowedV2825())return;
 const labels={auto:'自动',low:'省电',high:'精细'},mode=PERF_CONFIG.graphicsQuality;
 const html='<section class="main-overview-v2822"><h3>画质设置</h3>'+Object.entries(labels).map(([k,v])=>`<button type="button" class="choice-btn" aria-pressed="${mode===k}" onclick="setGraphicsQualityV2903('${k}')">${v}${mode===k?' · 已选':''}</button>`).join('')+`<p>自动按设备选择，手机优先省电。省电简化光环与氛围；精细显示完整道纹与光影。</p><p>电脑精细画布最高1.5倍，持续掉帧会自动降低。手机精细画布最高2倍，持续低于24帧会回退；低内存设备保持1倍，地图仍最高30帧。</p><p role="status">${message||'仅保存本机画质选择，不改变角色数据。'}</p>${mapFxSettingsV2868104()}${typeof uiSettingsV2868109==='function'?uiSettingsV2868109():''}</section>`;
 toggleCharacterPanel(false);showStory(html,[{text:'返回地图',action:'return_to_map'}]);
}

// Walkable interiors share the world loop and controls; outdoor coordinates are never replaced.
let interiorV286886=null;
const INTERIOR_HALLS_V286886=new Set(['task_hall','main_hall','guest_hall','outer_elder_hall','elder_hall','qingxuan_academy','library','alchemy_hall','night_yaolu','beast_hall','forge_hall','forbidden_library','dormitory']);
// Each supported POI has its own authored scene. A three-entry LRU bounds decoded backgrounds.
const INTERIOR_SCENES_V286893={
 "shop": {
  "name": "百宝阁",
  "host": "掌柜",
  "service": "交易柜台",
  "station": "desk",
  "npc": "affairs",
  "props": [
   "book",
   "desk",
   "furnace"
  ],
  "description": "货柜里备有丹药、兵器与护甲。走到交易柜台可查看商品，购买时仍会核对数量与费用。"
 },
 "market": {
  "name": "仙市",
  "host": "仙市行商",
  "service": "仙市交易案",
  "station": "desk",
  "npc": "affairs",
  "props": [
   "book",
   "desk",
   "throne"
  ],
  "description": "诸家货品汇于此处。走到仙市交易案可查看原有商铺与商品。"
 },
 "home": {
  "name": "洞府",
  "host": "洞府留笺",
  "service": "洞府蒲团",
  "station": "cushion",
  "npc": "teaching",
  "props": [
   "book",
   "desk",
   "bed"
  ],
  "description": "窗外云山静好，蒲团已备。走近右侧蒲团可打开洞府原有修行与休息事务。"
 },
 "alchemy": {
  "name": "炼丹房",
  "host": "守炉丹师",
  "service": "丹火工位",
  "station": "furnace",
  "npc": "medicine",
  "props": [
   "book",
   "desk",
   "furnace"
  ],
  "description": "西域丹火温烈，炼丹仍须备齐材料。右侧工位可打开原有炼丹事务。"
 },
 "dormitory": {
  "name": "外门弟子居",
  "host": "弟子居留笺",
  "service": "修行蒲团",
  "station": "cushion",
  "npc": "teaching",
  "props": [
   "bed",
   "desk",
   "book"
  ],
  "description": "竹窗下可安置行囊，卧榻供弟子起居。右侧蒲团可办理弟子居原有休息与打坐事务。"
 },
 "task_hall": {
  "name": "外门任务堂",
  "host": "任务执事",
  "service": "任务登记案",
  "station": "desk",
  "npc": "affairs",
  "props": [
   "book",
   "desk",
   "book"
  ],
  "description": "墙上卷轴记录宗门差事。右侧登记案可查看任务与功绩事务。"
 },
 "guest_hall": {
  "name": "迎宾殿",
  "host": "迎宾弟子",
  "service": "迎宾茶案",
  "station": "desk",
  "npc": "affairs",
  "props": [
   "book",
   "desk",
   "throne"
  ],
  "description": "清茶迎客，礼册备妥。右侧茶案可查看迎宾殿原有事务。"
 },
 "outer_elder_hall": {
  "name": "外门长老院",
  "host": "外门执事",
  "service": "外门事务案",
  "station": "desk",
  "npc": "affairs",
  "props": [
   "book",
   "desk",
   "book"
  ],
  "description": "外勤卷宗与巡防册分门归档。右侧事务案可查看外门管理。"
 },
 "main_hall": {
  "name": "凌霄大殿",
  "host": "大殿值守",
  "service": "宗主议事案",
  "station": "desk",
  "npc": "discipline",
  "props": [
   "book",
   "desk",
   "book"
  ],
  "description": "大殿承接宗门议事与重大决议。右侧议事案沿用原有身份与事务权限。"
 },
 "elder_hall": {
  "name": "内门长老阁",
  "host": "长老阁执事",
  "service": "长老议事案",
  "station": "desk",
  "npc": "discipline",
  "props": [
   "book",
   "desk",
   "book"
  ],
  "description": "五院卷宗在此汇集。右侧议事案可查看长老阁原有事务。"
 },
 "qingxuan_academy": {
  "name": "清玄道院",
  "host": "道院弟子",
  "service": "清玄问道案",
  "station": "desk",
  "npc": "teaching",
  "props": [
   "book",
   "desk",
   "book"
  ],
  "description": "梅窗照琴，道院清宁。右侧问道案可办理原有师徒与道院事务。"
 },
 "library": {
  "name": "藏经阁",
  "host": "守阁弟子",
  "service": "典籍书案",
  "station": "desk",
  "npc": "teaching",
  "props": [
   "book",
   "desk",
   "book"
  ],
  "description": "典籍按门类收存，查阅仍按原有资格。右侧书案可打开藏经阁事务。"
 },
 "alchemy_hall": {
  "name": "丹庐药堂",
  "host": "药堂弟子",
  "service": "药堂丹炉",
  "station": "furnace",
  "npc": "medicine",
  "props": [
   "book",
   "desk",
   "furnace"
  ],
  "description": "药柜收存灵草，丹炉候火。右侧丹炉可进入原有炼丹与药堂事务。"
 },
 "night_yaolu": {
  "name": "深夜药庐",
  "host": "夜值药师",
  "service": "夜庐药炉",
  "station": "furnace",
  "npc": "medicine",
  "props": [
   "book",
   "desk",
   "furnace"
  ],
  "description": "雨声绕窗，药灯未熄。右侧药炉可查看深夜药庐原有事务与剧情。"
 },
 "beast_hall": {
  "name": "御兽堂",
  "host": "御兽弟子",
  "service": "灵兽契约案",
  "station": "desk",
  "npc": "affairs",
  "props": [
   "book",
   "desk",
   "book"
  ],
  "description": "兽栏、饲料与契约分处保管。右侧契约案可查看原有灵宠与御兽事务。"
 },
 "forge_hall": {
  "name": "炼器阁",
  "host": "炼器执事",
  "service": "锻造工位",
  "station": "desk",
  "npc": "discipline",
  "props": [
   "book",
   "desk",
   "furnace"
  ],
  "description": "炉火锻铁，器架收锋。右侧锻造工位可办理原有炼器事务。"
 },
 "forbidden_library": {
  "name": "禁书秘阁",
  "host": "禁阁守卫",
  "service": "封印书案",
  "station": "desk",
  "npc": "discipline",
  "props": [
   "book",
   "desk",
   "book"
  ],
  "description": "封绳护卷，禁典有序。右侧封印书案仍须按原有资格办理禁阁事务。"
 }
};
const INTERIOR_SCENE_CACHE_V286893=new Map();
function interiorSceneIdV286893(p){
 const key=p?.action==='lingxiao_building'?p.buildingId:p?.action;
 return Object.hasOwn(INTERIOR_SCENES_V286893,key)?key:null;
}
function prepareInteriorSceneV286893(p){
 const id=interiorSceneIdV286893(p);if(!id)return null;
 let entry=INTERIOR_SCENE_CACHE_V286893.get(id);
 if(entry&&!entry.failed){INTERIOR_SCENE_CACHE_V286893.delete(id);INTERIOR_SCENE_CACHE_V286893.set(id,entry);return entry;}
 if(entry)INTERIOR_SCENE_CACHE_V286893.delete(id); // A new visit may retry; drawing never retries.
 entry={id,image:null,pending:null,failed:false};INTERIOR_SCENE_CACHE_V286893.set(id,entry);
 while(INTERIOR_SCENE_CACHE_V286893.size>3){
  const key=INTERIOR_SCENE_CACHE_V286893.keys().next().value,old=INTERIOR_SCENE_CACHE_V286893.get(key);
  INTERIOR_SCENE_CACHE_V286893.delete(key);
  if(old.pending){old.pending.onload=old.pending.onerror=null;old.pending.src='';old.pending=null;}old.image=null;
 }
 const image=new Image();entry.pending=image;image.decoding='async';
 image.onload=()=>{
  image.onload=image.onerror=null;entry.pending=null;
  if(INTERIOR_SCENE_CACHE_V286893.get(id)!==entry)return;
  if(image.naturalWidth>0)entry.image=image;else entry.failed=true;
 };
 image.onerror=()=>{image.onload=image.onerror=null;entry.pending=null;if(INTERIOR_SCENE_CACHE_V286893.get(id)===entry)entry.failed=true;};
 image.src='./interior-scenes-v286893/'+id+'.webp';return entry;
}
function interiorSceneImageV286893(s){return INTERIOR_SCENE_CACHE_V286893.get(s.sceneId)?.image||null;}

function interiorKindV286886(p){
 if(!p)return null;
 if(p.action==='lingxiao_building'&&INTERIOR_HALLS_V286886.has(p.buildingId))return /alchemy|yaolu|forge/.test(p.buildingId)?'workshop':/library/.test(p.buildingId)?'library':p.buildingId==='dormitory'?'home':'hall';
 return ({shop:'shop',market:'shop',home:'home',alchemy:'workshop'})[p.action]||null;
}
function clearInteriorV286886(){
 const s=interiorV286886;interiorV286886=null;if(s?.floor){s.floor.width=s.floor.height=1;}
 document.documentElement.classList.remove('interior-v286886');document.getElementById('interiorHudV286886')?.remove();
 if(typeof resetPaintedMotionV2838==='function')resetPaintedMotionV2838();
}
function interiorStateV286886(){
 const s=interiorV286886;if(!s)return null;
 if(s.owner!==player||s.region!==currentRegion||!FLAT_WORLD.pois.includes(s.poi)){clearInteriorV286886();return null;}
 return s;
}
function tryEnterInteriorV286886(p){
 const kind=interiorKindV286886(p);if(!kind)return false;
 if(!canMapNpcActV2864()||isWorldOverlayOpen()||!FLAT_WORLD.pois.includes(p)||Math.hypot(FLAT_WORLD.player.x-p.x,FLAT_WORLD.player.y-p.y)>p.r+62)return true;
 if(p.action==='lingxiao_building'){const access=canAccessBuilding(p.buildingId);if(!access.allowed){showFloatingText(access.reason,'#ffd76a');return true;}syncTaskWithLingxiaoBuilding(p.buildingId);}
 if(typeof tutorialFreeExploreUnlocked==='function'&&tutorialState.active&&!tutorialFreeExploreUnlocked())return false;
 resetWorldMovementV28686();clearInteriorV286886();prepareInteriorArtV286892();prepareInteriorSceneV286893(p);
 const label=({shop:'交易柜台',home:'修行蒲团',workshop:'炼制工位',library:'典籍书案',hall:'宗门事务案'})[kind];
 interiorV286886={owner:player,region:currentRegion,poi:p,kind,player:{x:288,y:352},path:[],floor:null,view:null,
  stations:[{id:'host',x:176,y:176,name:kind==='home'?'洞府留笺':kind==='shop'?'掌柜':'值守弟子',dialog:true},{id:'service',x:400,y:176,name:label},{id:'door',x:288,y:400,name:'离开建筑'}]};
 const session=interiorV286886;session.sceneId=interiorSceneIdV286893(p);const scene=INTERIOR_SCENES_V286893[session.sceneId];if(scene){session.stations[0].name=scene.host;session.stations[1].name=scene.service;}document.documentElement.classList.add('interior-v286886');
 const hud=document.createElement('div');hud.id='interiorHudV286886';
 const title=document.createElement('strong');title.textContent=p.name+' · 室内';hud.appendChild(title);
 const hint=document.createElement('span');hint.id='interiorHintV286886';hint.textContent='摇杆 / 方向键移动 · 点地行走 · 靠近后交互';hud.appendChild(hint);
 const menu=document.createElement('button');menu.type='button';menu.textContent='角色';menu.className='interior-menu-v286886';menu.onclick=()=>{if(interiorStateV286886()===session&&!isWorldOverlayOpen()){resetWorldMovementV28686();toggleCharacterPanel(true);}};hud.appendChild(menu);
 const bag=document.createElement('button');bag.type='button';bag.textContent='行囊';bag.className='interior-bag-v286886';bag.onclick=()=>{if(interiorStateV286886()===session&&!isWorldOverlayOpen()){resetWorldMovementV28686();showMobileInventory();}};hud.appendChild(bag);
 const exit=document.createElement('button');exit.type='button';exit.textContent='走向出口';exit.onclick=()=>{const s=interiorStateV286886();if(s===session&&!isWorldOverlayOpen())interiorRouteV286886(s,288,400);};hud.appendChild(exit);
 addHallTravelV286888(hud,session);
 document.getElementById('worldPanel').appendChild(hud);resetPaintedMotionV2838();return true;
}
// Session-owned intent: walk to the door first, then reuse outdoor routing and entry guards.
function hallDestinationsV286888(s){
 if(!s||s.poi.action!=='lingxiao_building')return [];
 return FLAT_WORLD.pois.filter(p=>p!==s.poi&&p.action==='lingxiao_building'&&INTERIOR_HALLS_V286886.has(p.buildingId)&&canAccessBuilding(p.buildingId).allowed);
}
function addHallTravelV286888(hud,s){
 const halls=hallDestinationsV286888(s);if(!halls.length)return;
 const row=document.createElement('div');row.className='interior-travel-v286888';row.onkeydown=e=>e.stopPropagation();
 const select=document.createElement('select');select.setAttribute('aria-label','前往其他殿宇');
 for(const p of halls){const option=document.createElement('option');option.value=p.id;option.textContent=p.name;select.appendChild(option);}
 const button=document.createElement('button');button.type='button';button.textContent='步行前往';
 button.onclick=()=>queueHallTravelV286888(s,select.value);
 row.appendChild(select);row.appendChild(button);hud.appendChild(row);
}
function queueHallTravelV286888(s,id){
 if(interiorStateV286886()!==s||isWorldOverlayOpen()||document.hidden||!canMapNpcActV2864())return false;
 const goal=hallDestinationsV286888(s).find(p=>p.id===id);
 if(!goal){showFloatingText('该殿宇当前不可前往。','#ffd76a');return false;}
 resetWorldMovementV28686();if(!interiorRouteV286886(s,288,400))return false;
 s.hallDestination=goal;showFloatingText('先走出门，再前往'+goal.name+'；移动或点地可取消。','#9edcff');return true;
}
function interiorCellV286886(x,y){
 if(x<1||x>16||y<2||y>12||(y===5&&(x===5||x===12)))return false;
 return !((y>=3&&y<=4&&((x>=2&&x<=4)||(x>=13&&x<=15)))||(y===3&&x>=7&&x<=10));
}
function interiorWalkV286886(x,y){return [[-10,-10],[10,-10],[-10,10],[10,10]].every(([dx,dy])=>interiorCellV286886(Math.floor((x+dx)/32),Math.floor((y+dy)/32)));}
function interiorRouteV286886(s,x,y){
 s.hallDestination=null;
 const sx=Math.floor(s.player.x/32),sy=Math.floor(s.player.y/32),tx=Math.floor(x/32),ty=Math.floor(y/32);
 if(!interiorCellV286886(tx,ty))return false;
 const key=(a,b)=>b*18+a,start=key(sx,sy),goal=key(tx,ty),prev=new Map([[start,null]]),queue=[start];
 for(let n=0;n<queue.length&&!prev.has(goal);n++){const at=queue[n],cx=at%18,cy=Math.floor(at/18);for(const [dx,dy]of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=cx+dx,ny=cy+dy,k=key(nx,ny);if(interiorCellV286886(nx,ny)&&!prev.has(k)){prev.set(k,at);queue.push(k);}}}
 if(!prev.has(goal))return false;const path=[];for(let k=goal;k!==null;k=prev.get(k))path.push({x:(k%18)*32+16,y:Math.floor(k/18)*32+16});path.reverse();
 // First centre prevents diagonal corner-cutting when the actor is off the tile centre.
 s.path=path;if(interiorWalkV286886(x,y))s.path.push({x,y});return true;
}
function interiorTapV286886(canvas,x,y){
 const s=interiorStateV286886();if(!s)return false;if(isWorldOverlayOpen()||!s.view)return true;
 const r=canvas.getBoundingClientRect(),v=s.view,wx=((x-r.left)*v.vw/r.width-v.x)/v.scale,wy=((y-r.top)*v.vh/r.height-v.y)/v.scale;
 if(v.painted&&wx>=256&&wx<=320&&wy>=392&&wy<=444){interiorRouteV286886(s,288,400);return true;}
 const point=v.painted?unprojectInteriorV286892(wx,wy):{x:wx,y:wy};if(!point){s.hallDestination=null;return true;}
 const station=s.stations.find(a=>Math.hypot(a.x-point.x,a.y-point.y)<30);
 interiorRouteV286886(s,station?.x??point.x,station?(station.y+(station.id==='door'?0:32)):point.y);return true;
}
function leaveInteriorV286886(){
 const s=interiorStateV286886();if(!s||isWorldOverlayOpen()||!canMapNpcActV2864()||document.hidden)return;
 const goal=s.hallDestination;clearInteriorV286886();resetWorldMovementV28686();FLAT_WORLD._lastNearbyId=null;FLAT_WORLD._lastAreaKey='';updateWorldHUD();
 if(!goal)return;
 if(!FLAT_WORLD.pois.includes(goal)||!canAccessBuilding(goal.buildingId).allowed){showFloatingText('目标殿宇已不可前往。','#ffd76a');return;}
 startPointNavigationV28685({...goal,mark:false,silent:true,enterPoiV2904:goal});
}
function interiorInteractV286886(){
 const s=interiorStateV286886();if(!s)return false;if(isWorldOverlayOpen()||!canMapNpcActV2864())return true;
 const a=s.stations.find(a=>Math.hypot(a.x-s.player.x,a.y-s.player.y)<48);if(!a){showFloatingText('走近人物或设施，再点击交互','#e7d6ab');return true;}
 if(a.id==='door'){leaveInteriorV286886();return true;}
 resetWorldMovementV28686();
 if(s.poi.action==='lingxiao_building'){const access=canAccessBuilding(s.poi.buildingId);if(!access.allowed){showFloatingText(access.reason,'#ffd76a');return true;}}
 if(a.dialog){const description=INTERIOR_SCENES_V286893[s.sceneId]?.description||'右侧工位可办理这里的事务。';showStory('<h3>'+a.name+'</h3><p>'+description+'离开时走到南侧门口即可。</p>',[{text:'继续在室内走动',action:'return_to_map'}]);}
 else if(s.poi.action==='lingxiao_building')enterLingxiaoBuilding(s.poi.buildingId);
 else showLocation(s.poi.action);
 return true;
}
function updateInteriorV286886(dt){
 const s=interiorStateV286886();if(!s)return false;if(isWorldOverlayOpen()||!canMapNpcActV2864()){if(s.hallDestination){s.hallDestination=null;s.path=[];}return true;}
 const input=mapInputVectorV2868100(),p=s.player;let dx=input.x,dy=input.y;
 if(dx||dy){s.path=[];s.hallDestination=null;}else if(s.path.length){const a=s.path[0],d=Math.hypot(a.x-p.x,a.y-p.y);if(d<2){p.x=a.x;p.y=a.y;s.path.shift();}else{dx=(a.x-p.x)/d;dy=(a.y-p.y)/d;}}
 const d=Math.max(1,Math.hypot(dx,dy)),step=Math.min(.05,Math.max(0,dt||0))*150,remaining=s.path.length?Math.hypot(s.path[0].x-p.x,s.path[0].y-p.y):step,travel=Math.min(step,remaining);
 // Substeps preserve walls and furniture on a delayed frame.
 for(let i=0,n=Math.max(1,Math.ceil(travel/3));i<n;i++){const x=p.x+dx/d*travel/n,y=p.y+dy/d*travel/n;if(interiorWalkV286886(x,p.y))p.x=x;if(interiorWalkV286886(p.x,y))p.y=y;}
  if(Math.abs(p.x-288)<24&&p.y>390){leaveInteriorV286886();return true;}
 const near=s.stations.find(a=>Math.hypot(a.x-p.x,a.y-p.y)<48),hint=document.getElementById('interiorHintV286886');
 const message=near?'交互 · '+near.name:'摇杆 / 方向键移动 · 点地行走 · 靠近后交互';if(hint&&hint.textContent!==message)hint.textContent=message;return true;
}
function interiorFloorV286886(s){
 if(s.floor)return s.floor;const c=document.createElement('canvas');c.width=576;c.height=448;const x=c.getContext('2d');
 x.fillStyle='#22322d';x.fillRect(0,0,576,448);
 for(let row=2;row<13;row++)for(let col=1;col<17;col++){x.fillStyle=(row+col)%2?'#897050':'#947959';x.fillRect(col*32,row*32,31,31);x.fillStyle='#5a4b37';x.fillRect(col*32+4,row*32+24,20,1);}
 x.fillStyle='#364b40';x.fillRect(24,22,528,42);x.fillStyle='#ba9c65';x.fillRect(24,58,528,5);
 for(const px of [32,528]){x.fillStyle='#704b35';x.fillRect(px,38,16,374);x.fillStyle='#c2a16b';x.fillRect(px+3,38,3,374);}
 for(const px of [96,432]){x.fillStyle='#c8d7bb';x.fillRect(px,29,48,23);x.strokeStyle='#66563d';for(let i=0;i<5;i++){x.beginPath();x.moveTo(px+i*12,29);x.lineTo(px+i*12,52);x.stroke();}}
 x.fillStyle=s.kind==='home'?'#406052':'#763e38';x.fillRect(224,144,128,224);x.strokeStyle='#d2b275';x.lineWidth=3;x.strokeRect(230,150,116,212);
 for(const [px,w]of [[64,96],[416,96],[224,128]]){x.fillStyle='#302d23';x.fillRect(px,98,w,64);x.fillStyle='#654633';x.fillRect(px,86,w,64);x.fillStyle='#c8a36c';x.fillRect(px,86,w,7);for(let i=0;i<w/16;i++){x.fillStyle=['#799280','#a9926b','#7d8d9d'][i%3];x.fillRect(px+5+i*16,100,10,33);}}
 if(s.kind==='home'){x.fillStyle='#d6c49c';x.fillRect(66,98,90,48);x.fillStyle='#547b76';x.fillRect(84,100,70,44);x.fillStyle='#ede0b8';x.fillRect(68,102,18,38);}
 if(s.kind==='workshop'){x.fillStyle='#273e37';x.beginPath();x.arc(464,118,27,0,Math.PI*2);x.fill();x.strokeStyle='#bc995c';x.lineWidth=5;x.stroke();x.fillStyle='#d8985d';x.beginPath();x.arc(464,133,9,0,Math.PI*2);x.fill();}
 x.fillStyle='#2b3732';x.fillRect(256,400,64,48);x.fillStyle='#d2b478';x.fillRect(256,400,64,5);x.font='16px serif';x.textAlign='center';x.fillText('出口',288,433);
 s.floor=c;return c;
}
// Bounded shared textures, requested only on entry. No per-room requests, RAFs or timers.
const INTERIOR_ART_V286892={started:false,room:null,props:null,npc:null,ready:false};
const INTERIOR_FRAMES_V286892={bed:[0,100,438,314],desk:[439,100,432,314],book:[930,0,310,429],furnace:[40,415,345,493],throne:[404,430,474,466],pillar:[980,425,200,479],cushion:[45,940,340,290],redRug:[407,898,454,345],jadeRug:[866,898,370,345]};
function prepareInteriorArtV286892(){
 const a=INTERIOR_ART_V286892;if(a.started)return;a.started=true;
 for(const [key,url]of [['room','./interior-painted-v286892/room.webp'],['props','./interior-painted-v286892/props.webp'],['npc','./art/npc/sect-stewards-v286879.webp']]){
  const image=new Image();image.decoding='async';
  image.onload=()=>{if(image.naturalWidth>0)a[key]=image;image.onload=image.onerror=null;a.ready=!!(a.room&&a.props);};
  image.onerror=()=>{image.onload=image.onerror=null;};image.src=url;
 }
}
// The logical floor and its collision grid remain unchanged. Both drawing and picking use this mapping.
function projectInteriorV286892(x,y){const t=(y-64)/352,w=388+138*t;return {x:288+(x-288)/512*w,y:132+t*276,k:w/512};}
function unprojectInteriorV286892(x,y){const t=(y-132)/276,w=388+138*t;if(!Number.isFinite(x)||!Number.isFinite(y)||t<0||t>1||w<=0)return null;const wx=288+(x-288)*512/w;return wx>=32&&wx<=544?{x:wx,y:64+t*352}:null;}
function interiorPropV286892(ctx,name,x,y,width,height){
 const a=INTERIOR_ART_V286892,f=INTERIOR_FRAMES_V286892[name];if(!a.props||!f)return;
 const h=height||width*f[3]/f[2];ctx.drawImage(a.props,...f,x-width/2,y-h,width,h);
}
function paintedInteriorFloorV286892(s){
 const sceneImage=interiorSceneImageV286893(s);
 if(s.floor&&s.floorPainted&&s.floorSceneImage===sceneImage)return s.floor;
 if(s.floor)s.floor.width=s.floor.height=1;
 const c=document.createElement('canvas');c.width=1152;c.height=896;const ctx=c.getContext('2d');ctx.scale(2,2);
 ctx.drawImage(sceneImage||INTERIOR_ART_V286892.room,0,0,576,448);
 if(!sceneImage){const rug=projectInteriorV286892(288,370);interiorPropV286892(ctx,s.kind==='home'?'jadeRug':'redRug',rug.x,rug.y,158,192);}
 // Door marker uses text drawn by the game, so generated art never dictates an interaction label.
 ctx.fillStyle='rgba(30,24,18,.82)';ctx.fillRect(260,414,56,21);ctx.font='14px serif';ctx.textAlign='center';ctx.fillStyle='#ead39b';ctx.fillText('出口',288,430);
 s.floor=c;s.floorPainted=true;s.floorSceneImage=sceneImage;return c;
}
function drawPaintedInteriorV286892(ctx,s){
 ctx.drawImage(paintedInteriorFloorV286892(s),0,0,576,448);
 const kinds={home:['bed','desk','book'],hall:['book','throne','furnace'],library:['book','desk','book'],workshop:['book','desk','furnace'],shop:['book','desk','book']},scene=INTERIOR_SCENES_V286893[s.sceneId],names=scene?.props||kinds[s.kind]||kinds.hall;
 const items=[{type:'prop',name:names[0],x:112,y:160,w:104},{type:'prop',name:names[1],x:288,y:128,w:128},{type:'prop',name:names[2],x:464,y:160,w:100},
  {type:s.kind==='home'?'prop':'npc',name:'desk',x:176,y:192,w:38},
  {type:'prop',name:scene?.station||(s.kind==='home'?'cushion':s.kind==='workshop'?'furnace':'desk'),x:400,y:192,w:38},
  {type:'player',x:s.player.x,y:s.player.y,w:0}];
 if(s.kind==='hall'&&!interiorSceneImageV286893(s))for(const x of [12,564]){const p=projectInteriorV286892(x,345);interiorPropV286892(ctx,'pillar',p.x,p.y,30,175);}
 items.sort((a,b)=>a.y-b.y);
 for(const item of items){const p=projectInteriorV286892(item.x,item.y);
  if(item.type==='player'){
   const scale=.95*p.k;ctx.save();ctx.translate(p.x-s.player.x*scale,p.y-(s.player.y+17)*scale);ctx.scale(scale,scale);drawActor25DV2770(ctx,s.player);ctx.restore();
  }else if(item.type==='npc'){
   const img=INTERIOR_ART_V286892.npc,key=scene?.npc||(s.kind==='workshop'?'medicine':s.kind==='library'?'teaching':'affairs'),frame=SECT_STEWARDS_V286865[key],h=88*p.k;
   if(img){const w=h*frame.w/941;ctx.drawImage(img,frame.x,0,frame.w,941,p.x-w/2,p.y-h,w,h);}
   else{ctx.save();ctx.translate(p.x,p.y-23*p.k);ctx.scale(p.k,p.k);drawMapNpcV2863(ctx,{action:s.kind==='shop'?'npc_trader':'npc_elder'});ctx.restore();}
  }else interiorPropV286892(ctx,item.name,p.x,p.y,item.w*p.k);
 }
 if(s.path.length){const t=projectInteriorV286892(s.path.at(-1).x,s.path.at(-1).y);ctx.strokeStyle='#ead59c';ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(t.x,t.y,10,5,0,0,Math.PI*2);ctx.stroke();}
 // Labels are grounded to the interactable locations, not baked into the image.
 for(const a of s.stations){if(a.id==='door')continue;const p=projectInteriorV286892(a.x,a.y),near=Math.hypot(a.x-s.player.x,a.y-s.player.y)<48;
  ctx.font='bold 14px serif';ctx.textAlign='center';const w=ctx.measureText(a.name).width+18;
  ctx.fillStyle=near?'rgba(83,62,31,.92)':'rgba(18,27,25,.86)';ctx.fillRect(p.x-w/2,p.y+13,w,22);ctx.fillStyle=near?'#ffe5a3':'#e9d6b0';ctx.fillText(a.name,p.x,p.y+29);
 }
}

function drawInteriorV286886(){
 const s=interiorStateV286886();if(!s)return false;const canvas=document.getElementById('worldCanvas'),ctx=canvas.getContext('2d'),dpr=canvas._dpr||1,vw=canvas.width/dpr,vh=canvas.height/dpr;
 const painted=!!(INTERIOR_ART_V286892.props&&(INTERIOR_ART_V286892.room||interiorSceneImageV286893(s))),landscape=vw>vh,top=landscape?96:174,bottom=landscape?12:150;
 const scale=painted&&!landscape?Math.min(1,(vw-16)/576*1.45,Math.max(100,vh-top-bottom)/448):Math.min((vw-24)/576,Math.max(100,vh-top-bottom)/448);
 const point=painted?projectInteriorV286892(s.player.x,s.player.y):s.player;
 const x=576*scale<=vw?(vw-576*scale)/2:Math.min(0,Math.max(vw-576*scale,vw/2-point.x*scale)),y=top+Math.max(0,(vh-top-bottom-448*scale)/2);
 s.view={x,y,scale,vw,vh,painted};ctx.setTransform(dpr,0,0,dpr,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';ctx.fillStyle='#101d19';ctx.fillRect(0,0,vw,vh);ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);if(painted){drawPaintedInteriorV286892(ctx,s);ctx.restore();return true;}ctx.drawImage(interiorFloorV286886(s),0,0);
 for(const a of s.stations){if(a.id==='door')continue;ctx.fillStyle='#e5ce9c';ctx.font='bold 20px serif';ctx.textAlign='center';ctx.fillText(a.name,a.x,a.y-38);
  if(a.dialog){ctx.fillStyle='#344f51';ctx.beginPath();ctx.moveTo(a.x,a.y-25);ctx.lineTo(a.x-13,a.y+10);ctx.lineTo(a.x+13,a.y+10);ctx.closePath();ctx.fill();ctx.fillStyle='#d7b990';ctx.beginPath();ctx.arc(a.x,a.y-28,7,0,Math.PI*2);ctx.fill();}
  else{ctx.fillStyle='#b29667';ctx.fillRect(a.x-21,a.y-18,42,25);ctx.fillStyle=s.kind==='workshop'?'#526f65':'#ece0bc';ctx.fillRect(a.x-13,a.y-26,26,11);}
 }
 if(s.path.length){const t=s.path.at(-1);ctx.strokeStyle='#efcf82';ctx.lineWidth=2;ctx.beginPath();ctx.arc(t.x,t.y,9,0,Math.PI*2);ctx.stroke();}
 drawActor25DV2770(ctx,s.player);ctx.restore();return true;
}

window.__xiantuBuildFilesV2814=window.__xiantuBuildFilesV2814||{};window.__xiantuBuildFilesV2814['xiantu-v28684-duel.js']='28.68.124';


if(typeof installBagViewV2905==='function')installBagViewV2905();

// Optional atmosphere is outside the required 40-module boot sequence.
const MAP_FX_HOST_V2868104={loading:null,failed:false,api:null,revision:0};
function mapFxPreferenceV2868104(){try{const p=localStorage.getItem('xiantu_map_fx_v2868104');return ['off','low','high'].includes(p)?p:'auto';}catch(_){return 'auto';}}
function mapFxReducedV2868104(){return typeof matchMedia==='function'&&matchMedia('(prefers-reduced-motion: reduce)').matches;}
function mapFxLoadV2868104(){
 const h=MAP_FX_HOST_V2868104;if(h.api)return Promise.resolve(h.api);if(h.failed)return Promise.resolve(null);if(h.loading)return h.loading;
 h.loading=new Promise(resolve=>{const s=document.createElement('script');let done=false;const finish=()=>{if(done)return;done=true;clearTimeout(timer);h.api=window.XiantuMapFxV2868104||null;h.failed=!h.api;resolve(h.api);};const timer=setTimeout(finish,10000);s.src='./xiantu-v2868104-map-fx.js?v='+encodeURIComponent(window.__xiantuBuildFilesV2814?.['xiantu-v28684-duel.js']||'28.68.116');s.onload=finish;s.onerror=finish;document.head.appendChild(s);});return h.loading;
}
function mapFxCancelV2868104(){const h=MAP_FX_HOST_V2868104;h.revision++;try{h.api?.pause(true);}catch(_){h.failed=true;}}
function mapFxFrameV2868104(t){
 const h=MAP_FX_HOST_V2868104;if(h.failed)return;
 if(mapFxPreferenceV2868104()==='off'||mapFxReducedV2868104()){try{h.api?.pause(true);}catch(_){}return;}
 if(document.hidden||isWorldOverlayOpen()||gameState!=='exploring'||!document.body.classList.contains('flat-world-active')){try{h.api?.pause(false);}catch(_){}return;}
 if(!h.api){mapFxLoadV2868104();return;}
 try{h.api.frame(t);}catch(_){h.api.pause(true);h.failed=true;}
}
function mapFxEventV2868104(kind,success){
 if(mapFxPreferenceV2868104()==='off'||mapFxReducedV2868104()||document.hidden||!['pill','breakthrough'].includes(kind))return;
 const owner=player,revision=MAP_FX_HOST_V2868104.revision,started=performance.now();
 mapFxLoadV2868104().then(api=>{if(api&&owner===player&&revision===MAP_FX_HOST_V2868104.revision&&!document.hidden&&performance.now()-started<1500)api.event(kind,!!success,owner,started);}).catch(()=>{});
}
function setMapFxV2868104(mode){
 if(!forgeAllowedV2825()||!['off','auto','low','high'].includes(mode))return;
 mapFxCancelV2868104();let saved=true;try{localStorage.setItem('xiantu_map_fx_v2868104',mode);}catch(_){saved=false;}
 if(!saved){showGraphicsV2903('浏览器未允许保存特效设置，已停止本次特效。');MAP_FX_HOST_V2868104.failed=true;return;}
 MAP_FX_HOST_V2868104.api?.resetQuality();showGraphicsV2903('地图与事件特效已调整；仅影响本机显示。');
}
function mapFxSettingsV2868104(){
 const mode=mapFxPreferenceV2868104(),labels={off:'关',low:'低',high:'高',auto:'自动'};
 return '<h3>地图 / 事件特效</h3>'+Object.entries(labels).map(([key,label])=>`<button type="button" class="choice-btn" aria-pressed="${mode===key}" onclick="setMapFxV2868104('${key}')">特效：${label}${mode===key?' · 已选':''}</button>`).join('')+'<p>自动档手机优先低档；持续掉帧会逐级降低本次特效。炼丹房与药庐显示彩色丹烟和地火阵，大殿显示盘旋灵气，秘境入口显示漩涡；对应手绘室内也有特效。地图只显示邻近已探索地点，战斗沿用原画面。</p>'+(mapFxReducedV2868104()?'<p>系统已开启减少动态效果，本次额外特效关闭。</p>':'');
}
