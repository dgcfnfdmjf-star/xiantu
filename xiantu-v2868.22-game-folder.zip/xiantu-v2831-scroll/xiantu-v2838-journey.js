// V28.47 · 三界行旅：剧情确认、纪事回看、可选游历与安全续行。
const JOURNEYS_V2838=[
 {id:'journey_01',level:6,title:'一 · 北雪归灯',place:'北域 · 断雪驿',enemy:'噬灯雪魇',requires:'main_16',
  desc:'炼虚游历。三万年战事留下的不是一张战报，而是一盏盏等待归人的灯。',
  opening:[['驿站守灯人','雪已封山七日。有人说那些灯会引来魔物，叫我全熄了。可渡口还有人没回来。'],['苏晚晴','她将药包放进你的行囊：“先把人带回来。伤可以慢慢养，名字不能只留在碑上。”'],['你','雪中有一道吞噬火光的影子。你循着最后一盏灯踏出驿门，先护住归路，再追查它的来处。']],
  ending:[['驿站守灯人','“少了一个……”老人逐一数过归来的人。最年轻的护卫把一盏破灯交给他，灯芯还温着。'],['你','你在雪下找到护卫的名牌。众人等待你决定：让他的名字留在这里，还是将遗物送回南域？']],
  choices:[['lamp','留名守灯'],['home','送还遗物']],
  outcomes:{lamp:'石碑多了一行名字。守灯人约定，只要驿站还在，这盏灯便不会熄灭。',home:'你托归乡商队送回遗物。数日后，一封短笺从南域寄来：知道他曾救人，家人便有了等候的答案。'}},
 {id:'journey_02',level:7,title:'二 · 万宗一桥',place:'人族群峰 · 悬桥',enemy:'裂桥怨灵',requires:'journey_01',
  desc:'合体游历。数家人族宗门争夺一座灵桥，桥下的难民却只想平安渡河。',
  opening:[['青云使者','“先让我宗伤员过桥。”另一位掌事已拔剑，两边都拿出了旧日的盟约。'],['顾承渊','“他们争的是谁先低头。你若只赢一场，明日仍会再争。”他把几家宗门的渡册摊在石上。'],['你','争吵激起桥下多年积聚的怨气。旧阵断裂，裂桥怨灵攀上桥面；在谈规矩之前，必须先守住桥。']],
  ending:[['顾承渊','怨灵散去，桥还立着。掌事们终于收剑，但谁都不肯先说方才错在哪里。'],['你','你可以安排各宗轮值护桥，也可以建立不问宗籍的渡册。这份约定不改变任何宗门的战力，却会改变过桥的人。']],
  choices:[['watch','各宗轮值护桥'],['register','不问宗籍通行']],
  outcomes:{watch:'各宗按月派弟子护桥。顾承渊第一个写下名字，将公约交给过桥的人监督。',register:'伤者与老幼优先的渡册挂上桥头。第一位签名的掌事没有写宗号，只写了自己的名字。'}},
 {id:'journey_03',level:8,title:'三 · 焚营余火',place:'魔域 · 灰烬营地',enemy:'吞烬魔傀',requires:'journey_02',
  desc:'大乘游历。姬红绫带来一份停火信。营地里藏着的答案，远比阵营二字复杂。',
  opening:[['姬红绫','“先收剑。”她指着灰烬里蜷缩的身影，“他们是被征来的药工，营地败了，也没人肯带走。”'],['魔族药工','药工不敢抬头，只递出烧损的册子。册页记满试验日期，最后一页被人撕去了一半。'],['你','营地深处的魔傀仍在执行焚毁命令。救人的路只有一条：让它先停下来。']],
  ending:[['姬红绫','“你看见的是他们做过什么，不是他们生来是什么。”她将最后一位药工扶出火场。'],['你','册子记录着残酷的旧试验。你决定如何让它被看见：交给前线共同核查，或先安置证人再公开。']],
  choices:[['inquiry','交三方共同核查'],['witness','先保护营地证人']],
  outcomes:{inquiry:'册子的副本送往三方营地。谁也无法再独占解释，但对峙中的人第一次坐到了同一张案前。',witness:'证人隐去姓名，在安全之处写下证言。姬红绫留了一盏灯，等每一个人把话说完。'}},
 {id:'journey_04',level:9,title:'四 · 雷海问舟',place:'东域 · 雷海旧渡',enemy:'雷海执念',requires:'journey_03',
  desc:'渡劫游历。飞升之前，先回答一个与强弱无关的问题。本章不会替代真正的飞升天劫。',
  opening:[['清玄真人','“渡劫是你的路，不是别人替你证明的功课。”他将一块普通船木交给你，木上留着补过的钉孔。'],['你','渡口船夫修了三十年的船，仍相信明年会有平静的海。他问你成仙后，还记不记得凡人的渡口。'],['雷海执念','雷云借你的影子成形，反复问着同一句话：“若救一人会误你飞升，你还停不停舟？”']],
  ending:[['你','雷影消散。没有人告诉你哪一句答案才对，真正的飞升之门仍要以渡劫圆满与天劫胜利开启。'],['清玄真人','“别把今日的话当作功德。”他看向海面，“等你有能力做的时候，再记得它。”']],
  choices:[['return','留下归来之约'],['ferry','立下守渡之约']],
  outcomes:{return:'你把船木带在身边，约定每次远行后都来看一眼渡口。成仙不是忘记来路的理由。',ferry:'你托人修好渡船，留下救急的办法。船夫笑道：“比起等仙人显灵，这个踏实。”'}},
 {id:'journey_05',level:11,title:'五 · 云阙无名册',place:'仙域 · 云阙下城',enemy:'封册灵卫',requires:'main_17',
  desc:'天仙游历。仙阙的战功册上，许多名字被写成了“无名”。',
  opening:[['仙阙录事','录事将厚册合上：“无军籍者不记功。这是旧例。”你看见页缝里夹着一封退回的家书。'],['你','城下修补云堤的人大多来自人族，他们抵过魔潮，却没有资格在册上留下姓名。'],['云堤匠人','“不求赏。”匠人把缺了一角的工牌交给你，“我们只想后人知道，这堤是谁修的。”封册灵卫已封锁档案台。']],
  ending:[['仙阙录事','灵卫退下，录事沉默着打开空白页。他问你，要按战功补录，还是将所有守堤者一并录入。'],['你','你想起凡间一盏等待归人的灯。名册不能使逝者复生，却能让后来者知道曾有人站在这里。']],
  choices:[['deeds','核实事迹逐人补录'],['names','先录姓名再补事迹']],
  outcomes:{deeds:'你与录事访遍守堤者，逐一核对。第一页末写着：未核实者继续查访，不再抹去。',names:'空白页先写上姓名。事迹暂缺的地方留着空格，等待家人、同伴和后来者慢慢补全。'}},
 {id:'journey_06',level:12,title:'六 · 碎星停战书',place:'西域 · 碎星前线',enemy:'噬阵星兽',requires:'journey_05',
  desc:'金仙游历。三方都需要一夜休战，但谁也不愿第一个熄灭阵旗。',
  opening:[['前线传令使','三方阵旗同时失去灵光。星兽在地下吞噬阵基，继续交战会把整片营地拖进裂隙。'],['姬红绫','“我能约束这边一夜。你说服另两边。”她没有许诺永久太平，只先保证今夜伤员能走。'],['你','暂时的停战书还没写完，噬阵星兽已破土而出。你必须守住唯一的撤离口。']],
  ending:[['前线传令使','伤员都越过了撤离线。一位仙族将领第一次接过魔族药工送来的绷带，没有追问出处。'],['你','停战将于天明结束。你可以留下共同救伤的通道，也可以先约定今后交换失踪者名册。']],
  choices:[['healers','保留共同救伤通道'],['missing','交换失踪者名册']],
  outcomes:{healers:'营地间升起一面无宗徽的白旗。战事没有结束，但旗下一小段路约定不再伏击救伤者。',missing:'三份名册被抄成九份，各方各留一套。传令使第一次带着找人的消息，而不是新的伤亡数。'}},
 {id:'journey_07',level:13,title:'七 · 太乙照心台',place:'仙域 · 照心台',enemy:'照心旧影',requires:'journey_06',
  desc:'太乙金仙游历。照心台不问你赢过谁，只问你是否肯直视自己的选择。',
  opening:[['照心台守者','“这里没有更强的功法。”守者指向台中清水，“只有你不肯再看的事。”'],['你','水中浮现雪驿、石桥、灰营与云堤。你救过人，也有来不及伸手的时候。'],['照心旧影','影子握着与你相同的剑：“承认救不了所有人，和从此不救任何人，是两回事。”']],
  ending:[['你','旧影退入水中。台上没有胜者的赞声，只有你自己的呼吸。那些选择都还在，并不因境界增长而消失。'],['照心台守者','“把悔意写下来也好，带着往前走也好。别把它交给下一次迁怒。”']],
  choices:[['record','记下未尽之事'],['teach','将经历讲给后辈']],
  outcomes:{record:'你写下那些未能做到的事，只写事实，不为自己辩解。这页文字留在行囊最里层。',teach:'后辈听见的故事没有百战百胜。你告诉他们如何求援、如何退让，以及什么时候必须站出来。'}},
 {id:'journey_08',level:14,title:'八 · 大罗共归途',place:'三界交界 · 旧关',enemy:'裂界残响',requires:'journey_07',
  desc:'大罗金仙游历。夜无疆立在旧关尽头。你们都能毁掉这座关，却第一次选择先修好它。',
  opening:[['夜无疆','“三万年，换了无数旗号，这道裂口还在。”他的气息随你的成长愈加强盛，却仍被半圣本源的裂痕束缚。'],['你','你们没有结盟，也没有拔剑。关下的归人正穿过残阵，裂界残响已追上最后一队车马。'],['夜无疆','“我封上方，你守归路。之后的账，之后再算。”他说完，转身踏入风中。']],
  ending:[['夜无疆','“我的路止于半圣，你的未必。”他看了看重新亮起的关灯，“别到那时，只记得自己有多强。”'],['你','车队已经离开。你可以把这次默契写进公开纪事，也可以只在私人行记里留下他的名字。']],
  choices:[['public','如实记入三界纪事'],['private','留在私人行记']],
  outcomes:{public:'纪事写明了各方所做的事，没有把敌人写成朋友，也没有抹去他曾出手护住归路的事实。',private:'你的行记留下一句：旧关有灯，同行一程。下次相逢仍可能交手，但这一次不会被遗忘。'}}
];
for(const j of JOURNEYS_V2838){
 const task={id:j.id,type:'journey',title:j.title,desc:j.desc,unlockRealm:j.level,unlockCondition:{questCompleted:[j.requires]},repeatable:false,
  steps:[{text:'听取来意 · '+j.place,action:j.id+'_open'},{text:'击败'+j.enemy,action:'journey_battle_v2838'},{text:'战后相谈',action:j.id+'_end'},{text:'决定此行的约定',action:'choice',options:j.choices}],
  rewards:{gold:800+j.level*180,exp:180+j.level*45,items:['大还丹','聚灵丹']}};
 SIDE_TASKS.push(task);ALL_TASKS[task.id]=task;
}
const SCENES_V2838={
 walk_to_sect:[['清玄真人','“上了这阶，不代表从此便高人一等。”他在山门前停下，等你把气喘匀。'],['你','云海在脚下翻涌。你看见扫阶弟子袖口磨出的毛边，也看见远处一盏未熄的夜灯。'],['清玄真人','“路很长。先学会自己走，再谈走到哪里。”古钟响起，你迈过凌霄山门。']],
 talk_suwanqing:[['苏晚晴','“好久不见。没想到，你也走上了仙途。”她先叫出你的名字，随后才低下眼。'],['你','石桥的风把许多旧话吹到唇边。你却只问：“这些年，还好吗？”'],['苏晚晴','“有时好，有时不好。”她没有再用一句平安带过。钟声催人离开，你们约好下次慢慢说。']],
 listen_confession:[['苏晚晴','“当年我怕留下，就再也走不了了。可我走了以后，才知道有些事不是离开就能变轻。”'],['你','旧木牌放在你们之间。雨水沿屋檐落下，你听她说完，没有替她辩解，也没有立刻替自己决定。'],['苏晚晴','“我不是要你现在原谅。只是这一次，我想把话说清楚。”你终于可以按自己的心意回应。']],
 war_archive_v2823:[['前线录事','“三万年。”他将断裂的书脊压平，“一册写不下，所以只能分代重抄。”'],['清玄真人','仙族底蕴深厚，却一直无法彻底压住魔族的超级天才夜无疆。如今他自斩重修，旧日的代价仍留在本源里。'],['你','卷末没有凯歌，只有补给与失踪名册。你收起卷宗，决定先守住眼前这条灵脉。']],
 saint_limit_v2823:[['夜无疆','“别等我替你走完最后一步。”他的气息已抵半圣极处，本源裂痕却像一扇永远无法开启的门。'],['你','他仍会随你成长，直至准圣圆满；这道天堑不会因你的境界变化而凭空消失。'],['夜无疆','“赢过我，只能证明你赢了。走过我走不到的地方，才算你的答案。”']]
};
function journeyIntroductionV2838(){
 const esc=discipleEscV2815;
 return `<section class="main-overview-v2822"><h3>三界游历 · 八章</h3><p>炼虚至渡劫、天仙至大罗金仙逐章开放。游历为可选篇章，不替代主线与飞升。战斗失败保留已读步骤，可补给后重试；章节奖励仅发一次。</p><details><summary>查看开放条件</summary>${JOURNEYS_V2838.map(j=>`<p>${esc(j.title)}：${esc(CULTIVATION_REALMS[j.level].name)}初期，完成「${esc(getTaskData(j.requires)?.title||j.requires)}」</p>`).join('')}</details></section>`;
}
function scenePagesV2838(id,action){
 const j=JOURNEYS_V2838.find(x=>x.id===id);
 if(j){if(action===id+'_open')return j.opening;if(action===id+'_end')return j.ending;
  if(action==='choice'){const pick=player.tasks?.choices?.[id];return [['此行约定',j.outcomes[pick]||'尚未做出选择。']];}}
 if(SCENES_V2838[action])return SCENES_V2838[action];
 const [title,body]=getTaskNarrative(action);return [[title,body]];
}
let sceneSessionV2838=null;
function closeSceneV2838(returnToTasks=false){
 const s=sceneSessionV2838;sceneSessionV2838=null;document.getElementById('sceneV2838')?.remove();
 FLAT_WORLD.keys={};
 if(s?.opener?.isConnected)s.opener.focus?.();
 if(returnToTasks&&s?.owner===player&&gameState==='exploring')showTaskPanel(s.replay?'journal':getTaskData(s.id)?.type||'main');
}
function validSceneV2838(s){
 if(!s||s!==sceneSessionV2838||s.owner!==player||gameState!=='exploring'||player.breakthrough?.isAnimating)return false;
 if(s.replay)return canReplaySceneV2838(s.id,s.action);
 const i=getTaskInstance(s.id);return i===s.instance&&!i.completed&&!i.failed&&i.currentStep===s.step&&getCurrentTaskStep(s.id)?.action===s.action;
}
function openTaskSceneV2838(id,action=null,replay=false){
 if(!taskInteractionAllowedV2822())return;
 const i=getTaskInstance(id),step=getCurrentTaskStep(id),task=getTaskData(id);if(!task)return;
 if(!replay){if(!i||i.completed||i.failed||!step||!isNarrativeActionV2838(id,step.action))return;action=step.action;}
 else if(!canReplaySceneV2838(id,action))return;
 const opener=document.activeElement;closeSceneV2838();closeTaskPanel();stopNavigationV2830();FLAT_WORLD.keys={};FLAT_WORLD.target=null;
 sceneSessionV2838={owner:player,id,action,instance:i,step:i?.currentStep||0,replay,page:0,pages:scenePagesV2838(id,action),opener};
 const el=document.createElement('div');el.id='sceneV2838';el.className='journey-overlay-v2838';el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-labelledby','sceneTitleV2838');
 el.innerHTML='<section class="scene-card-v2838"><header><div><small id="sceneChapterV2838"></small><h2 id="sceneTitleV2838"></h2></div><button type="button" data-scene="close" aria-label="暂时收起剧情">×</button></header><div class="scene-landscape-v2838" aria-hidden="true"></div><div class="scene-reading-v2838"><span id="sceneSpeakerV2838"></span><p id="sceneTextV2838"></p></div><footer><small id="scenePageV2838" aria-live="polite"></small><div><button type="button" data-scene="prev">上一页</button><button type="button" class="primary-v2838" data-scene="next">下一页</button></div></footer></section>';
 el.onclick=e=>{const a=e.target.closest('[data-scene]')?.dataset.scene;if(a==='close')closeSceneV2838(true);if(a==='prev')advanceSceneV2838(-1);if(a==='next')advanceSceneV2838(1);};
 el.onkeydown=e=>{e.stopPropagation();if(e.key==='Escape'){e.preventDefault();closeSceneV2838(true);}else trapJourneyFocusV2838(e,el);};
 document.body.appendChild(el);renderSceneV2838();el.querySelector('[data-scene="next"]')?.focus();
}
function trapJourneyFocusV2838(e,el){
 if(e.key!=='Tab')return;const buttons=[...el.querySelectorAll('button:not([disabled])')];if(!buttons.length)return;
 const first=buttons[0],last=buttons[buttons.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
}
function renderSceneV2838(){
 const s=sceneSessionV2838;if(!validSceneV2838(s)){closeSceneV2838();return;}
 const el=document.getElementById('sceneV2838');if(!el)return;const [speaker,text]=s.pages[s.page];
 document.getElementById('sceneChapterV2838').textContent=s.replay?'修行纪事 · 回看不发放奖励':'仙途 · '+(getTaskData(s.id)?.type==='journey'?'三界游历':'剧情');
 document.getElementById('sceneTitleV2838').textContent=getTaskData(s.id).title;
 document.getElementById('sceneSpeakerV2838').textContent=speaker;document.getElementById('sceneTextV2838').textContent=text;
 document.getElementById('scenePageV2838').textContent=`${s.page+1} / ${s.pages.length} · ${s.replay?'已发生的故事':'读完确认后推进'}`;
 const prev=el.querySelector('[data-scene="prev"]'),next=el.querySelector('[data-scene="next"]');prev.disabled=s.page===0;
 next.textContent=s.page<s.pages.length-1?'下一页':s.replay?'回到纪事':'读完 · 确认继续';
 el.querySelector('.scene-reading-v2838')?.scrollTo?.(0,0);
}
function advanceSceneV2838(direction){
 const s=sceneSessionV2838;if(!validSceneV2838(s)){closeSceneV2838();return;}
 if(direction<0){s.page=Math.max(0,s.page-1);renderSceneV2838();return;}
 if(s.page<s.pages.length-1){s.page++;renderSceneV2838();return;}
 if(s.replay){closeSceneV2838(true);return;}
 // Clear the session before committing: double taps cannot complete another step.
 closeSceneV2838();
 if(completeTaskStep(s.id,s.action)){rememberSceneV2838(s.id,s.action);autoSave();showTaskPanel(getTaskData(s.id)?.type||'main');}
}
function rememberSceneV2838(id,action){
 const key=id+':'+action;const entries=Array.isArray(player.journalV2838)?player.journalV2838.filter(x=>x&&typeof x.id==='string'&&typeof x.action==='string'&&x.id+':'+x.action!==key):[];
 entries.push({id,action,day:Math.max(0,player.worldTime?.totalDays||0)});player.journalV2838=entries.slice(-160);
}
function canReplaySceneV2838(id,action){
 const task=getTaskData(id),i=getTaskInstance(id),n=task?.steps.findIndex(x=>x.action===action);if(n==null||n<0)return false;
 const passed=i?.completed||player.tasks.completed.includes(id)||(i&&n<i.currentStep);if(!passed)return false;
 return action==='choice'?!!JOURNEYS_V2838.find(j=>j.id===id)&&!!player.tasks.choices[id]:isNarrativeActionV2838(id,action);
}
function isNarrativeActionV2838(id,action){
 if(['learn_high_skill','breakthrough_realm','cultivate_to_full','choice','collect_materials','journey_battle_v2838'].includes(action))return false;
 return !!SCENES_V2838[action]||action===id+'_open'||action===id+'_end'||getTaskNarrative(action)[0]!=='📜 任务推进';
}
function journalEntriesV2838(){
 ensureTaskState();const out=[],seen=new Set();
 const push=e=>{const key=e.id+':'+e.action;if(!seen.has(key)&&canReplaySceneV2838(e.id,e.action)){seen.add(key);out.push(e);}};
 (Array.isArray(player.journalV2838)?player.journalV2838:[]).slice().reverse().forEach(e=>{if(e&&typeof e.id==='string'&&typeof e.action==='string')push(e);});
 // Earlier saves may predate the journal; derive read-only recaps from completed steps.
 Object.values(ALL_TASKS).slice().reverse().forEach(t=>t.steps.slice().reverse().forEach(st=>push({id:t.id,action:st.action})));
 return out;
}
function renderJournalV2838(container){
 const esc=discipleEscV2815,entries=journalEntriesV2838();
 container.innerHTML='<section class="main-overview-v2822"><h3>修行纪事</h3><p>只显示已读或旧存档已完成的剧情。回看不会改变分支，也不会再发奖励。</p></section>'+ (entries.length?entries.map(e=>{
  const task=getTaskData(e.id),step=task.steps.find(s=>s.action===e.action);
  return `<article class="task-card"><strong>${esc(task.title)}</strong><p>${esc(step.text)}${e.day!=null?' · 第 '+Math.floor(e.day)+' 日':''}</p><button class="task-action" onclick="openTaskSceneV2838('${e.id}','${e.action}',true)">回看此段</button></article>`;
 }).join(''):'<p class="task-empty">读完第一段剧情后，它会留在这里。</p>');
}
const choiceBeforeV2838=onChoiceMade;
onChoiceMade=function(id,option){
 const j=JOURNEYS_V2838.find(x=>x.id===id),i=getTaskInstance(id),valid=j&&i&&!i.completed&&getCurrentTaskStep(id)?.action==='choice'&&j.choices.some(c=>c[0]===option);
 const result=choiceBeforeV2838.apply(this,arguments);
 if(valid&&i.completed&&player.tasks.choices[id]===option){rememberSceneV2838(id,'choice');autoSave();openTaskSceneV2838(id,'choice',true);}
 return result;
};
function journeyEnemyV2838(j){
 const lv=j.level,hp=300+lv*60;return balanceEnemyV2802({name:j.enemy,hp,maxHp:hp,atk:25+lv*7,def:10+lv*4,gold:80+lv*20,exp:80+lv*25,_realmLevel:lv,_realmPhase:0,_taskId:j.id,_taskAction:'journey_battle_v2838',_isTaskBattle:true});
}
function launchJourneyBattleV2838(id){
 const j=JOURNEYS_V2838.find(x=>x.id===id),i=getTaskInstance(id);if(!j||!i||i.completed||i.failed||getCurrentTaskStep(id)?.action!=='journey_battle_v2838'||!taskInteractionAllowedV2822())return;
 document.getElementById('journeyPrepareV2838')?.remove();closeTaskPanel();stopNavigationV2830();FLAT_WORLD.keys={};FLAT_WORLD.target=null;
 const enemy=journeyEnemyV2838(j),owner=player,step=i.currentStep,el=document.createElement('div');el.id='journeyPrepareV2838';el.className='journey-overlay-v2838';el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-labelledby','journeyEnemyV2838');const esc=discipleEscV2815;
 el.innerHTML=`<section class="journey-prepare-v2838"><small>${esc(j.place)}</small><h2 id="journeyEnemyV2838">${esc(j.enemy)}</h2><p>${esc(weaknessTextV286821(enemy))}</p><p>${esc(CULTIVATION_REALMS[j.level].name)}初期 · 气血 ${enemy.maxHp} · 攻击 ${enemy.atk} · 防御 ${enemy.def}</p><p><b>${enemyRiskV286817(enemy).label}</b> · 仅按境界与精英标记评估；装备、招式和剩余气血仍影响胜负。</p><div class="journey-vitals-v2838"><span>气血 <b>${Math.floor(player.hp)} / ${getMaxHp()}</b></span><span>灵力 <b>${Math.floor(player.mp)} / ${getMaxMp()}</b></span></div><p>挑战前请检查装备、已装配招式与丹药。获胜推进本章，失败扣除身上灵石的20%，已读剧情保留。</p><button type="button" data-journey="fight" class="primary-v2838" ${player.hp<=1?'disabled':''}>准备好了 · 开始挑战</button><button type="button" data-journey="back">先补给 · 返回任务</button></section>`;
 el.onclick=e=>{const act=e.target.closest('[data-journey]')?.dataset.journey;if(!act)return;if(owner!==player){el.remove();return;}if(act==='back'){el.remove();showTaskPanel('journey');return;}
  if(act==='fight'&&i===getTaskInstance(id)&&i.currentStep===step&&!i.completed&&!i.failed&&taskInteractionAllowedV2822()&&player.hp>1){el.remove();startCombat(enemy,false,false,null);}};
 el.onkeydown=e=>{e.stopPropagation();if(e.key==='Escape'){el.remove();if(owner===player)showTaskPanel('journey');}else trapJourneyFocusV2838(e,el);};document.body.appendChild(el);el.querySelector('[data-journey="back"]')?.focus();
}
// Compact battle receipt; rewards have already been settled by the core.
let lastBattleV2838=null;
function recordBattleSummaryV2838(enemy,before){
 if(enemy.tournamentFight){lastBattleV2838=null;return;}
 lastBattleV2838={owner:player,name:enemy.name,gold:Math.max(0,player.gold-before.gold),exp:Math.max(0,player.exp-before.exp),taskType:getTaskData(enemy._taskId)?.type||'main'};
}
function showAfterBattleV2838(owner){
 const r=lastBattleV2838;lastBattleV2838=null;if(!r||r.owner!==owner||player!==owner||gameState!=='exploring')return;
 document.getElementById('afterBattleV2838')?.remove();const el=document.createElement('aside');el.id='afterBattleV2838';el.className='after-battle-v2838';el.setAttribute('aria-label','战后简报');const esc=discipleEscV2815;
 el.innerHTML=`<div><strong>战胜 · ${esc(r.name)}</strong><button type="button" data-after="close" aria-label="收起战后简报">×</button></div><p>灵石 +${r.gold}　修为 +${r.exp}<small>含本战触发的任务奖励</small></p><p>气血 ${Math.floor(player.hp)}/${getMaxHp()} · 灵力 ${Math.floor(player.mp)}/${getMaxMp()}</p><div><button type="button" data-after="tasks">继续任务</button><button type="button" data-after="rest">寻找补给</button></div>`;
 el.onclick=e=>{const act=e.target.closest('[data-after]')?.dataset.after;if(!act)return;el.remove();if(player!==owner||gameState!=='exploring'||player.breakthrough?.isAnimating)return;if(act==='tasks')showTaskPanel(r.taskType);if(act==='rest'){showScrollMapV2831();nearestScrollRestV2837();}};document.body.appendChild(el);
}
// New-game checkpoint is independent of the rolling autosave backup.
const PREVIOUS_SAVE_V2838='xiantu_save_previous_character';
function saveChangeAllowedV2838(){return gameState!=='combat'&&gameState!=='combat-ending'&&!player?.breakthrough?.isAnimating;}
function prepareNewGameV2838(){
 if(!saveChangeAllowedV2838()){alert('请先结束战斗或突破，再重新入世。');return false;}
 try{
  const live=!document.getElementById('gameScreen')?.classList.contains('hidden')&&gameState!=='start';
  let raw=live&&!player.testAccount999?JSON.stringify(createSaveDataV2768()):(localStorage.getItem(SAVE_KEY)||localStorage.getItem(SAVE_BACKUP_KEY));
  try{if(raw)parseSaveV2768(raw);}catch(_){raw=localStorage.getItem(SAVE_BACKUP_KEY);if(raw)parseSaveV2768(raw);}
  if(!raw)return true;
  if(!confirm('重新入世将创建新角色。当前有效角色会保留在“存档管理 → 上一位角色”，该位置只保留最近一位。是否继续？'))return false;
  localStorage.setItem(PREVIOUS_SAVE_V2838,raw);return true;
 }catch(e){alert('未开启新角色：旧记录无法保全，请先导出存档。'+e.message);return false;}
}
function restorePreviousV2838(){
 if(!saveChangeAllowedV2838()){alert('请先结束战斗或突破。');return;}
 try{const raw=localStorage.getItem(PREVIOUS_SAVE_V2838);if(!raw)throw Error('尚无上一位角色');const data=parseSaveV2768(raw);
  if(!confirm(`恢复上一位角色「${data.player.name||'无名'}」？当前主档将成为滚动备份。`))return;
  writeSaveV2768(raw);document.getElementById('saveManagerV2768')?.remove();loadAndStart();
 }catch(e){alert('未恢复：'+e.message);}
}
function exportPreviousV2838(){
 try{const raw=localStorage.getItem(PREVIOUS_SAVE_V2838);if(!raw)throw Error('尚无上一位角色');parseSaveV2768(raw);
  const url=URL.createObjectURL(new Blob([raw],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='xiantu-previous-character.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
 }catch(e){alert('导出失败：'+e.message);}
}
window.__xiantuBuildFilesV2814=window.__xiantuBuildFilesV2814||{};window.__xiantuBuildFilesV2814['xiantu-v2838-journey.js']='28.68.22';

// Small non-combat encounters, two per region and character. Persist choice and reward together.
const ROAMING_KINDS_V286818=['traveler','ruins'];
let roamingContextV286818=null;
function normalizeRoamingV286818(raw){
 const out={maps:{}};
 for(const region of Object.keys(WORLD_MAP_CONFIGS)){
  const old=raw?.maps?.[region];if(!old||typeof old!=='object')continue;
  const resolved={};for(const kind of ROAMING_KINDS_V286818)if(['aid','guide','channel','copy','leave'].includes(old.resolved?.[kind]))resolved[kind]=old.resolved[kind];
  out.maps[region]={seen:Array.isArray(old.seen)?[...new Set(old.seen.filter(x=>typeof x==='string'&&/^\d{1,4},\d{1,4}$/.test(x)))].slice(-256):[],steps:Math.max(0,Math.min(999,Math.floor(Number(old.steps)||0))),pending:ROAMING_KINDS_V286818.includes(old.pending)&&!resolved[old.pending]?old.pending:null,resolved};
 }
 return out;
}
function roamingStateV286818(){
 const all=player.roamingV286818 ||= {maps:{}};all.maps ||= {};
 return all.maps[currentRegion||'south'] ||= {seen:[],steps:0,pending:null,resolved:{}};
}
function roamingAllowedV286818(){return gameState==='exploring'&&!player.breakthrough?.isAnimating&&!COMBAT_FINISH_V2764.settling;}
function discoverRoamingV286818(cell){
 if(!roamingAllowedV286818()||isWorldOverlayOpen()||autoNavigationV2830)return;
 const intro=typeof firstJourneyV28687==='function'?firstJourneyV28687():null;
 if(intro&&!intro.paused&&intro.step<4)return;
 const state=roamingStateV286818();if(state.pending||state.seen.includes(cell)||Object.keys(state.resolved).length>=2)return;
 state.seen.push(cell);if(state.seen.length>256)state.seen.shift();state.steps=Math.min(999,state.steps+1);
 let hash=17;for(const ch of (currentRegion||'south')+':'+cell)hash=(Math.imul(hash,31)+ch.charCodeAt(0))>>>0;
 if(state.steps<12||hash%17!==0)return;
 state.pending=ROAMING_KINDS_V286818.find(k=>!state.resolved[k]);state.steps=0;
 if(!saveGame()){state.pending=null;return;}
 stopNavigationV2830();FLAT_WORLD.keys={};FLAT_WORLD.target=null;FLAT_WORLD.moving=false;
 openRoamingV286818();
}
function roamingNoticeV286818(){
 const state=roamingStateV286818();return state.pending?'<p>途中有一段未了机缘。</p><button class="choice-btn" onclick="openRoamingV286818()">继续奇遇 · '+(state.pending==='traveler'?'受伤行者':'残阵遗迹')+'</button>':'';
}
function openRoamingV286818(){
 if(!roamingAllowedV286818())return;const state=roamingStateV286818(),kind=state.pending;if(!kind)return;
 roamingContextV286818={owner:player,region:currentRegion||'south',kind};
 const aid=(player.materials?.['灵草']||0)>=2,channel=player.mp>=20;
 let body=kind==='traveler'?`<h3 id="roamingTitleV286818">山道奇遇 · 受伤行者</h3><p>松根下，一位散修捂着伤腿。他愿以珍藏的神行符，换取两株灵草疗伤；若你不便施药，也可以替他辨认通往灵泉的道路。</p><button class="choice-btn" onclick="resolveRoamingV286818('aid')" ${aid?'':'disabled'}>施药相助 · 灵草−2，神行符+1</button><button class="choice-btn" onclick="resolveRoamingV286818('guide')">指路护送 · 获赠30灵石</button>`:`<h3 id="roamingTitleV286818">山道奇遇 · 残阵遗迹</h3><p>古修石门只余半幅阵纹。你可以注入灵力打开侧匣，也可以放弃启阵，采下石缝间的灵草。</p><button class="choice-btn" onclick="resolveRoamingV286818('channel')" ${channel?'':'disabled'}>注灵启匣 · 灵力−20，灵石+80、神行符+1</button><button class="choice-btn" onclick="resolveRoamingV286818('copy')">采草离去 · 灵草+3</button>`;
 body+='<p>各地区每种奇遇每位角色仅处理一次。可以稍后从探索手册继续；刷新不会重置选择。</p><button class="choice-btn" onclick="resolveRoamingV286818(\'leave\')">不作停留 · 放弃本次机缘</button>';
 showStory('<section class="main-overview-v2822">'+body+'</section>',[{text:'稍后再来 · 返回地图',action:'return_to_map'}]);
}
function resolveRoamingV286818(choice){
 const context=roamingContextV286818;
 if(!roamingAllowedV286818()||!context||context.owner!==player||context.region!==(currentRegion||'south')||!document.getElementById('roamingTitleV286818')||document.getElementById('storyPanel')?.classList.contains('hidden'))return false;
 const state=roamingStateV286818(),kind=state.pending;
 if(!kind||kind!==context.kind||state.resolved[kind]||!(kind==='traveler'?['aid','guide','leave']:['channel','copy','leave']).includes(choice))return false;
 if(choice==='aid'&&(player.materials?.['灵草']||0)<2||choice==='channel'&&player.mp<20)return false;
 const before={gold:player.gold,mp:player.mp,inventory:player.inventory,materials:player.materials,roaming:player.roamingV286818};
 const next={...state,pending:null,resolved:{...state.resolved,[kind]:choice}};
 player.roamingV286818={maps:{...player.roamingV286818.maps,[context.region]:next}};
 player.inventory=[...(player.inventory||[])];player.materials={...(player.materials||{})};
 if(choice==='aid'){player.materials['灵草']-=2;player.inventory.push('神行符');}
 if(choice==='guide')player.gold+=30;
 if(choice==='channel'){player.mp-=20;player.gold+=80;player.inventory.push('神行符');}
 if(choice==='copy')player.materials['灵草']=(player.materials['灵草']||0)+3;
 if(!saveGame()){
  player.gold=before.gold;player.mp=before.mp;player.inventory=before.inventory;player.materials=before.materials;player.roamingV286818=before.roaming;
  showFloatingText?.('未能保存，未扣除资源或领取奖励。请恢复存储后重试。','#ffd76a');return false;
 }
 roamingContextV286818=null;updateStats();
 showStory('<h3>机缘已记入行囊</h3><p>'+({aid:'你为行者敷好灵草，收下了一张神行符。',guide:'行者谢过你的指点，赠你30灵石。',channel:'残阵归于寂静，侧匣中留下80灵石和一张神行符。',copy:'你采下三株灵草，沿着旧道继续前行。',leave:'你收回目光，继续自己的修行路。'}[choice])+'</p>',[{text:'返回地图',action:'return_to_map'}]);return true;
}

// 雨夜命牌案：独立章节进度，不重置旧主线、情缘或物品。
const RAIN_TITLES_V286822=['雨夜来信','没有靠岸的渡船','河灯与脚印','先救谁，先追谁','渡口伏击','留下来的名字','苏晚晴的来意','库房旧账','秘境潮门','守册傀儡','宗门问证','把真相交给谁','另一封没有署名的信','雨夜命牌案 · 卷一完'];
const RAIN_CLUES_V286822={rope:['断绳','船绳朝岸的一侧被齐整割断，船没有被洪水冲走。割口沾着药箱封蜡。'],lamp:['河灯','灯芯还温着。灯底写着“沈禾，药工”，名字下面被盖了一个“亡”字，而岸上传来同名少年的呼救。'],print:['泥印','驮箱的车轮很深，回程却很浅。靴底的三角铜钉只在宗门库房役卒的鞋上见过。'],ledger:['库账','出库的是安魂药，入账却写“无主命牌”。同一批号的二十七块命牌，死亡日期竟完全相同。'],seal:['旧印','凌霄宗的云纹印是真的，但印泥比来信上的新。有人借正规运送的药箱夹带命牌。'],witness:['证词','守夜人记得一句交代：“不用死人，只要没人回来认领。”失踪者有可能还活着。']};
let rainViewV286822=null,rainSeqV286822=0;
const rainFightsV286822=new WeakMap();
function rainStateV286822(){
 const r=player.rainChapterV286822||{};
 return {step:Math.max(0,Math.min(13,Math.floor(Number(r.step)||0))),clues:Array.isArray(r.clues)?[...new Set(r.clues.filter(k=>Object.hasOwn(RAIN_CLUES_V286822,k)))]:[],
 route:['rescue','chase'].includes(r.route)?r.route:'',trust:['share','reserve'].includes(r.trust)?r.trust:'',policy:['public','protect','trace'].includes(r.policy)?r.policy:'',
 puzzle:!!r.puzzle,rested:Array.isArray(r.rested)?r.rested.filter(n=>n===4||n===9):[],rewarded:!!r.rewarded};
}
function rainUnlockedV286822(){return !!player.rainChapterV286822||player.level>=2||(firstJourneyV28687()?.step||0)>=4;}
function rainSummaryV286822(){const s=rainStateV286822();return s.step>=13?`${s.route==='rescue'?'沈禾活着回来作证':'运输暗号已查明'}；${({public:'名册已交三方公开核查',protect:'证人已安置在药庐',trace:'库房仍由专人监视'})[s.policy]||'旧案留待查明'}。`:s.step?`雨夜命牌案：${RAIN_TITLES_V286822[s.step]}。`:'渡口来信尚待查证。';}
function rainCardV286822(){return `<article class="task-card"><strong>雨夜命牌案 · 剧情扩展</strong><p>${rainUnlockedV286822()?escapeGameText(rainSummaryV286822()):'完成山道教学、发现来信后开启；筑基及以上旧存档可直接补记。'}</p><button class="task-action" onclick="showRainChapterV286822()" ${rainUnlockedV286822()?'':'disabled'}>${rainStateV286822().step>=13?'回看旧案':'追查来信'}</button></article>`;}
function rainNarrativeV286822(step,s){
 const rescue=s.route==='rescue',share=s.trust==='share';
 const pages=[
 ['雨把信纸洇透，你只辨出一句：“今夜，不要让药师上山。”云纹封蜡下还有一行针尖般的小字：他们正在收购失踪修士的命牌。','你把信朝灯移近。纸背是一个名单，你的名字在第三行，旁边写着“已亡”。署名处压着旧木牌的半边印记——当年苏晚晴离开青石桥时，也带走了这样一块木牌。','远处渡口的钟响了两次，第三声迟迟没有来。送药的船本应此时靠岸。你决定先去看看，而不是把这封信当作某个人的玩笑。'],
 ['青云渡口只剩一盏倾斜的灯。空船撞着桥墩，渡工说药师没有上山，反倒在傍晚被宗门的人请去了库房。','岸边有割断的船绳、一盏漂回来的河灯和两道不同方向的车辙。逐一查看，也许能分清这是劫财，还是有人故意把船上的人藏起来。','【调查】至少查看两处痕迹才能判断去向。证据不会因为选择另一条路永久消失。'],
 ['桥下有人敲击船板。一名少年卡在翻覆的药船里，水位正在上涨。与此同时，提灯的黑衣人正带着一只小匣离开。','渡工只有一条小艇，来不及同时追人和救人。他问你：“仙师，你先往哪边？”你看见河灯上的姓名，第一次意识到名单背后不是数字。','【选择后果】先救人：黑衣人暂时逃走，留下证人和援助。先追踪：渡工会带人救少年，你掌握运输暗号，但少年暂时无法作证。两路均可继续、补查证据，不扣好感。'],
 rescue?['你把剑横在船板间，叫少年跟着你的呼吸数数。他咳出第一口水时，仍紧攥一只碎药瓶：“里面有人活着，别把药倒掉。”','少年叫沈禾，是药庐帮工。他说药师被带走前把解毒粉分给了被关的人；所谓安魂药，其实会让命牌短暂失去感应。','“我的河灯写着我死了？”他摸着尚温的手腕，忽然不再哭了，“那我就活着去认自己的名字。”渡工将备用药包交给你，愿在伏击时掩护你。']:['你沿车辙追到旧仓，听见黑衣人敲门：两短一长。门里问“几盏灯”，他答“二十七盏，留三盏不灭”。','你没有立刻拔剑。小匣里不是灵石，而是一摞写着姓名的薄木片。黑衣人把其中一片翻过来，露出与你来信相同的印记。','渡工随后赶来报信：少年已经救起，正在药庐昏睡。你把暗号记牢，沿运货侧门布下绊索；这一趟没有证词，却有一条能继续往上查的线。'],
 ['库房役卒堵住渡口，拿出的不是通缉令，而是一张写着“意外落水”的验尸单。上面的名字甚至还没干。','“活人回去，账就对不上了。”领头人话音未落，河灯被一脚踢灭。你要守住药船，也要让这张纸留下来。',rescue?'【援助】渡工会在开战时提供15%最大气血的护盾，持续敌方两次行动。':'【先手布置】运输侧门的绊索令伏击者攻击降低20%。','可在本场出战前接受一次药包调息，补满气血与灵力。失败后章节停留在这里，可整备重试。'],
 ['你从役卒袖中取出库房借印单，借印者那一栏被刀刮过。真印可以借，人的生死却不该这样借来记账。',rescue?'沈禾把验尸单摊在灯下，照着自己的名字一笔一笔地读。他不是为了证明你做对了，而是要回药庐找到还没回来的师父。':'药庐回信说沈禾已脱险，只是仍不能开口。你把听见的暗号交给渡工，让他守住来往药箱，不再冒险单独追人。','你可以回头补查渡口遗留痕迹。另一条路上的人和证据没有凭空消失；你只是先后做了不同的事。'],
 ['苏晚晴在库房门前等你。她先看了看你手上的伤，再看那封信：“你也收到了？”她拿出另一封，名单里写着她失踪师姐的名字。','“木牌印是我留下的。”她没有躲开你的目光，“我想让你别上山，也怕你真的不来。”这不是道歉，更不是复合。你们先要决定，能不能把眼前的事情交给彼此。','【选择后果】坦白交出原信，她会主动讲出师姐留下的解阵口诀；暂留底牌，她保留疑虑，但后续仍可在库房找到同一线索，不锁死剧情。'],
 ['库房的门没有锁，值夜的录事却坚持每一只药箱都要盖章才准带走。他一遍遍说手续齐全，手指却停在同一个批号上。',share?'苏晚晴把原信压在账边：“先别问是谁有罪，先问谁还活着。”她将师姐的口诀告诉你：归潮认名，不认亡字。':'苏晚晴没有再问你原信的事，只借来一盏灯：“你查账，我查药。等你愿意说时，别让我从别人那里听见。”','【调查】查完库账、旧印和证词，再判断对方究竟在伪造死亡，还是单纯盗卖财物。判断不对可以继续核查，不损失物品。'],
 ['库房账页指向河底一座旧修士遗府。潮门上刻着二十七个姓名，每个名字旁都贴着一枚新写的“亡”字。门并未真的封死，只是有人把活人藏在死人的手续里。',share?'苏晚晴与你并肩站到水线前：“归潮认名，不认亡字。把名字留下。”':'你在账簿夹页找到了残句：“归潮认名，不认亡字。”苏晚晴看过后点头，却没有替你做决定。','【解阵】保留姓名、揭去“亡”签，可削弱守册傀儡的护甲；直接破门也能继续，但须正面面对完整防御。没有永久漏掉的奖励。'],
 ['潮门后不是宝库，而是一间仍在供药的石室。沉睡的修士腕上系着纸牌，药师被锁在药炉旁。他喊：“别砸炉！停药要按次序，否则他们醒不过来。”','守册傀儡将账页展开，挡在炉前。苏晚晴先护住药师，你负责打断傀儡的追击。救人需要手稳，也需要有人在前面站住。',s.puzzle?'【解阵已生效】傀儡防御降低25%。':'【强行破门】傀儡保留完整防御，仍可准备后挑战。','本场有一次战前调息；获胜才推进救援，刷新中断战斗会按现有战斗存档规则恢复。'],
 ['药师把最后一个人唤醒时，天已经亮了。二十七盏河灯只点起二十四盏，另三人的药位是空的。有人在你来之前把他们带走了。','宗门执事接过证物，第一句话却是：“真印外流，此事若传出去，凌霄宗颜面何存？”苏晚晴把名单往前推了一寸：“先把人记回来，再谈颜面。”',rescue?'沈禾站到人群前，报出自己的名字。他的声音仍很轻，却已经不再需要你代他说话。':'你按运输暗号复述了旧仓的交接过程；渡工带来沈禾的手印，补上了暂时不能到场的证词。','证据不足以指认某位长老。你需要决定如何保住调查，而不是选一个看起来最像坏人的人。'],
 ['公开核查会让更多家属知道真相，也会惊动暗中接货的人。保护证人能让他们喘口气，但解释暂时不会传遍山门。继续追踪能保住线索，却需要面对等待中的质疑。','【选择后果】公开：留下三方核查记录；保护：药庐成为证人落脚处；追踪：库房保留监视线。三种结案记录及苏晚晴后续对白不同，奖励相同，不扣好感，也不提前定罪。'],
 ['旧案刚刚封存，你在归途收到另一封信。里面没有命牌，只有一截烧焦的船绳和三个尚未归来的姓名。','夜无疆的字写在纸背：“有人买的是命牌，有人买的是不被追查的名字。你以为找回二十四个人，便已经找到了买家？”','你将信翻过来。第三个名字不是死者，也不是失踪者——那是替你们盖过借印章的录事。苏晚晴看完，把自己的灯递到你身旁：“这次，不要等我在别人那里听见。”','卷一至此结束。命牌案有了结果，真正接货的人仍在远处。完成可领取一次120灵石；回看不会重复领奖。'],
 [rainSummaryV286822(),share?'苏晚晴：“这次你把原信交给了我。下次有事，也别只留一句让我猜的话。”':'苏晚晴：“我会把我查到的事告诉你。至于你的那一半，我等你亲口说。”','你把案卷收好。河灯亮着，山路还长；原先未尽的约定，仍等你亲自赴约。可以回看此行，或继续自己的修行。']
 ];return pages[step]||pages[0];
}
function rainCloseV286822(){rainViewV286822=null;document.getElementById('rainChapterV286822')?.remove();}
function showRainChapterV286822(replay=-1){
 if(gameState!=='exploring'||!rainUnlockedV286822())return;
 document.getElementById('afterBattleV2838')?.remove();
 stopNavigationV2830();if(typeof FLAT_WORLD!=='undefined')FLAT_WORLD.keys={};
 closeTaskPanel();rainCloseV286822();const s=rainStateV286822(),back=Number.isInteger(replay)&&replay>=0&&replay<=s.step,n=back?replay:s.step;
 const token=++rainSeqV286822;rainViewV286822={owner:player,token,step:s.step,replay:back};
 const el=document.createElement('div');el.id='rainChapterV286822';el.className='rain-overlay-v286822';
 const button=(id,label)=>`<button type="button" class="choice-btn" onclick="actRainV286822(${token},'${id}')">${label}</button>`;
 let buttons='';
 if(!back){
  if([1,5,7].includes(n)){const keys=n===7?['ledger','seal','witness']:['rope','lamp','print'];buttons+=keys.map(k=>button(k,(s.clues.includes(k)?'✓ ':'调查 · ')+RAIN_CLUES_V286822[k][0])).join('');}
  if(n===2)buttons+=button('rescue','先救人 · 留下证人')+button('chase','先追踪 · 掌握暗号');
  else if(n===6)buttons+=button('share','交出原信 · 坦白同行')+button('reserve','暂留原信 · 分头查证');
  else if(n===7)buttons+=button('fraud','判断：伪造死亡，掩盖活人去向')+button('theft','判断：只为盗卖财物');
  else if(n===8)buttons+=button('names','留下姓名，揭去亡签')+button('force','直接破门，正面交锋');
  else if(n===4||n===9)buttons+=(!s.rested.includes(n)?button('rest','接受药包调息 · 本场一次'):'')+button('fight','准备妥当，进入战斗');
  else if(n===11)buttons+=button('public','公开证据 · 三方核查')+button('protect','先安置证人 · 保留证词')+button('trace','保留监视线 · 继续追踪');
  else if(n<13)buttons+=button('next',n===12?'完成卷一 · 领取120灵石':'继续调查');
 }
 const notebook=s.clues.map(k=>`<p><b>${RAIN_CLUES_V286822[k][0]}</b>：${RAIN_CLUES_V286822[k][1]}</p>`).join('');
 el.innerHTML=`<section role="dialog" aria-modal="true" aria-labelledby="rainTitleV286822" class="rain-card-v286822"><header><span>雨夜命牌案 · ${n+1}/14${back?' · 只读回看':''}</span><button type="button" onclick="rainCloseV286822()" aria-label="关闭章节">×</button></header><h2 id="rainTitleV286822">${RAIN_TITLES_V286822[n]}</h2>${rainNarrativeV286822(n,s).map(p=>`<p>${escapeGameText(p)}</p>`).join('')}<div id="rainNoticeV286822" role="status"></div><div class="rain-actions-v286822">${buttons}</div><details><summary>随身案卷 · ${s.clues.length}条证据</summary>${notebook||'<p>暂无线索。</p>'}</details><details><summary>回看已读片段</summary>${RAIN_TITLES_V286822.slice(0,s.step+1).map((t,i)=>`<button type="button" onclick="showRainChapterV286822(${i})">${i+1} · ${t}</button>`).join('')}</details>${back?'<button class="choice-btn" onclick="showRainChapterV286822()">返回当前进度</button>':''}<button class="choice-btn" onclick="rainCloseV286822()">暂别此处 · 进度已保存</button></section>`;
 document.body.appendChild(el);el.querySelector('header button')?.focus();
}
function rainCommitV286822(next,reward=0,rest=false){
 const old={state:player.rainChapterV286822,gold:player.gold,hp:player.hp,mp:player.mp};player.rainChapterV286822=next;player.gold+=reward;
 if(rest){player.hp=getMaxHp();player.mp=getMaxMp();}
 if(saveGame()){updateStats();return true;}
 Object.assign(player,{rainChapterV286822:old.state,gold:old.gold,hp:old.hp,mp:old.mp});return false;
}
function actRainV286822(token,action){
 const v=rainViewV286822,s=rainStateV286822();if(gameState!=='exploring'||!v||v.owner!==player||v.token!==token||v.step!==s.step||v.replay)return false;
 const n=s.step,notice=t=>{const el=document.getElementById('rainNoticeV286822');if(el)el.textContent=t;return false;};
 if(action==='fight'&&(n===4||n===9)){
  if(!player.rainChapterV286822)return false;
  rainCloseV286822();closeWorldOverlay();
  const enemy=balanceEnemyV2802({name:n===4?'渡口山贼':'守册石傀儡',hp:n===4?140:200,maxHp:n===4?140:200,atk:n===4?14:18,def:n===4?4:6,gold:0,exp:0,_realmLevel:0,_realmPhase:0,_isTaskBattle:true,_rainChapterV286822:n});
  if(n===4&&s.route==='chase')enemy.atk=Math.max(1,Math.floor(enemy.atk*.8));
  if(n===9&&s.puzzle)enemy.def=Math.floor(enemy.def*.75);
  startCombat(enemy);if(currentEnemy!==enemy||gameState!=='combat'){showRainChapterV286822();return false;}
  rainFightsV286822.set(enemy,{owner:player,step:n});
  if(n===4&&s.route==='rescue')elementGuardsV286818.set(enemy,{owner:player,pool:Math.floor(getMaxHp()*.15),turns:2,element:'heal'});
  updateCombatUI();return true;
 }
 let reward=0,rest=false;
 if(Object.hasOwn(RAIN_CLUES_V286822,action)&&(([1,5].includes(n)&&['rope','lamp','print'].includes(action))||(n===7&&['ledger','seal','witness'].includes(action)))){if(!s.clues.includes(action))s.clues.push(action);}
 else if(n===2&&['rescue','chase'].includes(action)){s.route=action;s.step++;}
 else if(n===6&&['share','reserve'].includes(action)){s.trust=action;s.step++;}
 else if(n===7&&['fraud','theft'].includes(action)){
  if(!['ledger','seal','witness'].every(k=>s.clues.includes(k)))return notice('还需核对库账、旧印与证词。');
  if(action==='theft')return notice('若只是盗卖财物，为何要给活着的沈禾开验尸单？请再对照死亡日期与药箱批号。没有损失资源。');s.step++;
 }else if(n===8&&['names','force'].includes(action)){s.puzzle=action==='names';s.step++;}
 else if([4,9].includes(n)&&action==='rest'&&!s.rested.includes(n)){s.rested.push(n);rest=true;}
 else if(n===11&&['public','protect','trace'].includes(action)){s.policy=action;s.step++;}
 else if(action==='next'&&[0,1,3,5,10,12].includes(n)){
  if(n===1&&s.clues.filter(k=>['rope','lamp','print'].includes(k)).length<2)return notice('请先调查至少两处痕迹，再决定往哪边去。');
  s.step++;if(n===12&&!s.rewarded){reward=120;s.rewarded=true;}
 }else return false;
 if(!rainCommitV286822(s,reward,rest))return notice('保存失败，本次选择、调息或奖励未生效。请恢复存储后重试。');
 showRainChapterV286822();if(Object.hasOwn(RAIN_CLUES_V286822,action))document.getElementById('rainNoticeV286822').textContent=RAIN_CLUES_V286822[action][1];return true;
}
function finishRainBattleV286822(enemy){
 const battle=rainFightsV286822.get(enemy),s=rainStateV286822();
 if(!battle||battle.owner!==player||enemy.hp>0||s.step!==battle.step)return;
 s.step++;player.rainChapterV286822=s;rainFightsV286822.delete(enemy);
 addCombatLog('命牌案有了新进展，可从任务中的“雨夜命牌案”继续。','gold');
}

function rainVillageV286822(){
 const s=rainStateV286822();if(s.step<13)return rainUnlockedV286822()?rainCardV286822():'';
 const aftermath={public:'渡口贴出了二十四名归来者的姓名。家属可以到三方核查处登记失踪线索，守夜人不再因私谈此案受责。',protect:'药庐留了两间客房安置证人，姓名暂不张榜。沈禾每天替师父添一盏灯，等另外三人归来。',trace:'码头照常装卸，库房的值夜人却多了两位。你留下的暗号交给了可靠的人，下一次送货不会再无人知晓。'};
 return `<section class="area-info-box"><h3>青云渡口 · 复航之后</h3><p>${aftermath[s.policy]||'河灯重新点起，旧案仍有人查访。'}</p><p>${s.route==='rescue'?'沈禾认出你，停下手里的活向你招手：“下回靠岸，我替你留灯。”':'渡工递来沈禾的谢笺：“他醒了。你的暗号我们记住了。”'}</p><button class="choice-btn" onclick="showRainChapterV286822()">翻阅雨夜旧案</button></section>`;
}

document.addEventListener('keydown',e=>{
 const modal=document.getElementById('rainChapterV286822');if(!modal)return;
 if(e.key==='Escape'){e.preventDefault();e.stopPropagation();rainCloseV286822();}
 if(e.key==='Tab'){const buttons=[...modal.querySelectorAll('button,summary')].filter(b=>!b.disabled&&b.getClientRects().length);const first=buttons[0],last=buttons[buttons.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}
},true);
