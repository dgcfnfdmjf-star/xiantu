/* 2.5D wolf battle pilot. Presentation only: never writes gameplay state. */
(()=>{
'use strict';
const W=720,H=420;
function create(host,read){
 const canvas=document.createElement('canvas');canvas.className='duel25-canvas';canvas.setAttribute('aria-label','斜视角战场：全身剑修与野狼');host.appendChild(canvas);
 const ctx=canvas.getContext('2d');if(!ctx){canvas.remove();return null;}
 const bg=document.createElement('canvas');bg.width=W;bg.height=H;const b=bg.getContext('2d');
 let raf=0,last=0,dead=false,elapsed=0,attack=null,hits=[],floats=[],label="";
 const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 function poly(c,pts,fill,stroke){c.beginPath();pts.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.closePath();c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.stroke();}}
 function ellipse(c,x,y,rx,ry,fill){c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fillStyle=fill;c.fill();}
 function line(c,points,color,width=2){c.beginPath();points.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.lineJoin='round';c.stroke();}
 function rock(c,x,y,k){c.save();c.translate(x,y);c.scale(k,k);poly(c,[[-28,8],[-19,-20],[5,-30],[30,-7],[18,15]],'#485e58');poly(c,[[-19,-20],[5,-30],[30,-7],[3,-4]],'#84968a');line(c,[[-19,-20],[3,-4],[18,15]],'#263f3a',2);c.restore();}
 function tree(c,x,y,k){c.save();c.translate(x,y);c.scale(k,k);line(c,[[0,0],[-8,-63],[0,-115]],'#343e34',9);line(c,[[-7,-56],[-40,-77]],'#343e34',6);for(const [a,d,r] of [[-36,-84,30],[5,-117,35],[31,-96,28],[-15,-101,36]]){ellipse(c,a,d,r,r*.35,'#284c42');ellipse(c,a-5,d-5,r*.8,r*.22,'#547e61');}c.restore();}
 function backdrop(){
 const sky=b.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#142b31');sky.addColorStop(.5,'#6f9181');sky.addColorStop(1,'#19382f');b.fillStyle=sky;b.fillRect(0,0,W,H);
 ellipse(b,555,60,33,33,'#d7dfb5');
 for(let i=0;i<4;i++){const y=90+i*25;poly(b,[[0,y+60],[70,y-25],[125,y+10],[215,y-70],[305,y+15],[385,y-33],[455,y+5],[555,y-60],[650,y],[720,y-40],[720,H],[0,H]],['#36595b','#4e726e','#759388','#456958'][i]);}
 b.fillStyle='#88a29455';b.fillRect(0,143,W,27);
 tree(b,65,257,1.35);tree(b,670,232,1.4);rock(b,615,280,1.1);
 poly(b,[[70,275],[372,163],[675,294],[371,426]],'#273f3a','#90a48b');
 for(let row=0;row<6;row++)for(let col=0;col<6;col++){const x=372+(col-row)*49,y=179+(row+col)*20;poly(b,[[x,y],[x+47,y+19],[x,y+38],[x-47,y+19]],(row+col)%3?'#697b66':'#798a72','#3f594b');}
 ellipse(b,368,306,158,61,'#9faf7930');b.strokeStyle='#c1c89655';b.lineWidth=1;b.beginPath();b.ellipse(368,306,152,58,0,0,Math.PI*2);b.stroke();
 for(let i=0;i<24;i++){const x=(i*113+23)%720,y=340+(i*29)%70;line(b,[[x,y],[x-4,y-13],[x,y-5],[x+6,y-19]],'#233f31',2);}
 rock(b,28,385,1.8);tree(b,745,440,1.9);
}
 backdrop();
 function swordman(c,x,y,t,pose,fall){
  c.save();c.translate(x,y);if(fall){c.rotate(-1.3);c.scale(.95,.8);}const walk=pose?Math.sin(pose*Math.PI*4):Math.sin(t*2)*.08,lean=pose?Math.sin(pose*Math.PI)*.15:0;c.rotate(lean);
  // Back sleeve, flowing sash and two articulated legs.
  poly(c,[[-5,-87],[-36,-76],[-29,-44],[-16,-64]],'#789eac','#234455');
  line(c,[[-8,-44],[-14+walk*10,-20],[-18+walk*14,-3]],'#254757',9);line(c,[[8,-44],[15-walk*10,-20],[23-walk*14,0]],'#254757',9);
  line(c,[[-18+walk*14,-3],[-8+walk*14,-3]],'#162d37',5);line(c,[[23-walk*14,0],[34-walk*14,0]],'#162d37',5);
  poly(c,[[-15,-91],[13,-91],[18,-60],[32+walk*7,-14],[0,-22],[-31-walk*4,-17],[-15,-62]],'#d5e2d9','#6e9ba5');
  poly(c,[[1,-90],[13,-91],[18,-60],[26,-20],[9,-28],[2,-57]],'#80a9b3');
  line(c,[[-10,-87],[2,-66],[11,-87]],'#e7e8ce',3);line(c,[[-16,-60],[18,-59]],'#294b60',7);
  poly(c,[[11,-60],[19,-60],[40+Math.sin(t*3)*8,-28],[32,-30]],'#b5ced4');
  ellipse(c,0,-108,12,16,'#d6b68e');poly(c,[[-12,-111],[-9,-128],[8,-127],[14,-114],[7,-119],[-4,-117]],'#142b35');
  ellipse(c,-3,-132,6,7,'#1c3038');line(c,[[-10,-111],[-17,-81],[-25+Math.sin(t*2)*3,-65]],'#192e37',7);
  line(c,[[6,-109],[11,-108]],'#3a3532',1);line(c,[[-7,-131],[8,-132]],'#c3c697',2);
  // Sword arm rotates at shoulder; elbow follows the slash.
  c.save();c.translate(11,-84);c.rotate(pose?-.9+Math.sin(pose*Math.PI)*1.8:-.22);
  poly(c,[[0,-8],[21,0],[27,21],[8,19]],'#c7dbdc','#6e9ba5');line(c,[[19,12],[33,14]],'#d6b68e',5);
  line(c,[[32,6],[32,23]],'#c8b985',4);poly(c,[[37,11],[87,10],[99,14],[86,17],[37,16]],'#e5f6ee','#93c7c9');line(c,[[40,14],[89,14]],'#7ab9c4',1);c.restore();
  c.restore();
 }
 function wolf(c,x,y,t,pose,fall){
  c.save();c.translate(x,y);c.scale(-1,1);if(fall){c.rotate(.95);c.translate(0,10);}const stride=pose?Math.sin(pose*13)*16:Math.sin(t*2)*1.5;
  line(c,[[-28,-35],[-53,-43],[-64,-30]],'#728b89',12);
  for(const [px,offset] of [[-25,1],[-13,-1],[22,-1],[33,1]])line(c,[[px,-34],[px+stride*offset*.5,-15],[px+stride*offset,-2],[px+8+stride*offset,-2]],offset===1?'#a7bab5':'#566e70',7);
  poly(c,[[-42,-47],[-19,-62],[19,-57],[40,-43],[29,-23],[-28,-25]],'#839c9a','#344f52');
  poly(c,[[-32,-46],[-10,-60],[22,-55],[8,-41],[-23,-37]],'#b7c8bc');
  poly(c,[[18,-50],[27,-76],[45,-69],[53,-53],[67,-44],[66,-34],[48,-31],[29,-39]],'#a5b9b1','#344f52');
  poly(c,[[28,-67],[23,-90],[39,-73]],'#788f8f','#344f52');poly(c,[[40,-68],[45,-87],[50,-65]],'#617e82');
  poly(c,[[22,-54],[12,-44],[25,-44],[17,-33],[34,-38]],'#d0d7c2');
  line(c,[[46,-54],[53,-52]],'#f5d487',3);ellipse(c,65,-42,4,3,'#193539');line(c,[[52,-35],[63,-34]],'#21393d',2);
  if(pose)poly(c,[[56,-33],[60,-32],[58,-26]],'#f0e8d1');c.restore();
 }
 function draw(now){
  if(dead)return;raf=0;const data=read();if(data.active===false){destroy();return;}if(document.hidden)return;
  if(now-last<33){raf=requestAnimationFrame(draw);return;}const dt=Math.min(60,Math.max(0,now-last));last=now;elapsed+=dt;
  const width=Math.max(1,host.clientWidth||W),dpr=Math.min(1.5,window.devicePixelRatio||1);const pw=Math.round(width*dpr),ph=Math.round(width*H/W*dpr);
  if(canvas.width!==pw||canvas.height!==ph){canvas.width=pw;canvas.height=ph;}ctx.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);ctx.drawImage(bg,0,0);
  const t=elapsed/1000,age=attack?(elapsed-attack.at)/650:2,p=age<=1?age:0,move=!reduced&&p?Math.sin(Math.PI*p)*150:0;
  const px=242+(attack?.side==='player'?move:0),ex=493-(attack?.side==='enemy'?move:0);
  const actors=[{side:'player',x:px,y:305},{side:'enemy',x:ex,y:278}].sort((a,b)=>a.y-b.y);
  for(const a of actors){ellipse(ctx,a.x,a.y+2,a.side==='player'?29:43,10,'#102d2c66');const hit=hits.find(h=>h.side===a.side&&elapsed-h.at<250);ctx.save();ctx.globalAlpha=hit&&Math.floor((elapsed-hit.at)/55)%2?.6:1;
   const recoil=hit&&!reduced?Math.sin((elapsed-hit.at)/250*Math.PI)*8:0;
   if(a.side==='player')swordman(ctx,a.x-recoil,a.y,t,attack?.side==='player'?p:0,data.playerHp<=0);else wolf(ctx,a.x+recoil,a.y,t,attack?.side==='enemy'?p:0,data.enemyHp<=0);ctx.restore();}
  if(attack&&age<1){const k=Math.sin(age*Math.PI),from=attack.side==='player'?px:ex,to=attack.side==='player'?ex:px;
   if(attack.element==='heal'){ctx.strokeStyle='#b4f9ac';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(from,280,35+k*20,12+k*9,0,0,Math.PI*2);ctx.stroke();}
   else if(/thunder|雷/.test(attack.element)){line(ctx,[[to,62],[to-18,119],[to+9,141],[to-12,190],[to,235]],'#d8fbff',3+k*3);}
   else {ctx.strokeStyle=attack.side==='player'?'#c5f8e2':'#e5c78d';ctx.globalAlpha=k;ctx.lineWidth=3+3*k;ctx.beginPath();ctx.ellipse((from+to)/2,237,55+k*30,30,.3,Math.PI*1.15,Math.PI*2.1);ctx.stroke();ctx.globalAlpha=1;}
  }
  hits=hits.filter(h=>elapsed-h.at<260);floats=floats.filter(f=>elapsed-f.at<850);
  for(const f of floats){ctx.globalAlpha=1-(elapsed-f.at)/850;ctx.fillStyle=f.heal?'#b6f0a3':'#ffe2af';ctx.font='bold 24px serif';ctx.textAlign='center';ctx.fillText(f.text,f.side==='player'?px:ex,177-(elapsed-f.at)/22);ctx.globalAlpha=1;}
  const hud=(x,name,hp,max,color)=>{ctx.textAlign='left';ctx.font='bold 17px serif';ctx.fillStyle='#edf0d8';ctx.fillText(name,x,35);ctx.fillStyle='#152c2ccf';ctx.fillRect(x,46,180,7);ctx.fillStyle=color;ctx.fillRect(x,46,180*Math.max(0,Math.min(1,hp/Math.max(1,max))),7);ctx.font='12px sans-serif';ctx.fillStyle='#d4dfca';ctx.fillText(`${Math.max(0,Math.ceil(hp))} / ${Math.ceil(max)}`,x,70);};
  hud(30,data.playerName||'青云剑修',data.playerHp,data.playerMax,'#a5cc9f');hud(510,data.enemyName||'苍山野狼',data.enemyHp,data.enemyMax,'#dba176');
  ctx.fillStyle='#dce2bf';ctx.textAlign='center';ctx.font='12px sans-serif';ctx.fillText('青云试剑坪 · 全身动作演武',360,397);
  const nextLabel=`${data.playerName||"剑修"}气血${Math.ceil(data.playerHp)}，${data.enemyName||"野狼"}气血${Math.ceil(data.enemyHp)}`;if(label!==nextLabel){label=nextLabel;canvas.setAttribute("aria-label",label);}
  raf=requestAnimationFrame(draw);
 }
 function wake(){if(!dead&&!document.hidden&&!raf){last=performance.now();raf=requestAnimationFrame(draw);}}
 function visibility(){if(document.hidden){cancelAnimationFrame(raf);raf=0;}else wake();}
 function destroy(){if(dead)return;dead=true;cancelAnimationFrame(raf);raf=0;document.removeEventListener('visibilitychange',visibility);canvas.remove();bg.width=bg.height=1;host.classList.remove('duel25-active');if(host.id==='combatArena')document.getElementById('combatPanel')?.classList.remove('duel25-panel');}
 host.classList.add('duel25-active');if(host.id==='combatArena')document.getElementById('combatPanel')?.classList.add('duel25-panel');document.addEventListener('visibilitychange',visibility);wake();
 return {act(side,element='sword'){attack={side,element,at:elapsed};},hit(side,amount,heal=false){hits.push({side,at:elapsed});floats.push({side,text:(heal?'+':'−')+Math.round(amount),heal,at:elapsed});},destroy,canvas};
}
window.XiantuDuel25D={create};
if(typeof window.startCombat==='function'){
 let scene=null,owner=null,foe=null;
 const stop=()=>{scene?.destroy();scene=null;document.getElementById('combatArena')?.classList.remove('duel25-active');};
 const start=window.startCombat;window.startCombat=function(...args){const result=start.apply(this,args);if(typeof currentEnemy!=='undefined'&&currentEnemy===args[0]&&gameState==='combat'){stop();if(currentEnemy.name==='野狼'){owner=player;foe=currentEnemy;scene=create(document.getElementById('combatArena'),()=>({active:player===owner&&currentEnemy===foe&&(gameState==='combat'||gameState==='combat-ending'),playerName:player.name,enemyName:currentEnemy.name,playerHp:player.hp,playerMax:getMaxHp(),enemyHp:currentEnemy.hp,enemyMax:currentEnemy.maxHp}));}}return result;};
 for(const name of ['resetRuntimeState','endCombatAfterCapture']){const base=window[name];if(typeof base==='function')window[name]=function(...args){stop();return base.apply(this,args);};}
 const attack=window.playAttackAnimation;window.playAttackAnimation=function(side){if(scene){scene.act(side);return;}return attack.apply(this,arguments);};
 const skill=window.playSkillEffect;window.playSkillEffect=function(name,element,source){if(scene){scene.act('player',element||'sword');return;}return skill.apply(this,arguments);};
 const damage=window.showDamageNumber;window.showDamageNumber=function(amount,side,heal){if(scene){scene.hit(side,amount,heal);return;}return damage.apply(this,arguments);};
 const story=window.showStory;window.showStory=function(...args){if(scene)stop();return story.apply(this,args);};
}
})();
;window.__xiantuBuildFilesV2814=window.__xiantuBuildFilesV2814||{};window.__xiantuBuildFilesV2814['xiantu-v28684-duel.js']='28.68.6';
